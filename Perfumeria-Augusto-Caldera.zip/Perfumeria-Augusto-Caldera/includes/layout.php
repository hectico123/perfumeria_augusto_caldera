<?php
require_once __DIR__ . '/../config/config.php';
require_login();

if (session_expired(120)) {
    logout();
    flash_set('warning', 'Tu sesión expiró por inactividad.');
    redirect('login');
}

$u = current_user();
$systemModal = $_SESSION['_system_modal'] ?? null;
unset($_SESSION['_system_modal']);
$page = $page ?? 'Dashboard';
$active = $active ?? 'dashboard';

function nav_link(string $href, string $label, string $key, string $activeKey, string $icon = ''): string {
    $cls = ($key === $activeKey) ? 'nav-link active dsl' : 'nav-link navdslon';
    $iconHtml = $icon ? '<i class="bi bi-' . $icon . ' me-2"></i>' : '';
    return '<li class="nav-item mb-1 navdsloff"><a href="' . e(BASE_URL . $href) . '" class="' . $cls . '">' . $iconHtml . e($label) . '</a></li>';
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-Frame-Options" content="SAMEORIGIN">
  <meta http-equiv="X-Content-Type-Options" content="nosniff">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($page) ?> - <?= e(APP_NAME) ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
  <!-- Después de los estilos de Bootstrap -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="<?= e(ASSETS_URL) ?>css/styles.css">
  <style>
    .app-footer{
  text-align:center;
  padding:12px;
  font-size:13px;
  color:#777;
  border-top:1px solid #eee;
  margin-top:20px;
}
  </style>
</head>
<body class="bgdsl">
  <div id="number" style="display: none;"></div>
<div class="container-fluid">
  <div class="row">

    <!-- Sidebar (desktop) -->
    <nav id="sidebar" class="col-12 col-md-3 col-lg-2 d-none d-md-flex flex-column bg-white vh-100 p-3 border-end overflow-auto shadow">
      <div class="d-flex align-items-center mb-4">
        <img src="<?= e(ASSETS_URL) ?>img/logo.jpeg" alt="Logo" class="rounded-circle" style="width:48px;height:48px;object-fit:cover;">
        <div class="ms-2">
          <h6 class="mb-0">Perfumería</h6>
          <small class="text-muted">Augusto Caldera</small>
        </div>
      </div>

      <ul class="nav nav-pills flex-column mb-auto">
          <?= nav_link('dashboard', 'Dashboard', 'dashboard', $active, 'speedometer2') ?>
          <?= nav_link('categorias', 'Categorías', 'categorias', $active, 'tags') ?>
          <?= nav_link('productos', 'Productos', 'productos', $active, 'box-seam') ?>
          <?= nav_link('movimientos', 'Entradas / Salidas', 'movimientos', $active, 'arrow-left-right') ?>
          <?= nav_link('configuracion', 'Configuración', 'config', $active, 'gear') ?>
          <?php if (($u['role'] ?? '') === 'admin'): ?>
              <?= nav_link('usuarios', 'Usuarios', 'usuarios', $active, 'people') ?>
              
              <?= nav_link('auditoria', 'Reportes y Auditoría', 'auditoria', $active, 'file-earmark-text') ?>
          <?php endif; ?>

          <li class="nav-item mb-1">
              <a href="#" class="nav-link navdslon" data-bs-toggle="modal" data-bs-target="#logoutModal">
                  <i class="bi bi-box-arrow-right me-2"></i>Cerrar sesión
              </a>
          </li>
      </ul>

      <div class="mt-auto pt-3 border-top">
        <div class="d-flex align-items-center">
          <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width:40px;height:40px;">
            <?= e(strtoupper(substr($u['name'] ?? 'U', 0, 1))) ?>
          </div>
          <div class="ms-2">
            <div class="fw-bold"><?= e($u['name'] ?? 'Usuario') ?></div>
            <small class="text-muted"><?= e(($u['role'] ?? 'user') === 'admin' ? 'Administrador' : 'Usuario') ?></small>
          </div>
        </div>
      </div>
    </nav>

    <!-- Offcanvas (mobile) -->
    <div class="offcanvas offcanvas-start" tabindex="-1" id="mobileSidebar" aria-labelledby="mobileSidebarLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="mobileSidebarLabel">Perfumería</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Cerrar"></button>
      </div>
      <div class="offcanvas-body overflow-auto">
      <ul class="nav nav-pills flex-column">
          <li class="nav-item mb-1"><a href="<?= e(BASE_URL) ?>dashboard" class="nav-link navdslon<?= $active==='dashboard'?'active':'' ?>"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a></li>
          <li class="nav-item mb-1"><a href="<?= e(BASE_URL) ?>categorias" class="nav-link navdslon<?= $active==='categorias'?'active':'' ?>"><i class="bi bi-tags me-2"></i>Categorías</a></li>
          <li class="nav-item mb-1"><a href="<?= e(BASE_URL) ?>productos" class="nav-link navdslon<?= $active==='productos'?'active':'' ?>"><i class="bi bi-box-seam me-2"></i>Productos</a></li>
          <li class="nav-item mb-1"><a href="<?= e(BASE_URL) ?>movimientos" class="nav-link navdslon<?= $active==='movimientos'?'active':'' ?>"><i class="bi bi-arrow-left-right me-2"></i>Entradas / Salidas</a></li>
          <li class="nav-item mb-1"><a href="<?= e(BASE_URL) ?>configuracion" class="nav-link navdslon<?= $active==='config'?'active':'' ?>"><i class="bi bi-gear me-2"></i>Configuración</a></li>
          <?php if (($u['role'] ?? '') === 'admin'): ?>
              <li class="nav-item mb-1"><a href="<?= e(BASE_URL) ?>usuarios" class="nav-link navdslon<?= $active==='usuarios'?'active':'' ?>"><i class="bi bi-people me-2"></i>Usuarios</a></li>
              
              <li class="nav-item mb-1"><a href="<?= e(BASE_URL) ?>auditoria" class="nav-link navdslon<?= $active==='auditoria'?'active':'' ?>"><i class="bi bi-file-earmark-text me-2"></i>Reportes y Auditoría</a></li>
          <?php endif; ?>

          <li class="nav-item mb-1">
              <a href="<?= e(BASE_URL) ?>logout" class="nav-link navdslon">
                  <i class="bi bi-box-arrow-right me-2"></i>Cerrar Sesión
              </a>
          </li>
      </ul>
      </div>
    </div>

    <!-- Main content -->
    <main class="col-12 col-md-9 col-lg-10 py-4">
      <div class="d-flex justify-content-between align-items-start mb-4 flex-wrap gap-3">
        <div>
          <h1 class="h4 mb-0"><?= e(APP_NAME) ?></h1>
          <p class="text-muted mb-0"><?= e($page) ?></p>
        </div>
        <div class="d-flex gap-2 align-items-center">
          <button class="btn btn-outline-secondary d-md-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileSidebar" aria-controls="mobileSidebar">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
          </button>
          
        </div>
      </div>

<!-- MODAL CERRAR SESIÓN -->
<div class="modal fade" id="logoutModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-sm">
    <div class="modal-content modal-delete">

      <div class="modal-header border-0 pb-0">
        <h5 class="modal-title">
          <i class="bi bi-exclamation-triangle text-danger me-2"></i>
          Cerrar sesión
        </h5>

        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body text-center pt-2">

        <div class="delete-icon">
          <i class="bi bi-box-arrow-right"></i>
        </div>

        <p class="mb-1">Estás por cerrar tu sesión</p>

        <div class="delete-name">
          <?= e($u['name'] ?? 'Usuario') ?>
        </div>

        <p class="text-muted small mt-3 mb-0">
          Tendrás que volver a iniciar sesión para continuar.
        </p>

      </div>

      <div class="modal-footer border-0 pt-0 justify-content-center">

        <button type="button" class="btn btn-cancel" data-bs-dismiss="modal">
          Cancelar
        </button>

        <a href="<?= e(BASE_URL) ?>logout" class="btn btndeleteconfirm" style="width: auto;">
          Sí, cerrar
        </a>

      </div>

    </div>
  </div>
</div>
<?php if ($systemModal): ?>
<div class="modal fade" id="systemAlertModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-sm">
    <div class="modal-content modal-delete">

      <div class="modal-header border-0 pb-0">
        <h5 class="modal-title">
          <i class="bi <?= e($systemModal['icon']) ?> <?= e($systemModal['icon_color']) ?> me-2"></i>
          <?= e($systemModal['title']) ?>
        </h5>

        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body text-center pt-2">

        <div class="delete-icon">
          <i class="bi <?= e($systemModal['icon']) ?>"></i>
        </div>

        <?php if (!empty($systemModal['headline'])): ?>
          <p class="mb-1"><?= e($systemModal['headline']) ?></p>
        <?php endif; ?>

        <div class="delete-name">
          <?= e($u['name'] ?? 'Usuario') ?>
        </div>

        <p class="text-muted small mt-3 mb-0">
          <?= e($systemModal['message']) ?>
        </p>

      </div>

      <div class="modal-footer border-0 pt-0 justify-content-center">
        <a href="<?= e(BASE_URL . $systemModal['button_href']) ?>" class="btn <?= e($systemModal['button_class']) ?>" style="width:auto;">
          <?= e($systemModal['button_text']) ?>
        </a>
      </div>

    </div>
  </div>
</div>
<?php endif; ?>

<?php if ($systemModal): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var modalEl = document.getElementById('systemAlertModal');
    if (modalEl) {
        var modal = new bootstrap.Modal(modalEl);
        modal.show();
    }
});
</script>
<?php endif; ?>

    <script type="text/javascript">
        n = 1000
        var l = document.getElementById("number");
        var id = window.setInterval(function(){
            document.onmousemove = function(){
                n = 1000
            };
            l.innerText = n;
            n--;

            if (n <= -1){
                
                location.href="logout.php";
            }
        },1200);
    </script>

      <?php $flash = flash_get(); if ($flash): ?>
        <div class="alert alert-<?= e($flash['type']) ?>" role="alert"><?= e($flash['message']) ?></div>
      <?php endif; ?>
