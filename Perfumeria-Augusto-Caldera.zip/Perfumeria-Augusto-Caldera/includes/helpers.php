<?php

declare(strict_types=1);

function e(?string $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function app_legacy_route_map(): array {
    return [
        'index.php' => '',
        'dashboard.php' => 'dashboard',
        'categorias.php' => 'categorias',
        'productos.php' => 'productos',
        'movimientos.php' => 'movimientos',
        'usuarios.php' => 'usuarios',
        'usuarios_delete.php' => 'usuarios/eliminar',
        'configuracion.php' => 'configuracion',
        'auditoria.php' => 'auditoria',
        'export.php' => 'export',
        'forgot_password.php' => 'forgot-password',
        'reset_password.php' => 'reset-password',
        'logout.php' => 'logout',
        'login' => 'login',
    ];
}

function is_external_url(string $path): bool {
    return (bool) preg_match('#^(?:https?:)?//#i', $path)
        || str_starts_with($path, 'mailto:')
        || str_starts_with($path, 'tel:')
        || str_starts_with($path, 'javascript:')
        || str_starts_with($path, '#');
}

function normalize_internal_path(string $path): string {
    $path = trim($path);

    if ($path === '') {
        return '';
    }

    if (is_external_url($path)) {
        return $path;
    }

    if (defined('BASE_URL') && str_starts_with($path, BASE_URL)) {
        $basePath = parse_url(BASE_URL, PHP_URL_PATH) ?: '/';
        $path = substr($path, strlen((string)BASE_URL)) ?: '';
        return trim($path, '/');
    }

    $fragment = '';
    $query = '';

    if (str_contains($path, '#')) {
        [$path, $fragment] = explode('#', $path, 2);
        $fragment = '#' . $fragment;
    }

    if (str_contains($path, '?')) {
        [$path, $query] = explode('?', $path, 2);
        $query = '?' . $query;
    }

    $path = ltrim($path, '/');
    $path = preg_replace('#^\./#', '', $path) ?? $path;

    $map = app_legacy_route_map();
    if (array_key_exists($path, $map)) {
        $path = $map[$path];
    }

    return trim($path, '/') . $query . $fragment;
}

function url(string $path = ''): string {
    $normalized = normalize_internal_path($path);

    if ($normalized === '') {
        return rtrim(BASE_URL, '/') . '/';
    }

    if (is_external_url($normalized)) {
        return $normalized;
    }

    return rtrim(BASE_URL, '/') . '/' . ltrim($normalized, '/');
}

function redirect(string $path): void {
    $location = is_external_url($path) || (defined('BASE_URL') && str_starts_with($path, BASE_URL))
        ? $path
        : url($path);

    if (!headers_sent()) {
        if (function_exists('ob_get_level') && ob_get_level() > 0) {
            @ob_clean();
        }
        header('Location: ' . $location);
        exit;
    }

    $safe = htmlspecialchars($location, ENT_QUOTES, 'UTF-8');
    echo "<script>window.location.href='{$safe}';</script>";
    echo "<noscript><meta http-equiv=\"refresh\" content=\"0;url={$safe}\"></noscript>";
    exit;
}

function resolve_route_from_request(): string {
    $route = trim((string)($_GET['route'] ?? ''));
    if ($route !== '') {
        return trim(normalize_internal_path($route), '/');
    }

    $requestUri = (string)($_SERVER['REQUEST_URI'] ?? '/');
    $path = parse_url($requestUri, PHP_URL_PATH) ?: '/';
    $basePath = parse_url(BASE_URL, PHP_URL_PATH) ?: '/';

    $path = str_replace('\\', '/', $path);
    $basePath = rtrim(str_replace('\\', '/', $basePath), '/');

    if ($basePath !== '' && $basePath !== '/' && str_starts_with($path, $basePath)) {
        $path = substr($path, strlen($basePath));
    }

    return trim(normalize_internal_path($path), '/');
}

function flash_set(string $type, string $message): void {
    $_SESSION['_flash'] = ['type' => $type, 'message' => $message];
}

function flash_get(): ?array {
    if (!isset($_SESSION['_flash'])) {
        return null;
    }

    $f = $_SESSION['_flash'];
    unset($_SESSION['_flash']);
    return $f;
}

function is_post(): bool {
    return ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
}

function require_https_hint(): void {
    // En local puede no haber HTTPS.
}

function old_input_set(array $data): void {
    $_SESSION['_old_input'] = $data;
}

function old_form_data(): array {
    return $_SESSION['_old_input'] ?? [];
}

function old_input_clear(): void {
    unset($_SESSION['_old_input']);
}

function valid_person_name(string $value): bool {
    $value = trim($value);

    if ($value === '') {
        return false;
    }

    if (mb_strlen($value) > 30) {
        return false;
    }

    return (bool) preg_match('/^[\p{L}\s]+$/u', $value);
}
