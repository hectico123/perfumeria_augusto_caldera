<?php
/**
 * Funciones de Validación
 * Perfumería Augusto Caldera
 */

/**
 * Sanitiza una cadena de texto para prevenir XSS
 * @param string $texto Texto a sanitizar
 * @return string Texto sanitizado
 */
function sanitizar_texto($texto)
{
    return htmlspecialchars(trim($texto), ENT_QUOTES, 'UTF-8');
}

/**
 * Sanitiza un array completo de datos
 * @param array $datos Array de datos a sanitizar
 * @return array Array sanitizado
 */
function sanitizar_array($datos)
{
    $sanitizado = [];
    foreach ($datos as $clave => $valor) {
        if (is_array($valor)) {
            $sanitizado[$clave] = sanitizar_array($valor);
        }
        else {
            $sanitizado[$clave] = sanitizar_texto($valor);
        }
    }
    return $sanitizado;
}

/**
 * Valida que un campo no esté vacío
 * @param mixed $valor Valor a validar
 * @param string $nombre_campo Nombre del campo (para el mensaje de error)
 * @return array ['valido' => bool, 'mensaje' => string]
 */
function validar_requerido($valor, $nombre_campo = 'Campo')
{
    $es_valido = !empty(trim($valor));
    return [
        'valido' => $es_valido,
        'mensaje' => $es_valido ? '' : "$nombre_campo es obligatorio"
    ];
}

/**
 * Valida formato de email
 * @param string $email Email a validar
 * @return array ['valido' => bool, 'mensaje' => string]
 */
function validar_email($email)
{
    $es_valido = filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    return [
        'valido' => $es_valido,
        'mensaje' => $es_valido ? '' : 'El formato del email no es válido'
    ];
}

/**
 * Valida longitud mínima de un texto
 * @param string $valor Valor a validar
 * @param int $minimo Longitud mínima
 * @param string $nombre_campo Nombre del campo
 * @return array ['valido' => bool, 'mensaje' => string]
 */
function validar_longitud_minima($valor, $minimo, $nombre_campo = 'Campo')
{
    $longitud = strlen(trim($valor));
    $es_valido = $longitud >= $minimo;
    return [
        'valido' => $es_valido,
        'mensaje' => $es_valido ? '' : "$nombre_campo debe tener al menos $minimo caracteres"
    ];
}

/**
 * Valida longitud máxima de un texto
 * @param string $valor Valor a validar
 * @param int $maximo Longitud máxima
 * @param string $nombre_campo Nombre del campo
 * @return array ['valido' => bool, 'mensaje' => string]
 */
function validar_longitud_maxima($valor, $maximo, $nombre_campo = 'Campo')
{
    $longitud = strlen(trim($valor));
    $es_valido = $longitud <= $maximo;
    return [
        'valido' => $es_valido,
        'mensaje' => $es_valido ? '' : "$nombre_campo no puede exceder $maximo caracteres"
    ];
}

/**
 * Valida que un valor sea numérico
 * @param mixed $valor Valor a validar
 * @param string $nombre_campo Nombre del campo
 * @return array ['valido' => bool, 'mensaje' => string]
 */
function validar_numerico($valor, $nombre_campo = 'Campo')
{
    $es_valido = is_numeric($valor);
    return [
        'valido' => $es_valido,
        'mensaje' => $es_valido ? '' : "$nombre_campo debe ser un número válido"
    ];
}

/**
 * Valida que un valor sea un número positivo
 * @param mixed $valor Valor a validar
 * @param string $nombre_campo Nombre del campo
 * @return array ['valido' => bool, 'mensaje' => string]
 */
function validar_numero_positivo($valor, $nombre_campo = 'Campo')
{
    $es_valido = is_numeric($valor) && floatval($valor) > 0;
    return [
        'valido' => $es_valido,
        'mensaje' => $es_valido ? '' : "$nombre_campo debe ser un número positivo"
    ];
}

/**
 * Valida datos de un producto
 * @param array $datos Datos del producto a validar
 * @return array Array de errores (vacío si no hay errores)
 */
function validar_producto($datos)
{
    $errores = [];

    // Validar nombre
    $validacion = validar_requerido($datos['nombre'] ?? '', 'Nombre del producto');
    if (!$validacion['valido']) {
        $errores['nombre'] = $validacion['mensaje'];
    }
    else {
        $validacion = validar_longitud_maxima($datos['nombre'], 100, 'Nombre del producto');
        if (!$validacion['valido']) {
            $errores['nombre'] = $validacion['mensaje'];
        }
    }

    // Validar categoría
    $validacion = validar_requerido($datos['categoria'] ?? '', 'Categoría');
    if (!$validacion['valido']) {
        $errores['categoria'] = $validacion['mensaje'];
    }

    // Validar precio
    $validacion = validar_numero_positivo($datos['precio'] ?? '', 'Precio');
    if (!$validacion['valido']) {
        $errores['precio'] = $validacion['mensaje'];
    }

    // Validar stock
    $validacion = validar_numerico($datos['stock'] ?? '', 'Stock');
    if (!$validacion['valido']) {
        $errores['stock'] = $validacion['mensaje'];
    }
    elseif (floatval($datos['stock']) < 0) {
        $errores['stock'] = 'Stock no puede ser negativo';
    }

    return $errores;
}

/**
 * Valida datos de una categoría
 * @param array $datos Datos de la categoría a validar
 * @return array Array de errores (vacío si no hay errores)
 */
function validar_categoria($datos)
{
    $errores = [];

    // Validar nombre
    $validacion = validar_requerido($datos['nombre'] ?? '', 'Nombre de la categoría');
    if (!$validacion['valido']) {
        $errores['nombre'] = $validacion['mensaje'];
    }
    else {
        $validacion = validar_longitud_maxima($datos['nombre'], 50, 'Nombre de la categoría');
        if (!$validacion['valido']) {
            $errores['nombre'] = $validacion['mensaje'];
        }
    }

    // Descripción es opcional, pero validar longitud si existe
    if (!empty($datos['descripcion'])) {
        $validacion = validar_longitud_maxima($datos['descripcion'], 255, 'Descripción');
        if (!$validacion['valido']) {
            $errores['descripcion'] = $validacion['mensaje'];
        }
    }

    return $errores;
}

/**
 * Valida datos de login
 * @param array $datos Datos del login
 * @return array Array de errores (vacío si no hay errores)
 */
function validar_login($datos)
{
    $errores = [];

    // Validar email
    $validacion = validar_requerido($datos['email'] ?? '', 'Email');
    if (!$validacion['valido']) {
        $errores['email'] = $validacion['mensaje'];
    }
    else {
        $validacion = validar_email($datos['email']);
        if (!$validacion['valido']) {
            $errores['email'] = $validacion['mensaje'];
        }
    }

    // Validar password
    $validacion = validar_requerido($datos['password'] ?? '', 'Contraseña');
    if (!$validacion['valido']) {
        $errores['password'] = $validacion['mensaje'];
    }

    return $errores;
}
