<?php

declare(strict_types=1);

function is_logged_in(): bool {
    return !empty($_SESSION['user']['id']);
}

function is_2fa_pending(): bool {
    return false;
}

function require_no_2fa_pending(): void {
    // 2FA eliminado
}

function current_user(): ?array {
    return $_SESSION['user'] ?? null;
}

function require_login(): void {
    if (!is_logged_in()) {
        flash_set('danger', 'Debes iniciar sesión.');
        redirect('login');
    }
}

function system_modal_set(array $config): void {
    $_SESSION['_system_modal'] = [
        'title'         => (string)($config['title'] ?? 'Aviso'),
        'icon'          => (string)($config['icon'] ?? 'bi-exclamation-triangle'),
        'icon_color'    => (string)($config['icon_color'] ?? 'text-danger'),
        'headline'      => (string)($config['headline'] ?? ''),
        'message'       => (string)($config['message'] ?? ''),
        'button_text'   => (string)($config['button_text'] ?? 'Entendido'),
        'button_href'   => (string)($config['button_href'] ?? 'dashboard'),
        'button_class'  => (string)($config['button_class'] ?? 'btndeleteconfirm'),
    ];
}

function require_admin(): void {
    require_login();

    $u = current_user();

    if (($u['role'] ?? '') !== 'admin') {
        http_response_code(403);

        system_modal_set([
            'title'        => 'Acceso restringido',
            'icon'         => 'bi-shield-lock',
            'icon_color'   => 'text-danger',
            'headline'     => 'No autorizado',
            'message'      => 'No tienes permisos para acceder a este apartado. Si necesitas esta función, solicita autorización al administrador del sistema.',
            'button_text'  => 'Entendido',
            'button_href'  => 'dashboard',
            'button_class' => 'btndeleteconfirm',
        ]);

        redirect('dashboard');
    }
}

function login_attempt(string $usernameOrEmail, string $password): array {
    $usernameOrEmail = trim($usernameOrEmail);

    if ($usernameOrEmail === '' || $password === '') {
        return ['ok' => false, 'msg' => 'Completa usuario/email y contraseña.'];
    }

    $row = db_one(
        'SELECT user_id, firstname, lastname, user_name, user_email, user_password_hash, role, is_active,
                failed_attempts, locked_until
         FROM users
         WHERE user_name = :u1 OR user_email = :u2
         LIMIT 1',
        [':u1' => $usernameOrEmail, ':u2' => $usernameOrEmail]
    );

    if (!$row || (int)$row['is_active'] !== 1) {
       // Cámbialo por esto:
       audit_log('Sesión Fallida', 'auth', null, ['Razón' => 'Usuario no encontrado o inactivo', 'Usuario' => $usernameOrEmail]);
        return ['ok' => false, 'msg' => 'Credenciales inválidas.'];
    }

    if (!empty($row['locked_until']) && strtotime((string)$row['locked_until']) > time()) {
        audit_log('Sesión Bloqueada', 'auth', (int)$row['user_id'], ['until' => $row['locked_until']]);
        return ['ok' => false, 'msg' => 'Cuenta bloqueada temporalmente por intentos fallidos. Intenta más tarde.'];
    }

    if (!password_verify($password, $row['user_password_hash'])) {
        $attempts = (int)($row['failed_attempts'] ?? 0) + 1;
        $lockUntil = null;

        if ($attempts >= 3) {
            $attempts = 3;
            $lockUntil = date('Y-m-d H:i:s', time() + (15 * 60));
        }

        db_exec(
            'UPDATE users SET failed_attempts = :fa, locked_until = :lu WHERE user_id = :id',
            [':fa' => $attempts, ':lu' => $lockUntil, ':id' => (int)$row['user_id']]
        );

        audit_log('Sesión Fallida', 'auth', (int)$row['user_id'], ['Razon' => 'Contraseña Erronea', 'Intentos Fallidos' => $attempts]);

       $restantes = 3 - $attempts;

        return [
            'ok' => false,
            'msg' => $lockUntil
                ? 'Cuenta bloqueada por 15 minutos (3 intentos fallidos).'
                : "Credenciales inválidas. Intento $attempts de 3. Te quedan $restantes intentos antes de bloquear la cuenta."
        ];
    }

    if ((int)($row['failed_attempts'] ?? 0) > 0 || !empty($row['locked_until'])) {
        db_exec(
            'UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE user_id = :id',
            [':id' => (int)$row['user_id']]
        );
    }

    session_regenerate_id(true);

    $_SESSION['user'] = [
        'id'         => (int)$row['user_id'],
        'name'       => trim($row['firstname'] . ' ' . $row['lastname']),
        'username'   => $row['user_name'],
        'email'      => $row['user_email'],
        'role'       => $row['role'],
        'login_time' => time(),
    ];

    audit_log('LOGIN_OK', 'auth', (int)$row['user_id']);

    return ['ok' => true, 'msg' => 'Acceso concedido.', 'redirect' => 'dashboard'];
}

function logout(): void {
    if (is_logged_in()) {
        audit_log('LOGOUT', 'auth', (int)(current_user()['id'] ?? 0));
    }

    $_SESSION = [];

    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }

    session_destroy();
}

function session_expired(int $minutes = 120): bool {
    if (!is_logged_in()) {
        return false;
    }

    $t = $_SESSION['user']['login_time'] ?? 0;
    return (time() - (int)$t) > ($minutes * 60);
}