<?php
/**
 * Bitácora / Auditoría
 */

declare(strict_types=1);

if (!function_exists('audit_log')) {
function audit_log(string $action, string $entity = '', ?int $entityId = null, array $details = []): void {
    try {
        $u = current_user();
        $uid = $u['id'] ?? null;
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        db_exec(
            'INSERT INTO audit_logs (user_id, action, entity, entity_id, ip, user_agent, details_json, created_at)
             VALUES (:uid, :a, :e, :eid, :ip, :ua, :dj, NOW())',
            [
                ':uid' => $uid,
                ':a' => $action,
                ':e' => $entity,
                ':eid' => $entityId,
                ':ip' => $ip,
                ':ua' => mb_substr($ua, 0, 255),
                ':dj' => json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ]
        );
    } catch (Throwable $e) {
        // No romper el flujo por fallos de logging
    }
}

}
