<?php
/**
 * Funciones Generales del Sistema
 * Perfumería Augusto Caldera
 */

/**
 * Redirige a una URL con mensaje opcional
 * @param string $url URL a la que redirigir
 * @param string $mensaje Mensaje a mostrar (opcional)
 * @param string $tipo Tipo de mensaje: success, error, warning, info
 */
function redirigir($url, $mensaje = '', $tipo = 'info')
{
    if (!empty($mensaje)) {
        $_SESSION['flash_mensaje'] = $mensaje;
        $_SESSION['flash_tipo'] = $tipo;
    }
    header("Location: $url");
    exit;
}

/**
 * Obtiene y limpia el mensaje flash de la sesión
 * @return array ['mensaje' => string, 'tipo' => string] o null si no hay mensaje
 */
function obtener_flash()
{
    if (isset($_SESSION['flash_mensaje'])) {
        $flash = [
            'mensaje' => $_SESSION['flash_mensaje'],
            'tipo' => $_SESSION['flash_tipo'] ?? 'info'
        ];
        unset($_SESSION['flash_mensaje']);
        unset($_SESSION['flash_tipo']);
        return $flash;
    }
    return null;
}

/**
 * Formatea un número como precio
 * @param float $precio Precio a formatear
 * @param string $moneda Símbolo de moneda (default: $)
 * @return string Precio formateado
 */
function formatear_precio($precio, $moneda = '$')
{
    return $moneda . number_format(floatval($precio), 2, '.', ',');
}

/**
 * Formatea una fecha en formato español
 * @param string $fecha Fecha en formato Y-m-d o timestamp
 * @param string $formato Formato de salida (default: d/m/Y)
 * @return string Fecha formateada
 */
function formatear_fecha($fecha, $formato = 'd/m/Y')
{
    if (is_numeric($fecha)) {
        return date($formato, $fecha);
    }
    return date($formato, strtotime($fecha));
}

/**
 * Genera un código único alfanumérico
 * @param int $longitud Longitud del código
 * @param string $prefijo Prefijo opcional
 * @return string Código generado
 */
function generar_codigo($longitud = 8, $prefijo = '')
{
    $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $codigo = '';
    for ($i = 0; $i < $longitud; $i++) {
        $codigo .= $caracteres[rand(0, strlen($caracteres) - 1)];
    }
    return $prefijo . $codigo;
}

/**
 * Agrupa un array de elementos, por una clave
 * @param array $array Array a agrupar
 * @param string $clave Clave por la que agrupar
 * @return array Array agrupado
 */
function agrupar_por($array, $clave)
{
    $agrupado = [];
    foreach ($array as $elemento) {
        if (isset($elemento[$clave])) {
            $agrupado[$elemento[$clave]][] = $elemento;
        }
    }
    return $agrupado;
}

/**
 * Determina el estado de un producto basado en su stock
 * @param int $stock Cantidad en stock
 * @param int $minimo Stock mínimo (default: 5)
 * @return string 'disponible', 'bajo' o 'agotado'
 */
function determinar_estado_stock($stock, $minimo = 5)
{
    if ($stock <= 0) {
        return 'agotado';
    }
    elseif ($stock <= $minimo) {
        return 'bajo';
    }
    else {
        return 'disponible';
    }
}

/**
 * Convierte un array asociativo a atributos HTML
 * @param array $atributos Array de atributos
 * @return string Atributos HTML string
 */
function array_a_atributos($atributos)
{
    $html = [];
    foreach ($atributos as $clave => $valor) {
        if ($valor === true) {
            $html[] = sanitizar_texto($clave);
        }
        elseif ($valor !== false && $valor !== null) {
            $html[] = sanitizar_texto($clave) . '="' . sanitizar_texto($valor) . '"';
        }
    }
    return implode(' ', $html);
}

/**
 * Trunca un texto a una longitud específica
 * @param string $texto Texto a truncar
 * @param int $longitud Longitud máxima
 * @param string $sufijo Sufijo a añadir (default: ...)
 * @return string Texto truncado
 */
function truncar_texto($texto, $longitud = 100, $sufijo = '...')
{
    if (strlen($texto) <= $longitud) {
        return $texto;
    }
    return substr($texto, 0, $longitud) . $sufijo;
}

/**
 * Debug helper - imprime datos de forma legible (solo en desarrollo)
 * @param mixed $datos Datos a imprimir
 * @param bool $terminar Si debe terminar la ejecución
 */
function debug($datos, $terminar = false)
{
    if (APP_ENV === 'development') {
        echo '<pre style="background:#f0f0f0;padding:10px;border:1px solid #ccc;margin:10px;font-family:monospace;font-size:12px;">';
        print_r($datos);
        echo '</pre>';
        if ($terminar) {
            die();
        }
    }
}
