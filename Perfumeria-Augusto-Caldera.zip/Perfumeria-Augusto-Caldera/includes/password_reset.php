<?php
/**
 * Recuperación de contraseña 
 */

declare(strict_types=1);

function mail_send(string $to, string $subject, string $body): bool {
    if (!is_dir(BASE_PATH . '/logs')) {
        @mkdir(BASE_PATH . '/logs', 0775, true);
    }

    if (MAIL_MODE === 'mail') {
        return @mail($to, $subject, $body);
    }

   
    $line = "[" . date('Y-m-d H:i:s') . "] To: {$to} | {$subject}\n{$body}\n\n";
    file_put_contents(BASE_PATH . '/logs/email.log', $line, FILE_APPEND);
    return true;
}

function password_reset_create(int $userId): string {
    $token = bin2hex(random_bytes(32));
    $tokenHash = hash('sha256', $token);
    db_exec('DELETE FROM password_resets WHERE user_id = :uid', [':uid' => $userId]);
    db_exec(
        'INSERT INTO password_resets (user_id, token_hash, expires_at, used_at, created_at)
         VALUES (:uid, :th, DATE_ADD(NOW(), INTERVAL 30 MINUTE), NULL, NOW())',
        [':uid' => $userId, ':th' => $tokenHash]
    );
    return $token;
}

function password_reset_verify(string $token): ?array {
    $token = trim($token);
    if ($token === '') return null;
    $h = hash('sha256', $token);
    $row = db_one(
        'SELECT pr.id, pr.user_id, pr.expires_at, pr.used_at, u.user_email
         FROM password_resets pr
         JOIN users u ON u.user_id = pr.user_id
         WHERE pr.token_hash = :h LIMIT 1',
        [':h' => $h]
    );
    if (!$row) return null;
    if (!empty($row['used_at'])) return null;
    if (strtotime($row['expires_at']) < time()) return null;
    return $row;
}

function password_reset_mark_used(int $resetId): void {
    db_exec('UPDATE password_resets SET used_at = NOW() WHERE id = :id', [':id' => $resetId]);
}
