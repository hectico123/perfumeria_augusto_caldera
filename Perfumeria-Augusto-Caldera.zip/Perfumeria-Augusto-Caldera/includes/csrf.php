<?php

declare(strict_types=1);

function csrf_token(): string {
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

function csrf_field(): string {
    // Compatibilidad: algunos formularios pueden usar "csrf_token".
    // Mantenemos _csrf como estándar, pero aceptaremos ambos en csrf_verify().
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_verify(): void {
    if (!is_post()) return;
    // Aceptar ambos nombres de campo para evitar fallos por inconsistencias en formularios.
    $sent = $_POST['_csrf'] ?? ($_POST['csrf_token'] ?? '');
    $valid = $_SESSION['_csrf'] ?? '';
    if (!$sent || !$valid || !hash_equals($valid, (string)$sent)) {
        // Respuesta amigable para UI (y útil en demo).
        if (function_exists('flash_set')) {
            flash_set('danger', 'CSRF token inválido o expirado. Refresca la página e intenta de nuevo.');
        }

        // Si es una petición AJAX, devolver JSON.
        $isAjax = (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest')
            || (str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json'));
        if ($isAjax) {
            http_response_code(419);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => 'CSRF token inválido o expirado.']);
            exit;
        }

        // Volver a la página anterior si existe.
        $fallback = 'dashboard.php';
        $ref = $_SERVER['HTTP_REFERER'] ?? '';
        if ($ref) {
            $parsed = parse_url($ref);
            $path = $parsed['path'] ?? '';
            if ($path) {
                $basePath = parse_url(defined('BASE_URL') ? BASE_URL : '', PHP_URL_PATH) ?: '';
                $rel = $basePath && str_starts_with($path, $basePath) ? substr($path, strlen($basePath)) : ltrim($path, '/');
                if ($rel !== '') {
                    redirect($rel);
                }
            }
        }

        redirect($fallback);
    }
}
