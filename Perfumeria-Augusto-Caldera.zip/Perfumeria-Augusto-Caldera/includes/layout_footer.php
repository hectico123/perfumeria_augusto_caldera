
      <div class="modal fade" id="logoutModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Cerrar sesión</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
              ¿Estás seguro de cerrar sesión?
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>

              <form method="POST" action="<?= e(BASE_URL) ?>logout">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-danger">Sí, cerrar sesión</button>
              </form>
            </div>
          </div>
        </div>
      </div>

    </main>
                <footer class="app-footer">
            Perfumería Augusto Caldera · Sistema de Inventario · v<?= e(APP_VERSION ?? '1.0') ?>
        </footer>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>