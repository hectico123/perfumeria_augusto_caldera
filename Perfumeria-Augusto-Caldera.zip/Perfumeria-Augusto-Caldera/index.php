<?php

declare(strict_types=1);

require_once __DIR__ . '/config/config.php';
require_once BASE_PATH . '/app/Core/Router.php';
require_once BASE_PATH . '/app/Core/View.php';
require_once BASE_PATH . '/app/Support/dispatcher.php';

use App\Core\Router;

$router = new Router();

$router->match(['GET', 'POST'], '', fn() => dispatch_page('login', 'login', false));
$router->match(['GET', 'POST'], 'login', fn() => dispatch_page('login', 'login', false));
$router->match(['GET', 'POST'], 'forgot-password', fn() => dispatch_page('forgot_password', 'forgot_password', false));
$router->match(['GET', 'POST'], 'reset-password', fn() => dispatch_controller_only('reset_password'));

$router->match(['GET', 'POST'], 'dashboard', fn() => dispatch_page('dashboard', 'dashboard'));
$router->match(['GET', 'POST'], 'categorias', fn() => dispatch_page('categorias', 'categorias'));
$router->match(['GET', 'POST'], 'productos', fn() => dispatch_page('productos', 'productos'));
$router->match(['GET', 'POST'], 'movimientos', fn() => dispatch_page('movimientos', 'movimientos'));
$router->match(['GET', 'POST'], 'usuarios', fn() => dispatch_page('usuarios', 'usuarios'));
$router->match(['GET', 'POST'], 'usuarios/eliminar', fn() => dispatch_page('usuarios_delete', 'usuarios_delete'));
$router->match(['GET', 'POST'], 'configuracion', fn() => dispatch_page('configuracion', 'configuracion'));
$router->match(['GET', 'POST'], 'auditoria', fn() => dispatch_page('auditoria', 'auditoria'));
$router->match(['GET', 'POST'], 'export', fn() => dispatch_controller_only('export'));
$router->match(['GET', 'POST'], 'logout', fn() => dispatch_controller_only('logout'));

$route = resolve_route_from_request();
$router->dispatch($route, $_SERVER['REQUEST_METHOD'] ?? 'GET');
