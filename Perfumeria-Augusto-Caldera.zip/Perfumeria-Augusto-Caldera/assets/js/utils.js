/**
 * Utilidades JavaScript
 * Perfumería Augusto Caldera - Sistema de Inventario
 * 
 * IMPORTANTE: Este archivo contiene SOLO funciones de UI/UX
 * NO debe contener lógica de negocio
 */

// Sistema de Modales
const Modal = {
    open(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
        }
    },

    close(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
        }
    },

    toggle(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.toggle('active');
        }
    }
};

// Formateo visual de números (NO hace cálculos)
const Format = {
    /**
     * Formatea un número para display visual
     * @param {number} num - Número a formatear
     * @param {number} decimales - Decimales a mostrar
     * @returns {string} Número formateado
     */
    number(num, decimales = 2) {
        return parseFloat(num).toLocaleString('es-VE', {
            minimumFractionDigits: decimales,
            maximumFractionDigits: decimales
        });
    },

    /**
     * Formatea un precio para display (solo visual)
     * @param {number} precio - Precio a formatear
     * @param {string} moneda - Símbolo de moneda
     * @returns {string} Precio formateado
     */
    precio(precio, moneda = '$') {
        return moneda + this.number(precio, 2);
    },

    /**
     * Formatea una fecha para display
     * @param {string|Date} fecha - Fecha a formatear
     * @returns {string} Fecha formateada
     */
    fecha(fecha) {
        const date = new Date(fecha);
        return date.toLocaleDateString('es-VE');
    }
};

// Utilidades de DOM (solo manipulación visual)
const DOM = {
    /**
     * Muestra un elemento
     * @param {string} elementId - ID del elemento
     */
    show(elementId) {
        const el = document.getElementById(elementId);
        if (el) el.classList.remove('hidden');
    },

    /**
     * Oculta un elemento
     * @param {string} elementId - ID del elemento
     */
    hide(elementId) {
        const el = document.getElementById(elementId);
        if (el) el.classList.add('hidden');
    },

    /**
     * Toggle visibilidad de un elemento
     * @param {string} elementId - ID del elemento
     */
    toggle(elementId) {
        const el = document.getElementById(elementId);
        if (el) el.classList.toggle('hidden');
    },

    /**
     * Habilita un elemento (quita disabled)
     * @param {string} elementId - ID del elemento
     */
    enable(elementId) {
        const el = document.getElementById(elementId);
        if (el) el.disabled = false;
    },

    /**
     * Deshabilita un elemento
     * @param {string} elementId - ID del elemento
     */
    disable(elementId) {
        const el = document.getElementById(elementId);
        if (el) el.disabled = true;
    }
};

// Validaciones de UI (solo feedback visual, no seguridad)
const Validation = {
    /**
     * Valida un email (solo para UX feedback)
     * NOTA: La validación real DEBE hacerse en PHP
     * @param {string} email - Email a validar
     * @returns {boolean}
     */
    email(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    },

    /**
     * Valida que un campo no esté vacío (solo UX)
     * @param {string} value - Valor a validar
     * @returns {boolean}
     */
    required(value) {
        return value !== null && value !== undefined && value.trim() !== '';
    },

    /**
     * Valida longitud mínima (solo UX)
     * @param {string} value - Valor a validar
     * @param {number} min - Longitud mínima
     * @returns {boolean}
     */
    minLength(value, min) {
        return value.length >= min;
    },

    /**
     * Valida que sea un número (solo UX)
     * @param {string} value - Valor a validar
     * @returns {boolean}
     */
    isNumber(value) {
        return !isNaN(parseFloat(value)) && isFinite(value);
    },

    /**
     * Muestra error visual en un campo
     * @param {string} fieldId - ID del campo
     * @param {string} message - Mensaje de error
     */
    showError(fieldId, message) {
        const field = document.getElementById(fieldId);
        if (!field) return;

        field.classList.add('error');

        // Remover error anterior si existe
        const existingError = field.parentElement.querySelector('.error-message');
        if (existingError) existingError.remove();

        // Agregar nuevo mensaje
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        errorDiv.style.color = 'var(--destructive)';
        errorDiv.style.fontSize = '0.75rem';
        errorDiv.style.marginTop = '0.25rem';
        field.parentElement.appendChild(errorDiv);
    },

    /**
     * Limpia el error visual de un campo
     * @param {string} fieldId - ID del campo
     */
    clearError(fieldId) {
        const field = document.getElementById(fieldId);
        if (!field) return;

        field.classList.remove('error');
        const errorMsg = field.parentElement.querySelector('.error-message');
        if (errorMsg) errorMsg.remove();
    }
};

// Utilidades de animación (solo visual)
const Animate = {
    /**
     * Hace scroll suave a un elemento
     * @param {string} elementId - ID del elemento
     */
    scrollTo(elementId) {
        const element = document.getElementById(elementId);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    },

    /**
     * Anima un elemento con shake (útil para errores)
     * @param {string} elementId - ID del elemento
     */
    shake(elementId) {
        const element = document.getElementById(elementId);
        if (!element) return;

        element.style.animation = 'shake 0.3s ease-in-out';
        setTimeout(() => {
            element.style.animation = '';
        }, 300);
    }
};

// Exportar para uso global
if (typeof window !== 'undefined') {
    window.Modal = Modal;
    window.Format = Format;
    window.DOM = DOM;
    window.Validation = Validation;
    window.Animate = Animate;
}

// CSS para animaciones (inyectar en head si no existe)
if (typeof document !== 'undefined') {
    const styleId = 'utils-animations';
    if (!document.getElementById(styleId)) {
        const style = document.createElement('style');
        style.id = styleId;
        style.textContent = `
            @keyframes shake {
                0%, 100% { transform: translateX(0); }
                25% { transform: translateX(-10px); }
                75% { transform: translateX(10px); }
            }
            .error {
                border-color: var(--destructive) !important;
            }
        `;
        document.head.appendChild(style);
    }
}
