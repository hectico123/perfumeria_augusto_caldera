/**
 * Sistema de Toasts/Notificaciones
 * Perfumería Augusto Caldera
 * 
 * IMPORTANTE: Solo muestra mensajes, no procesa lógica de negocio
 */

const Toast = {
    container: null,

    /**
     * Inicializa el contenedor de toasts
     */
    init() {
        if (this.container) return;

        this.container = document.createElement('div');
        this.container.id = 'toast-container';
        this.container.style.cssText = `
            position: fixed;
            top: 1rem;
            right: 1rem;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            pointer-events: none;
        `;
        document.body.appendChild(this.container);
    },

    /**
     * Muestra un toast
     * @param {string} message - Mensaje a mostrar
     * @param {string} type - Tipo: success, error, warning, info
     * @param {number} duration - Duración en ms (default 3000)
     */
    show(message, type = 'info', duration = 3000) {
        this.init();

        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;

        // Estilos del toast
        const colors = {
            success: { bg: '#f0fdf4', border: '#22c55e', text: '#15803d' },
            error: { bg: '#fef2f2', border: '#dc2626', text: '#991b1b' },
            warning: { bg: '#fef3c7', border: '#f59e0b', text: '#92400e' },
            info: { bg: '#f0f9ff', border: '#3b82f6', text: '#1e40af' }
        };

        const color = colors[type] || colors.info;

        toast.style.cssText = `
            background: ${color.bg};
            border-left: 4px solid ${color.border};
            color: ${color.text};
            padding: 1rem 1.5rem;
            border-radius: 0.5rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            min-width: 300px;
            max-width: 400px;
            pointer-events: auto;
            animation: slideIn 0.3s ease-out;
            font-size: 0.875rem;
            font-weight: 500;
        `;

        toast.textContent = message;

        this.container.appendChild(toast);

        // Auto-remover después de la duración
        setTimeout(() => {
            toast.style.animation = 'slideOut 0.3s ease-out';
            setTimeout(() => toast.remove(), 300);
        }, duration);

        return toast;
    },

    /**
     * Toast de éxito
     * @param {string} message - Mensaje
     * @param {number} duration - Duración
     */
    success(message, duration = 3000) {
        return this.show(message, 'success', duration);
    },

    /**
     * Toast de error
     * @param {string} message - Mensaje
     * @param {number} duration - Duración
     */
    error(message, duration = 4000) {
        return this.show(message, 'error', duration);
    },

    /**
     * Toast de advertencia
     * @param {string} message - Mensaje
     * @param {number} duration - Duración
     */
    warning(message, duration = 3500) {
        return this.show(message, 'warning', duration);
    },

    /**
     * Toast de info
     * @param {string} message - Mensaje
     * @param {number} duration - Duración
     */
    info(message, duration = 3000) {
        return this.show(message, 'info', duration);
    }
};

// CSS de animaciones
if (typeof document !== 'undefined') {
    const styleId = 'toast-animations';
    if (!document.getElementById(styleId)) {
        const style = document.createElement('style');
        style.id = styleId;
        style.textContent = `
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            @keyframes slideOut {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }
}

// Exportar
if (typeof window !== 'undefined') {
    window.Toast = Toast;
}
