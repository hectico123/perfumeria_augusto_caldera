/**
 * Sistema de Modales Mejorado
 * Perfumería Augusto Caldera
 * 
 * Funcionalidad extendida para modales
 */

// Cerrar modales automáticamente al hacer click fuera
document.addEventListener('DOMContentLoaded', function () {
    // Cerrar modal al hacer click en el overlay
    document.addEventListener('click', function (event) {
        if (event.target.classList.contains('modal')) {
            event.target.classList.remove('active');
        }
    });

    // Cerrar modal con la tecla ESC
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            const activeModals = document.querySelectorAll('.modal.active');
            activeModals.forEach(modal => modal.classList.remove('active'));
        }
    });

    // Prevenir scroll del body cuando hay modal activo
    const observer = new MutationObserver(function (mutations) {
        const hasActiveModal = document.querySelector('.modal.active') !== null;
        if (hasActiveModal) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
    });

    observer.observe(document.body, {
        attributes: true,
        subtree: true,
        attributeFilter: ['class']
    });
});
