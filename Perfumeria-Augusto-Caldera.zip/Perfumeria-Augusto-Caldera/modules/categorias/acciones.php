<?php
/**
 * Acciones CRUD para Categorías
 * Perfumería Augusto Caldera - Sistema de Inventario
 */

// Cargar configuración
require_once '../../config/config.php';

// Verificar autenticación
requiere_autenticacion('../../index.php');

// Obtener la acción
$accion = $_GET['accion'] ?? $_POST['accion'] ?? '';

// Procesar según la acción
switch ($accion) {
    case 'crear':
        // Obtener y sanitizar datos
        $datos = [
            'nombre' => $_POST['nombre'] ?? '',
            'descripcion' => $_POST['descripcion'] ?? ''
        ];

        // Validar
        $errores = validar_categoria($datos);

        if (empty($errores)) {
            // TODO: Guardar en base de datos
            // Por ahora solo simulamos
            redirigir('index.php', 'Categoría creada correctamente', 'success');
        }
        else {
            // Hay errores de validación
            $mensaje_errores = implode(', ', $errores);
            redirigir('index.php', 'Error: ' . $mensaje_errores, 'error');
        }
        break;

    case 'editar':
        // Obtener y sanitizar datos
        $id = $_POST['categoria_id'] ?? 0;
        $datos = [
            'nombre' => $_POST['nombre_editar'] ?? '',
            'descripcion' => $_POST['descripcion_editar'] ?? ''
        ];

        // Validar
        $errores = validar_categoria($datos);

        if (empty($errores)) {
            // TODO: Actualizar en base de datos
            redirigir('index.php', 'Categoría actualizada correctamente', 'success');
        }
        else {
            $mensaje_errores = implode(', ', $errores);
            redirigir('index.php', 'Error: ' . $mensaje_errores, 'error');
        }
        break;

    case 'eliminar':
        $id = $_GET['id'] ?? 0;

        if ($id > 0) {
            // TODO: Eliminar de base de datos
            redirigir('index.php', 'Categoría eliminada correctamente', 'success');
        }
        else {
            redirigir('index.php', 'ID de categoría inválido', 'error');
        }
        break;

    default:
        redirigir('index.php', 'Acción no válida', 'error');
}
