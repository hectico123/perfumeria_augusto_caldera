<?php
require_once __DIR__ . '/config/config.php';
$page = 'Productos';
$active = 'productos';

/* =========================
   TASA
========================= */
$rateRow = db_one("SELECT setting_value FROM settings WHERE setting_key='usd_to_ves' LIMIT 1");
$usd_to_ves = $rateRow ? (float)$rateRow['setting_value'] : 0.0;

/* =========================
   HELPERS FORM
========================= */
function product_old_set(array $data): void {
    $_SESSION['_product_old_input'] = $data;
}

function product_old_get(): array {
    return $_SESSION['_product_old_input'] ?? [];
}

function product_old_clear(): void {
    unset($_SESSION['_product_old_input']);
}

function product_form_value(array $old, ?array $edit, string $key, string $default = ''): string {
    return (string)($old[$key] ?? $edit[$key] ?? $default);
}

/* =========================
   ACCIONES POST
========================= */
if (is_post()) {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $id = (int)($_POST['id_producto'] ?? 0);
        $codigo = trim((string)($_POST['codigo_producto'] ?? ''));
        $nombre = trim((string)($_POST['nombre_producto'] ?? ''));
        $precio = (float)($_POST['precio_usd'] ?? 0);
        $stock = (int)($_POST['stock'] ?? 0);
        $min = (int)($_POST['stock_min'] ?? 5);
        $cat = (int)($_POST['id_categoria'] ?? 0);

        $redirectUrl = $action === 'update' ? 'productos.php?edit=' . $id : 'productos.php';

        product_old_set([
            'id_producto'      => (string)$id,
            'codigo_producto'  => $codigo,
            'nombre_producto'  => $nombre,
            'precio_usd'       => (string)$precio,
            'stock'            => (string)$stock,
            'stock_min'        => (string)$min,
            'id_categoria'     => (string)$cat,
        ]);

        if ($codigo === '' || $nombre === '' || $cat <= 0) {
            flash_set('danger', 'Completa código, nombre y categoría.');
            redirect($redirectUrl);
        }

        if (mb_strlen($codigo) > 20) {
            flash_set('danger', 'El código no puede superar 20 caracteres.');
            redirect($redirectUrl);
        }

        if (!preg_match('/^[A-Za-z0-9_-]+$/', $codigo)) {
            flash_set('danger', 'El código solo puede contener letras, números, guion y guion bajo.');
            redirect($redirectUrl);
        }

        if ($precio < 0) {
            flash_set('danger', 'El precio no puede ser negativo.');
            redirect($redirectUrl);
        }

        if ($stock < 0) {
            flash_set('danger', 'El stock no puede ser negativo.');
            redirect($redirectUrl);
        }

        if ($min < 0) {
            flash_set('danger', 'El stock mínimo no puede ser negativo.');
            redirect($redirectUrl);
        }

        $dupCode = db_one(
            'SELECT id_producto 
             FROM products 
             WHERE codigo_producto = :c AND id_producto <> :id 
             LIMIT 1',
            [
                ':c'  => $codigo,
                ':id' => $id
            ]
        );

        if ($dupCode) {
            flash_set('danger', 'Ya existe un producto con ese código.');
            redirect($redirectUrl);
        }

        if ($action === 'create') {
            db_exec(
                'INSERT INTO products (
                    codigo_producto,
                    nombre_producto,
                    precio_usd,
                    stock,
                    stock_min,
                    id_categoria,
                    date_added
                 ) VALUES (
                    :c, :n, :p, :s, :m, :cat, NOW()
                 )',
                [
                    ':c'   => $codigo,
                    ':n'   => $nombre,
                    ':p'   => $precio,
                    ':s'   => $stock,
                    ':m'   => $min,
                    ':cat' => $cat
                ]
            );

            $newId = db_last_id();

            db_exec(
                'INSERT INTO movimientos (
                    tipo,
                    id_producto,
                    cantidad,
                    stock_antes,
                    stock_despues,
                    referencia,
                    observacion,
                    user_id,
                    created_at
                 ) VALUES (
                    :t, :pid, :c, :sa, :sd, :r, :o, :uid, NOW()
                 )',
                [
                    ':t'   => 'ENTRADA',
                    ':pid' => $newId,
                    ':c'   => $stock,
                    ':sa'  => 0,
                    ':sd'  => $stock,
                    ':r'   => 'REGISTRO_PRODUCTO',
                    ':o'   => 'Alta de producto',
                    ':uid' => (int)(current_user()['id'] ?? 0),
                ]
            );

            audit_log('PRODUCT_CREATE', 'product', $newId, [
                'codigo_producto' => $codigo,
                'nombre_producto' => $nombre,
                'precio_usd'      => $precio,
                'stock'           => $stock,
                'stock_min'       => $min,
                'id_categoria'    => $cat,
            ]);

            product_old_clear();
            flash_set('success', 'Producto creado.');
            redirect('productos.php');
        }

        db_exec(
            'UPDATE products
             SET codigo_producto = :c,
                 nombre_producto = :n,
                 precio_usd = :p,
                 stock = :s,
                 stock_min = :m,
                 id_categoria = :cat
             WHERE id_producto = :id',
            [
                ':c'   => $codigo,
                ':n'   => $nombre,
                ':p'   => $precio,
                ':s'   => $stock,
                ':m'   => $min,
                ':cat' => $cat,
                ':id'  => $id
            ]
        );

        audit_log('PRODUCT_UPDATE', 'product', $id, [
            'codigo_producto' => $codigo,
            'nombre_producto' => $nombre,
            'precio_usd'      => $precio,
            'stock'           => $stock,
            'stock_min'       => $min,
            'id_categoria'    => $cat,
        ]);

        product_old_clear();
        flash_set('success', 'Producto actualizado.');
        redirect('productos.php');
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id_producto'] ?? 0);

        $p = db_one(
            'SELECT codigo_producto, nombre_producto 
             FROM products 
             WHERE id_producto = :id',
            [':id' => $id]
        );

        if ($p) {
            db_exec('DELETE FROM movimientos WHERE id_producto = :id', [':id' => $id]);
            db_exec('DELETE FROM products WHERE id_producto = :id', [':id' => $id]);

            audit_log('PRODUCT_DELETE', 'product', $id, [
                'codigo_producto' => $p['codigo_producto'] ?? null,
                'nombre_producto' => $p['nombre_producto'] ?? null,
            ]);

            flash_set('success', 'Producto y su historial eliminados correctamente.');
        } else {
            flash_set('danger', 'El producto no existe.');
        }

        redirect('productos.php');
    }
}

/* =========================
   DATOS PARA LA VISTA
========================= */
$categorias = db_all(
    'SELECT id_categoria, nombre_categoria
     FROM categorias
     ORDER BY nombre_categoria ASC'
);

$buscar = trim((string)($_GET['buscar'] ?? ''));
$params = [];
$where = '';

if ($buscar !== '') {
    $where = 'WHERE p.nombre_producto LIKE :q1 
              OR p.codigo_producto LIKE :q2 
              OR c.nombre_categoria LIKE :q3';

    $like = '%' . $buscar . '%';

    $params = [
        ':q1' => $like,
        ':q2' => $like,
        ':q3' => $like
    ];
}

$productos = db_all(
    "SELECT p.*, c.nombre_categoria
     FROM products p
     LEFT JOIN categorias c ON c.id_categoria = p.id_categoria
     $where
     ORDER BY p.id_producto DESC",
    $params
);

$edit_id = (int)($_GET['edit'] ?? 0);
$edit = null;

if ($edit_id > 0) {
    $edit = db_one(
        'SELECT * FROM products WHERE id_producto = :id',
        [':id' => $edit_id]
    );
}

$old = product_old_get();
product_old_clear();

$currentCategoria = (int)($old['id_categoria'] ?? ($edit['id_categoria'] ?? 0));

require_once __DIR__ . '/includes/layout.php';
?>

<div class="row g-3">

  <!-- ===================== FORMULARIO ===================== -->
  <div class="col-12 col-lg-4">
    <div class="card stat-card primary h-100">

      <div class="card-header form-header">
        <h5 class="card-title mb-0">
          <i class="bi bi-box-seam me-2"></i>
          <?= $edit ? 'Editar producto' : 'Nuevo producto' ?>
        </h5>
      </div>

      <div class="card-body">

        <form method="POST">
          <?= csrf_field() ?>

          <input type="hidden" name="action" value="<?= $edit ? 'update' : 'create' ?>">
          <input type="hidden" name="id_producto" value="<?= e((string)($edit['id_producto'] ?? 0)) ?>">

          <div class="mb-3">
            <label class="form-label">Código</label>
            <input
              class="form-control form-modern"
              name="codigo_producto"
              maxlength="20"
              required
              placeholder="Ej: PRD-001"
              value="<?= e(product_form_value($old, $edit, 'codigo_producto')) ?>">
            <div class="form-text">Máx. 20 caracteres</div>
          </div>

          <div class="mb-3">
            <label class="form-label">Nombre<span style="color:#dc2626">*</span></label>
            <input
              class="form-control form-modern"
              name="nombre_producto"
              maxlength="40"
              required
              placeholder="Ej: Perfume floral"
              oninput="this.value=this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñÜü ]/g,'');"
              value="<?= e(product_form_value($old, $edit, 'nombre_producto')) ?>">
              <div class="form-text">Máx. 40 caracteres</div>
          </div>

          <div class="row g-2">
            <div class="col-6">
              <label class="form-label">Precio (USD)</label>
              <input
                class="form-control form-modern"
                name="precio_usd"
                type="number"
                step="0.01"
                min="0"
                value="<?= e(product_form_value($old, $edit, 'precio_usd', '0')) ?>">
            </div>

            <div class="col-6">
              <label class="form-label">Stock</label>
              <input
                class="form-control form-modern"
                name="stock"
                type="number"
                step="1"
                min="0"
                value="<?= e(product_form_value($old, $edit, 'stock', '0')) ?>">
            </div>
          </div>

          <div class="row g-2 mt-1">
            <div class="col-6">
              <label class="form-label">Stock mín.</label>
              <input
                class="form-control form-modern"
                name="stock_min"
                type="number"
                step="1"
                min="0"
                value="<?= e(product_form_value($old, $edit, 'stock_min', '5')) ?>">
            </div>

            <div class="col-6">
              <label class="form-label">Categoría</label>
              <select class="form-select form-modern" name="id_categoria" required>
                <option value="">Selecciona</option>
                <?php foreach ($categorias as $c): ?>
                  <option
                    value="<?= e((string)$c['id_categoria']) ?>"
                    <?= $currentCategoria === (int)$c['id_categoria'] ? 'selected' : '' ?>>
                    <?= e($c['nombre_categoria']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="form-actions mt-3">
            <button class="btn btn-save" type="submit">
              <i class="bi bi-check-lg"></i>
              <?= $edit ? 'Guardar cambios' : 'Crear producto' ?>
            </button>

            <?php if ($edit): ?>
              <a class="btn btn-cancel" href="productos.php">Cancelar</a>
            <?php endif; ?>
          </div>
        </form>

        <hr>

        <div class="small text-muted">
          Tasa actual:
          <b><?= $usd_to_ves > 0 ? e(number_format($usd_to_ves, 2, '.', ',')) : 'No configurada' ?></b>
        </div>

      </div>
    </div>
  </div>

  <!-- ===================== TABLA ===================== -->
  <div class="col-12 col-lg-8">
    <div class="card stat-card primary table-card h-100">

      <div class="card-header table-header">
        <div>
          <h5 class="card-title mb-1">Listado de productos</h5>
          <small class="text-muted">Indicador: stock ≤ mínimo</small>
        </div>

        <a class="btn btn-outline-success btn-sm" href="export.php?type=products">
          <i class="bi bi-file-earmark-excel"></i> Exportar
        </a>
      </div>

      <!-- BUSCADOR -->
      <form class="table-search m-3" method="GET">
        <div class="search-bar">

          <div class="search-input-wrap">
            <i class="bi bi-search search-icon"></i>

            <input
              class="form-control search-input"
              name="buscar"
              maxlength="40"
              placeholder="Buscar por código, producto o categoría"
              value="<?= e($buscar) ?>">

            <?php if (!empty($buscar)): ?>
              <a href="productos.php" class="clear-search" title="Limpiar">
                <i class="bi bi-x"></i>
              </a>
            <?php endif; ?>
          </div>

          <div class="search-actions">
            <button class="btn btn-search" type="submit">
              <i class="bi bi-search"></i>
              Buscar
            </button>

            <a class="btn btn-refresh" href="productos.php">
              <i class="bi bi-arrow-clockwise"></i>
            </a>
          </div>

        </div>
      </form>

      <div class="card-body">

        <div class="table-responsive table-modern">
          <table class="table align-middle mb-0">

            <thead>
              <tr>
                <th>Código</th>
                <th>Producto</th>
                <th>Estado</th>
                <th>Categoría</th>
                <th>Stock</th>
                <th>USD</th>
                <th>Bs</th>
                <th style="width:160px;">Acciones</th>
              </tr>
            </thead>

            <tbody>
              <?php if (!$productos): ?>
                <tr>
                  <td colspan="8" class="text-center text-muted py-4">
                    No hay productos
                  </td>
                </tr>
              <?php else: foreach ($productos as $p):

                $stockActual = (int)$p['stock'];
                $stockMinimo = (int)$p['stock_min'];
                $estado = $stockActual <= 0 ? 'agotado' : ($stockActual <= $stockMinimo ? 'bajo' : 'ok');

                $precioUsd = (float)$p['precio_usd'];
                $precioBs = $usd_to_ves > 0 ? $precioUsd * $usd_to_ves : null;
              ?>
                <tr>

                  <td class="text-muted fw-medium"><?= e($p['codigo_producto']) ?></td>

                  <td class="fw-semibold"><?= e($p['nombre_producto']) ?></td>

                  <td>
                    <span class="badge-modern <?= e($estado) ?>">
                      <?= e(strtoupper($estado)) ?>
                    </span>
                  </td>

                  <td><?= e($p['nombre_categoria'] ?? '—') ?></td>

                  <td>
                    <strong><?= e((string)$stockActual) ?></strong>
                    <span class="text-muted"> / mín <?= e((string)$stockMinimo) ?></span>
                  </td>

                  <td>$<?= e(number_format($precioUsd, 2, '.', ',')) ?></td>

                  <td>
                    <?= $precioBs === null ? '—' : 'Bs ' . e(number_format($precioBs, 2, '.', ',')) ?>
                  </td>

                  <td>
                    <div class="table-actions">
                      <a class="btn btn-edit" href="productos.php?edit=<?= e((string)$p['id_producto']) ?>">
                        <i class="bi bi-pencil"></i>
                      </a>

                      <button
                        type="button"
                        class="btn btn-delete btn-delete-product"
                        data-id="<?= e((string)$p['id_producto']) ?>"
                        data-name="<?= e($p['nombre_producto']) ?>"
                        data-bs-toggle="modal"
                        data-bs-target="#deleteProductModal">
                        <i class="bi bi-trash"></i>
                      </button>
                    </div>
                  </td>

                </tr>
              <?php endforeach; endif; ?>
            </tbody>

          </table>
        </div>

      </div>
    </div>
  </div>

</div>

<!-- MODAL ELIMINAR -->
<div class="modal fade" id="deleteProductModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-sm">
    <div class="modal-content modal-delete">

      <div class="modal-header border-0 pb-0">
        <h5 class="modal-title">
          <i class="bi bi-exclamation-triangle text-danger me-2"></i>
          Eliminar producto
        </h5>

        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body text-center pt-2">
        <div class="delete-icon">
          <i class="bi bi-trash"></i>
        </div>

        <p class="mb-1">Vas a eliminar:</p>
        <div class="delete-name" id="deleteProductName">—</div>

        <p class="text-muted small mt-3 mb-0">
          También se eliminará su historial de movimientos.
        </p>
      </div>

      <div class="modal-footer border-0 pt-0 justify-content-center">
        <button type="button" class="btn btn-cancel" data-bs-dismiss="modal">
          Cancelar
        </button>

        <form method="POST">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="id_producto" id="deleteProductId">

          <button class="btn btndeleteconfirm" type="submit">
            Sí, eliminar
          </button>
        </form>
      </div>

    </div>
  </div>
</div>

<script>
document.querySelectorAll('.btn-delete-product').forEach(function (btn) {
  btn.addEventListener('click', function () {
    document.getElementById('deleteProductId').value = this.dataset.id;
    document.getElementById('deleteProductName').textContent = this.dataset.name;
  });
});
</script>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>