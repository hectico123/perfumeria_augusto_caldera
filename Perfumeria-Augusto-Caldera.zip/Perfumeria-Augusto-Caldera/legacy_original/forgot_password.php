<?php
require_once __DIR__ . '/config/config.php';

if (is_logged_in()) {
    redirect('dashboard.php');
}

$step = (int)($_POST['step'] ?? 1);
$identifier = trim($_POST['identifier'] ?? '');
$answer = trim($_POST['answer'] ?? '');
$new1 = (string)($_POST['new_password'] ?? '');
$new2 = (string)($_POST['new_password2'] ?? '');

$question = '';
$user_id = 0;

$ok = '';
$error = '';

if (is_post()) {
    csrf_verify();

    if ($step === 1) {
        if ($identifier === '') {
            $error = 'Ingresa tu usuario o correo.';
        } else {
            $u = db_one("SELECT user_id, user_name, user_email, security_question, security_answer_hash
                        FROM users
                        WHERE is_active=1 AND (user_name=:u1 OR user_email=:u2)
                        LIMIT 1", [':u1'=>$identifier, ':u2'=>$identifier]);

            if (!$u || empty($u['security_question']) || empty($u['security_answer_hash'])) {

                $ok = 'Si la cuenta existe y tiene recuperación configurada, podrás restablecer la contraseña.';
            } else {
                $step = 2;
                $user_id = (int)$u['user_id'];
                $_SESSION['pw_reset_user'] = $user_id;
                $securityquestions = [
    'q_color' => '¿cuál es tu color favorito?',
    'q_pet'   => '¿cuál es el nombre de tu primera mascota?',
    'q_city'  => '¿cuál es tu ciudad de nacimiento?',
    'q_food'  => '¿cuál es tu comida favorita?',
    'q_word'  => '¿cuál es tu palabra clave?'
];

$questioncode = (string)$u['security_question'];
$question = $securityquestions[$questioncode] ?? 'pregunta no disponible';
            }
        }
    } elseif ($step === 2) {
        $user_id = (int)($_SESSION['pw_reset_user'] ?? 0);
        if ($user_id <= 0) {
            $error = 'Sesión de recuperación expirada. Intenta nuevamente.';
            $step = 1;
        } else {
            $u = db_one("SELECT user_id, security_question, security_answer_hash FROM users WHERE user_id=:id AND is_active=1 LIMIT 1",
                        [':id'=>$user_id]);
            if (!$u) {
                $error = 'No se pudo validar la cuenta.';
                $step = 1;
            } else {
                $securityquestions = [
    'q_color' => '¿cuál es tu color favorito?',
    'q_pet'   => '¿cuál es el nombre de tu primera mascota?',
    'q_city'  => '¿cuál es tu ciudad de nacimiento?',
    'q_food'  => '¿cuál es tu comida favorita?',
    'q_word'  => '¿cuál es tu palabra clave?'
];

$questioncode = (string)$u['security_question'];
$question = $securityquestions[$questioncode] ?? 'pregunta no disponible';

                if ($answer === '') {
                    $error = 'Responde la pregunta de seguridad.';
                } elseif (!password_verify($answer, (string)$u['security_answer_hash'])) {
                    $error = 'Respuesta incorrecta.';
                } elseif (strlen($new1) < 16) {
                    $error = 'La contraseña debe tener mínimo 16 caracteres.';
                } elseif ($new1 !== $new2) {
                    $error = 'Las contraseñas no coinciden.';
                } else {
                    $hash = password_hash($new1, PASSWORD_DEFAULT);
                    db_exec("UPDATE users SET user_password_hash=:h WHERE user_id=:id", [':h'=>$hash, ':id'=>$user_id]);
                    audit_log('AUTH', 'password_reset_security_question', $user_id, []);
                    unset($_SESSION['pw_reset_user']);
                    $ok = 'Contraseña actualizada. Ya puedes iniciar sesión.';
                    $step = 1;
                }
            }
        }
    }
}

$flash = flash_get();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recuperar contraseña - <?= e(APP_NAME) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
  <link href="<?= e(ASSETS_URL) ?>css/login.css" rel="stylesheet">
</head>
<body>
  <div class="login-container">
    <!-- Panel izquierdo (solo escritorio) -->
    <div class="login-panel-left d-none d-lg-flex">
      <div class="logo-container">
        <div class="logo-wrapper">
          <img src="<?= e(ASSETS_URL) ?>img/logo.jpeg" alt="Logo">
        </div>
        <div class="login-tagline">
          Recupera tu acceso de forma segura con pregunta de seguridad.
        </div>
      </div>
    </div>

    <!-- Panel derecho -->
    <div class="login-panel-right">
      <div class="w-100" style="max-width:520px;">

        <div class="text-center mb-3 d-lg-none">
          <img src="<?= e(ASSETS_URL) ?>img/logo.jpeg" alt="Logo" style="width:84px;height:84px;object-fit:contain;" class="mb-2">
          <h3 class="h5 mb-0">Perfumería Augusto Caldera</h3>
          <div class="text-muted small">Recuperación de contraseña</div>
        </div>

        <div class="card shadow-sm border-0">
          <div class="card-body p-4 p-md-5">

            <div class="d-flex justify-content-between align-items-center mb-3">
              <div>
                <h4 class="mb-1">Recuperar contraseña</h4>
                <div class="text-muted small">
                  Paso <?= $step === 1 ? '1' : '2' ?> de 2
                </div>
              </div>
              <span class="badge text-bg-light border"><?= $step === 1 ? 'Identificar cuenta' : 'Verificar y cambiar' ?></span>
            </div>

            <?php if (!empty($flash['success'])): ?><div class="alert alert-success"><?= e($flash['success']) ?></div><?php endif; ?>
            <?php if (!empty($flash['error'])): ?><div class="alert alert-danger"><?= e($flash['error']) ?></div><?php endif; ?>
            <?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>
            <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>

            <?php if ($step === 1): ?>
              <p class="text-muted mb-4">
                Ingresa tu usuario o correo. <br>
                <span class="small">Si la cuenta existe y tiene recuperación configurada, podrás restablecer la contraseña.</span>
              </p>
              <form method="post" class="vstack gap-3">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="step" value="1">

                <div>
                  <label class="form-label">Usuario o correo</label>
                  <input type="text" maxlength="20" name="identifier" class="form-control form-control-lg" required value="<?= e($identifier) ?>" autocomplete="username">
                </div>

                <button class="btn btn-primary btn-lg w-100">Continuar</button>

                <div class="text-center mt-2">
                  <a class="text-decoration-none" href="index.php">Volver al inicio</a>
                </div>
              </form>

            <?php else: ?>
              <p class="text-muted mb-4">
                Responde tu pregunta de seguridad y define una nueva contraseña.
              </p>
              <form method="post" class="vstack gap-3">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="step" value="2">

                <div>
                  <label class="form-label">Pregunta de seguridad</label>
                  <input type="text" class="form-control" value="<?= e($question) ?>" disabled>
                </div>

                <div>
                  <label class="form-label">Respuesta</label>
                  <input type="text" maxlength="20" name="answer" class="form-control" required autocomplete="off">
                </div>

<div class="row g-2">
  <div class="col-12 col-md-6">
    <label class="form-label">Nueva contraseña</label>

    <div class="input-group">
      <input 
        id="newPassword"
        type="password" 
        name="new_password" 
        maxlength="128" 
        class="form-control" 
        required 
        minlength="16" 
        autocomplete="new-password"
      >

      <button 
        class="input-group-text bg-white border-start-0" 
        type="button" 
        id="toggleNewPassword"
        style="cursor:pointer;"
      >
        <i class="bi bi-eye text-dark" id="iconNewPassword"></i>
      </button>
    </div>

    <div class="form-text">Mínimo 16 caracteres.</div>
  </div>

  <div class="col-12 col-md-6">
    <label class="form-label">Repetir contraseña</label>

    <div class="input-group">
      <input 
        id="newPassword2"
        type="password" 
        name="new_password2" 
        class="form-control" 
        maxlength="128" 
        required 
        minlength="16" 
        autocomplete="new-password"
      >

      <button 
        class="input-group-text bg-white border-start-0" 
        type="button" 
        id="toggleNewPassword2"
        style="cursor:pointer;"
      >
        <i class="bi bi-eye text-dark" id="iconNewPassword2"></i>
      </button>
    </div>
  </div>
</div>

                <button class="btn btn-primary btn-lg w-100">Guardar nueva contraseña</button>

                <div class="text-center mt-2 d-flex justify-content-center gap-3 flex-wrap">
                  <a class="text-decoration-none" href="forgot_password.php">Volver</a>
                  <span class="text-muted">·</span>
                  <a class="text-decoration-none" href="index.php">Ir al inicio</a>
                </div>
              </form>
            <?php endif; ?>

          </div>
        </div>

        <div class="text-center text-muted small mt-3">
          <?= e(APP_NAME) ?> · v<?= e(APP_VERSION) ?>
        </div>

      </div>
    </div>
  </div>
<script>
function togglePassword(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon = document.getElementById(iconId);

    if (!input || !icon) return;

    const isPassword = input.type === 'password';
    input.type = isPassword ? 'text' : 'password';

    icon.classList.toggle('bi-eye');
    icon.classList.toggle('bi-eye-slash');
}

document.getElementById('toggleNewPassword')?.addEventListener('click', () => {
    togglePassword('newPassword', 'iconNewPassword');
});

document.getElementById('toggleNewPassword2')?.addEventListener('click', () => {
    togglePassword('newPassword2', 'iconNewPassword2');
});
</script>
  <script src="<?= e(ASSETS_URL) ?>vendor/bootstrap/bootstrap.bundle.min.js"></script>
</body>
</html>
