<?php
require_once __DIR__ . '/config/config.php';
$page = 'Categorías';
$active = 'categorias';

require_once __DIR__ . '/includes/layout.php';

/* =========================
   BUSCADOR 
========================= */
$buscar = trim($_GET['buscar'] ?? '');
$params = [];
$where = '';

if ($buscar !== '') {

    $where = 'WHERE c.nombre_categoria LIKE :q1 
              OR c.descripcion_categoria LIKE :q2 
              OR c.id_categoria LIKE :q3';

    $like = "%$buscar%";

    $params = [
        'q1' => $like,
        'q2' => $like,
        'q3' => $like
    ];
}

/* =========================
   CRUD
========================= */
if (is_post()) {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $id = (int)($_POST['id_categoria'] ?? 0);
        $nombre = trim($_POST['nombre_categoria'] ?? '');
        if (mb_strlen($nombre) > 20) {
            flash_set('danger', 'El nombre de la categoría no puede superar 20 caracteres.');
            redirect($redirectUrl);
        }
        $desc = trim($_POST['descripcion_categoria'] ?? '');

        if ($nombre === '') {
            flash_set('danger', 'El nombre es obligatorio.');
            redirect('categorias');
        }

        if ($action === 'create') {

            db_exec(
                'INSERT INTO categorias (nombre_categoria, descripcion_categoria, date_added) 
                 VALUES (:n,:d,NOW())',
                [':n'=>$nombre, ':d'=>$desc]
            );

            $newId = db_last_id();

            audit_log('CATEGORY_CREATE', 'category', $newId, [
                'nombre_categoria' => $nombre,
                'descripcion_categoria' => $desc,
            ]);

            flash_set('success', 'Categoría creada.');

        } else {

            db_exec(
                'UPDATE categorias 
                 SET nombre_categoria=:n, descripcion_categoria=:d 
                 WHERE id_categoria=:id',
                [':n'=>$nombre, ':d'=>$desc, ':id'=>$id]
            );

            audit_log('CATEGORY_UPDATE', 'category', $id, [
                'nombre_categoria' => $nombre,
                'descripcion_categoria' => $desc,
            ]);

            flash_set('success', 'Categoría actualizada.');
        }

        redirect('categorias');
    }

    if ($action === 'delete') {

        $id = (int)($_POST['id_categoria'] ?? 0);

        $count = (int)(db_one(
            'SELECT COUNT(*) AS c FROM products WHERE id_categoria=:id',
            [':id'=>$id]
        )['c'] ?? 0);

        if ($count > 0) {
            flash_set('warning', 'No puedes eliminar una categoría con productos asociados.');
            redirect('categorias');
        }

        $c = db_one(
            'SELECT nombre_categoria, descripcion_categoria 
             FROM categorias 
             WHERE id_categoria=:id',
            [':id'=>$id]
        );

        db_exec('DELETE FROM categorias WHERE id_categoria=:id', [':id'=>$id]);

        audit_log('CATEGORY_DELETE', 'category', $id, [
            'nombre_categoria' => $c['nombre_categoria'] ?? null,
            'descripcion_categoria' => $c['descripcion_categoria'] ?? null,
        ]);

        flash_set('success', 'Categoría eliminada.');
        redirect('categorias');
    }
}

/* =========================
   CONSULTA
========================= */
$sql = "SELECT c.*, 
        (SELECT COUNT(*) FROM products p WHERE p.id_categoria=c.id_categoria) AS productos 
        FROM categorias c 
        $where
        ORDER BY c.id_categoria DESC";

$categorias = db_all($sql, $params);

$edit_id = (int)($_GET['edit'] ?? 0);
$edit = null;

if ($edit_id > 0) {
    $edit = db_one('SELECT * FROM categorias WHERE id_categoria=:id', [':id'=>$edit_id]);
}
?>

<div class="row g-3">

<!-- FORM -->
<div class="col-12 col-lg-4">
<div class="card stat-card primary h-100">

<div class="card-header form-header">
<h5 class="card-title mb-0">
<i class="bi bi-tags me-2"></i>
<?= $edit ? 'Editar categoría' : 'Nueva categoría' ?>
</h5>
</div>

<div class="card-body">

<form method="POST">
<?= csrf_field() ?>

<input type="hidden" name="action" value="<?= $edit ? 'update' : 'create' ?>">
<input type="hidden" name="id_categoria" value="<?= e((string)($edit['id_categoria'] ?? 0)) ?>">

<div class="mb-3">
<label class="form-label">Nombre<span style="color:#dc2626">*</span></label>
<input 
  class="form-control form-modern"
  name="nombre_categoria"
  maxlength="20"
  oninput="this.value=this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñÜü ]/g,'');"
  required
  value="<?= e($edit['nombre_categoria'] ?? '') ?>">
<div class="form-text">Máx. 20 caracteres</div>
</div>

<div class="mb-2">
<label class="form-label">Descripción</label>
<textarea class="form-control form-modern"
name="descripcion_categoria"
maxlength="255"
placeholder="Opcional"
value="<?= e($edit['descripcion_categoria'] ?? '') ?>"></textarea> 
</div>

<div class="form-actions">

<button class="btn btn-save" type="submit">
<i class="bi bi-check-lg"></i>
<?= $edit ? 'Guardar cambios' : 'Crear categoría' ?>
</button>

<?php if ($edit): ?>
<a class="btn btn-cancel" href="categorias">Cancelar</a>
<?php endif; ?>

</div>
</form>

</div>
</div>
</div>

<!-- TABLA -->
<div class="col-12 col-lg-8">
<div class="card stat-card primary table-card h-100">

<div class="card-header table-header">

<div>
<h5 class="card-title mb-1">Listado de categorías</h5>
<small class="text-muted">No se permite borrar categorías con productos</small>
</div>

<a class="btn btn-outline-success btn-sm" href="export.php?type=categorias">
<i class="bi bi-file-earmark-excel"></i> Exportar
</a>

</div>

<!-- BUSCADOR -->
<form class="table-search m-3" method="GET">

<div class="search-bar">

<div class="search-input-wrap">

<i class="bi bi-search search-icon"></i>

<input
class="form-control search-input"
name="buscar"
maxlength="40"
placeholder="Buscar por ID, nombre o descripción"
value="<?= e($buscar) ?>">

<?php if(!empty($buscar)): ?>
<a href="categorias" class="clear-search">
<i class="bi bi-x"></i>
</a>
<?php endif; ?>

</div>

<div class="search-actions">

<button class="btn btn-search" type="submit">
<i class="bi bi-search"></i>
Buscar
</button>

<a class="btn btn-refresh" href="categorias">
<i class="bi bi-arrow-clockwise"></i>
</a>

</div>

</div>
</form>

<div class="card-body">

<div class="table-responsive table-modern">

<table class="table align-middle mb-0">

<thead>
<tr>
<th>ID</th>
<th>Nombre</th>
<th>Descripción</th>
<th>Productos</th>
<th style="width:160px;">Acciones</th>
</tr>
</thead>

<tbody>

<?php if (!$categorias): ?>
<tr>
<td colspan="5" class="text-center text-muted py-4">
No hay categorías
</td>
</tr>

<?php else: foreach ($categorias as $c): ?>

<tr>

<td class="text-muted fw-medium"><?= e((string)$c['id_categoria']) ?></td>

<td class="fw-semibold"><?= e($c['nombre_categoria']) ?></td>

<td class="descripcion"><?= e($c['descripcion_categoria']) ?></td>

<td>
<span class="badge-soft"><?= e((string)$c['productos']) ?></span>
</td>

<td>

<div class="table-actions">

<a class="btn btn-edit"
href="categorias?edit=<?= e((string)$c['id_categoria']) ?>">
<i class="bi bi-pencil"></i>
</a>

<button
type="button"
class="btn btn-delete btn-delete-category"
data-id="<?= e((string)$c['id_categoria']) ?>"
data-name="<?= e($c['nombre_categoria']) ?>"
data-bs-toggle="modal"
data-bs-target="#deleteCategoryModal">
<i class="bi bi-trash"></i>
</button>

</div>

</td>

</tr>

<?php endforeach; endif; ?>

</tbody>

</table>

</div>
</div>
</div>
</div>

</div>

<!-- MODAL ELIMINAR -->
<div class="modal fade" id="deleteCategoryModal" tabindex="-1">
<div class="modal-dialog modal-dialog-centered modal-sm">

<div class="modal-content modal-delete">

<div class="modal-header border-0 pb-0">
<h5 class="modal-title">
<i class="bi bi-exclamation-triangle text-danger me-2"></i>
Eliminar categoría
</h5>

<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body text-center pt-2">

<div class="delete-icon">
<i class="bi bi-trash"></i>
</div>

<p class="mb-1">Vas a eliminar:</p>

<div class="delete-name" id="deleteCategoryName">—</div>

<p class="text-muted small mt-3 mb-0">
Solo se eliminará si no tiene productos asociados.
</p>

</div>

<div class="modal-footer border-0 pt-0 justify-content-center">

<button type="button" class="btn btn-cancel" data-bs-dismiss="modal">
Cancelar
</button>

<form method="POST">
<?= csrf_field() ?>
<input type="hidden" name="action" value="delete">
<input type="hidden" name="id_categoria" id="deleteCategoryId">

<button class="btn btndeleteconfirm" type="submit">
Sí, eliminar
</button>
</form>

</div>

</div>
</div>
</div>

<script>
document.querySelectorAll('.btn-delete-category').forEach(function (btn) {
btn.addEventListener('click', function () {
document.getElementById('deleteCategoryId').value = this.dataset.id;
document.getElementById('deleteCategoryName').textContent = this.dataset.name;
});
});
</script>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>