<?php 
require_once __DIR__ . '/config/config.php';
$page = 'Usuarios';
$active = 'usuarios';

require_admin();

$securityQuestions = [
    'q_color' => '¿Cuál es tu color favorito?',
    'q_pet'   => '¿Cuál es el nombre de tu primera mascota?',
    'q_city'  => '¿Cuál es tu ciudad de nacimiento?',
    'q_food'  => '¿Cuál es tu comida favorita?',
    'q_word'  => '¿Cuál es tu palabra clave?'
];

$old = old_form_data();
old_input_clear();

if (is_post()) {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {

        $id = (int)($_POST['user_id'] ?? 0);
        $firstname = trim((string)($_POST['firstname'] ?? ''));
        $lastname = trim((string)($_POST['lastname'] ?? ''));
        $username = trim((string)($_POST['user_name'] ?? ''));
        $email = trim((string)($_POST['user_email'] ?? ''));
        $role = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $password = (string)($_POST['password'] ?? '');
        $sec_q = trim((string)($_POST['security_question'] ?? ''));
        $sec_a = trim((string)($_POST['security_answer'] ?? ''));

        $redirectUrl = $action === 'update' ? 'usuarios.php?edit=' . $id : 'usuarios.php';

        // ✅ VALIDACIÓN CORRECTA
        if ($sec_q !== '' && !array_key_exists($sec_q, $securityQuestions)) {
            flash_set('danger', 'Selecciona una pregunta de seguridad válida.');
            redirect($redirectUrl);
        }

        old_input_set([
            'user_id' => $id,
            'firstname' => $firstname,
            'lastname' => $lastname,
            'user_name' => $username,
            'user_email' => $email,
            'role' => $role,
            'is_active' => $is_active,
            'security_question' => $sec_q
        ]);

        if ($firstname === '' || $lastname === '' || $username === '' || $email === '') {
            flash_set('danger', 'Completa todos los campos obligatorios.');
            redirect($redirectUrl);
        }

        if (!valid_person_name($firstname) || !valid_person_name($lastname)) {
            flash_set('danger', 'Nombres y apellidos solo pueden tener letras y máximo 30 caracteres.');
            redirect($redirectUrl);
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash_set('danger', 'Email inválido.');
            redirect($redirectUrl);
        }

        if ($password !== '' && strlen($password) < PASSWORD_MIN_LEN) {
            flash_set('danger', 'La contraseña debe tener mínimo ' . PASSWORD_MIN_LEN . ' caracteres.');
            redirect($redirectUrl);
        }

        $dupU = db_one(
            'SELECT user_id FROM users WHERE user_name=:u AND user_id<>:id LIMIT 1',
            [':u' => $username, ':id' => $id]
        );

        if ($dupU) {
            flash_set('danger', 'El nombre de usuario ya existe.');
            redirect($redirectUrl);
        }

        $dupE = db_one(
            'SELECT user_id FROM users WHERE user_email=:e AND user_id<>:id LIMIT 1',
            [':e' => $email, ':id' => $id]
        );

        if ($dupE) {
            flash_set('danger', 'El email ya está registrado.');
            redirect($redirectUrl);
        }

        $secHash = null;

        // ================= CREATE =================
        if ($action === 'create') {

            if ($role === 'admin' && ($sec_q === '' || $sec_a === '')) {
                flash_set('danger', 'Para usuarios admin debes configurar pregunta y respuesta de seguridad.');
                redirect($redirectUrl);
            }

            if ($sec_q !== '' && $sec_a !== '') {
                $secHash = password_hash($sec_a, PASSWORD_DEFAULT);
            }

            if ($password === '') {
                flash_set('danger', 'La contraseña es obligatoria para crear usuario.');
                redirect($redirectUrl);
            }

            $hash = password_hash($password, PASSWORD_DEFAULT);

            db_exec(
                'INSERT INTO users 
                (firstname, lastname, user_name, user_email, user_password_hash, role, is_active, security_question, security_answer_hash, date_added)
                VALUES
                (:f,:l,:u,:e,:p,:r,:a,:sq,:sh,NOW())',
                [
                    ':f' => $firstname,
                    ':l' => $lastname,
                    ':u' => $username,
                    ':e' => $email,
                    ':p' => $hash,
                    ':r' => $role,
                    ':a' => $is_active,
                    ':sq' => $sec_q !== '' ? $sec_q : null,
                    ':sh' => $secHash
                ]
            );

            old_input_clear();
            audit_log('USER_CREATE', 'users', null, ['user_name' => $username, 'role' => $role]);
            flash_set('success', 'Usuario creado.');
            redirect('usuarios.php');
        }

        // ================= UPDATE =================
        $currentId = (int)(current_user()['id'] ?? 0);

        if ($id === $currentId && $is_active === 0) {
            flash_set('warning', 'No puedes desactivar tu propio usuario.');
            redirect($redirectUrl);
        }

        if (($sec_q !== '' && $sec_a === '') || ($sec_q === '' && $sec_a !== '')) {
            flash_set('danger', 'Para actualizar la pregunta debes indicar pregunta y respuesta.');
            redirect($redirectUrl);
        }

        if ($sec_q !== '' && $sec_a !== '') {
            $secHash = password_hash($sec_a, PASSWORD_DEFAULT);
        }

        $sql = 'UPDATE users SET firstname=:f, lastname=:l, user_name=:u, user_email=:e, role=:r, is_active=:a';
        $params = [
            ':f' => $firstname,
            ':l' => $lastname,
            ':u' => $username,
            ':e' => $email,
            ':r' => $role,
            ':a' => $is_active,
            ':id' => $id
        ];

        if ($password !== '') {
            $sql .= ', user_password_hash=:p';
            $params[':p'] = password_hash($password, PASSWORD_DEFAULT);
        }

        if ($secHash !== null) {
            $sql .= ', security_question=:sq, security_answer_hash=:sh';
            $params[':sq'] = $sec_q;
            $params[':sh'] = $secHash;
        }

        $sql .= ' WHERE user_id=:id';
        db_exec($sql, $params);

        old_input_clear();
        audit_log('USER_UPDATE', 'users', $id);
        flash_set('success', 'Usuario actualizado.');
        redirect('usuarios.php');
    }

    // ================= UNLOCK =================
    if ($action === 'unlock') {
        $id = (int)($_POST['user_id'] ?? 0);
        db_exec(
            'UPDATE users SET failed_attempts=0, locked_until=NULL WHERE user_id=:id',
            [':id' => $id]
        );
        audit_log('USER_UNLOCK', 'users', $id);
        flash_set('success', 'Usuario desbloqueado.');
        redirect('usuarios.php');
    }
}

$users = db_all(
    'SELECT user_id, firstname, lastname, user_name, user_email, role, is_active, date_added, failed_attempts, locked_until 
     FROM users ORDER BY user_id DESC'
);

$edit_id = (int)($_GET['edit'] ?? 0);
$edit = null;

if ($edit_id > 0) {
    $edit = db_one(
        'SELECT user_id, firstname, lastname, user_name, user_email, role, is_active, security_question 
         FROM users WHERE user_id=:id',
        [':id' => $edit_id]
    );
}

function user_form_value(array $old, ?array $edit, string $key, string $default = ''): string {
    return (string)($old[$key] ?? $edit[$key] ?? $default);
}

$currentQuestion = user_form_value($old, $edit, 'security_question');

if ($currentQuestion !== '' && !array_key_exists($currentQuestion, $securityQuestions)) {
    $securityQuestions[$currentQuestion] = $currentQuestion;
}

$currentIsActive = array_key_exists('is_active', $old)
    ? (int)$old['is_active'] === 1
    : (int)($edit['is_active'] ?? 1) === 1;

require_once __DIR__ . '/includes/layout.php';
?>


<div class="row g-3">

  <!-- ===================== FORMULARIO ===================== -->
  <div class="col-12 col-lg-4">
    <div class="card stat-card primary h-100">

      <div class="card-header form-header">
        <h5 class="card-title mb-0">
          <i class="bi bi-people me-2"></i>
          <?= $edit ? 'Editar usuario' : 'Nuevo usuario' ?>
        </h5>
      </div>

      <div class="card-body">
        <form method="POST">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="<?= $edit ? 'update' : 'create' ?>">
          <input type="hidden" name="user_id" value="<?= e((string)($edit['user_id'] ?? 0)) ?>">

          <div class="row g-2">
            <div class="col-6">
              <label class="form-label">Nombres</label>
              <input
                class="form-control form-modern"
                name="firstname"
                maxlength="20"
                required
                value="<?= e(user_form_value($old,$edit,'firstname')) ?>"
                oninput="this.value=this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñÜü ]/g,'');">
            </div>

            <div class="col-6">
              <label class="form-label">Apellidos</label>
              <input
                class="form-control form-modern"
                name="lastname"
                maxlength="20"
                required
                value="<?= e(user_form_value($old,$edit,'lastname')) ?>"
                oninput="this.value=this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñÜü ]/g,'');">
            </div>
          </div>

          <div class="row g-2">
             <div class="col-6">
           
                <label class="form-label">Usuario</label>
                <input class="form-control form-modern" name="user_name" required
                maxlength="20"
                value="<?= e(user_form_value($old,$edit,'user_name')) ?>">
      
            </div>

            <div class="col-6">
           
                <label class="form-label">Email</label>
                <input class="form-control form-modern" name="user_email" required
                maxlength="35"
                value="<?= e(user_form_value($old,$edit,'user_email')) ?>">
             
            </div>

          </div>


          <div class="row g-2">
            <div class="col-6">
              <label class="form-label">Rol</label>
              <select class="form-select form-modern" name="role">
                <option value="user" <?= user_form_value($old,$edit,'role','user')==='user'?'selected':'' ?>>Usuario</option>
                <option value="admin" <?= user_form_value($old,$edit,'role','user')==='admin'?'selected':'' ?>>Admin</option>
              </select>
            </div>

            <div class="col-6 d-flex align-items-end">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="is_active" id="is_active" <?= $currentIsActive?'checked':'' ?>>
                <label class="form-check-label" for="is_active">Activo</label>
              </div>
            </div>
          </div>

          <div class="mb-3 mt-2">
            <label class="form-label">Pregunta de seguridad (solo Admin)</label>
            <select class="form-select form-modern" name="security_question">
              <option value="">Selecciona una pregunta</option>
              <?php foreach ($securityQuestions as $code => $label): ?>
                <option value="<?= e($code) ?>" <?= (($edit['security_question'] ?? '') === $code) ? 'selected' : '' ?>>
                  <?= e($label) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label">Respuesta (solo Admin)</label>
            <input maxlength="20" class="form-control form-modern" type="password" name="security_answer">
          </div>

<div class="mb-3">
  <label class="form-label">
    Contraseña <?= $edit ? '(opcional)' : '' ?>
  </label>

  <div class="input-group">
    <input 
      id="passwordInputEdit"
      class="form-control form-modern" 
      name="password" 
      type="password"
      minlength="16"
      <?= $edit ? '' : 'required' ?>
    >

    <button 
      class="input-group-text bg-white" 
      type="button" 
      id="togglePasswordEdit"
      style="cursor:pointer;"
    >
      <i class="bi bi-eye" id="iconPasswordEdit"></i>
    </button>
  </div>

  <div class="form-text">Mínimo 16 caracteres.</div>
</div>

          <div class="form-actions">
            <button class="btn btn-save" type="submit">
              <i class="bi bi-check-lg"></i>
              <?= $edit ? 'Guardar cambios' : 'Crear usuario' ?>
            </button>

            <?php if ($edit): ?>
              <a class="btn btn-cancel" href="usuarios.php">Cancelar</a>
            <?php endif; ?>
          </div>

        </form>
      </div>
    </div>
  </div>

  <!-- ===================== TABLA ===================== -->
  <div class="col-12 col-lg-8">
    <div class="card stat-card primary table-card h-100">

      <div class="card-header table-header">
        <div>
          <h5 class="card-title mb-1">Listado de usuarios</h5>
          <small class="text-muted">Admin tiene todos los privilegios</small>
        </div>

        <a class="btn btn-outline-success btn-sm" href="export.php?type=users">
          <i class="bi bi-file-earmark-excel"></i> Exportar
        </a>
      </div>

      <div class="card-body">
        <div class="table-responsive table-modern">
          <table class="table align-middle mb-0">

            <thead>
              <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Usuario</th>
                <th>Email</th>
                <th>Rol</th>
                <th>Estado</th>
                <th>Seguridad</th>
                <th style="width:160px;">Acciones</th>
              </tr>
            </thead>

            <tbody>
              <?php if (!$users): ?>
                <tr>
                  <td colspan="8" class="text-center text-muted py-4">No hay usuarios</td>
                </tr>
              <?php else: foreach ($users as $u): ?>
                <tr>

                  <td class="text-muted"><?= e((string)$u['user_id']) ?></td>

                  <td class="fw-semibold"><?= e($u['firstname'].' '.$u['lastname']) ?></td>

                  <td><?= e($u['user_name']) ?></td>

                  <td><?= e($u['user_email']) ?></td>

                  <td>
                    <span class="badge-modern <?= $u['role']==='admin'?'ok':'bajo' ?>">
                      <?= e(strtoupper($u['role'])) ?>
                    </span>
                  </td>

                  <td>
                    <span class="badge-modern <?= (int)$u['is_active']===1?'ok':'agotado' ?>">
                      <?= (int)$u['is_active']===1?'ACTIVO':'INACTIVO' ?>
                    </span>
                  </td>

                  <td>
                    <?php $locked = !empty($u['locked_until']) && strtotime((string)$u['locked_until']) > time(); ?>
                    <span class="badge-modern <?= $locked?'bajo':'ok' ?>">
                      <?= $locked?'BLOQUEADO':'OK' ?>
                    </span>
                    <div class="small text-muted">Intentos: <?= e((string)($u['failed_attempts'] ?? 0)) ?></div>
                  </td>

                  <td>
                    <div class="table-actions">
                      <a class="btn btn-edit" href="usuarios.php?edit=<?= e((string)$u['user_id']) ?>">
                        <i class="bi bi-pencil"></i>
                      </a>

                      <?php if ($locked): ?>
                        <form method="POST">
                          <?= csrf_field() ?>
                          <input type="hidden" name="action" value="unlock">
                          <input type="hidden" name="user_id" value="<?= e((string)$u['user_id']) ?>">
                          <button class="btn btn-refresh" type="submit">
                            <i class="bi bi-unlock"></i>
                          </button>
                        </form>
                      <?php endif; ?>

                      <a class="btn btn-delete" href="usuarios_delete.php?id=<?= e((string)$u['user_id']) ?>">
                        <i class="bi bi-trash"></i>
                      </a>
                    </div>
                  </td>

                </tr>
              <?php endforeach; endif; ?>
            </tbody>

          </table>
        </div>
      </div>
    </div>
  </div>

</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
<script>
const togglePasswordEdit = document.getElementById('togglePasswordEdit');
const passwordInputEdit = document.getElementById('passwordInputEdit');
const iconEdit = document.getElementById('iconPasswordEdit');

if (togglePasswordEdit) {
    togglePasswordEdit.addEventListener('click', () => {
        const isPassword = passwordInputEdit.type === 'password';

        passwordInputEdit.type = isPassword ? 'text' : 'password';

        iconEdit.classList.toggle('bi-eye');
        iconEdit.classList.toggle('bi-eye-slash');
    });
}
</script>