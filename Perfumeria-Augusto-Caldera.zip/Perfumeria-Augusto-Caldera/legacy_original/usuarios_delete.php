<?php
require_once __DIR__ . '/config/config.php';
$page = 'Eliminar Usuario';
$active = 'usuarios';

require_admin();

$id = (int)($_GET['id'] ?? 0);
$currentId = (int)(current_user()['id'] ?? 0);

if ($id <= 0) {
    redirect('usuarios.php');
}
if ($id === $currentId) {
    flash_set('warning', 'No puedes eliminar tu propio usuario.');
    redirect('usuarios.php');
}

$target = db_one('SELECT user_id, user_name, user_email FROM users WHERE user_id = :id LIMIT 1', [':id' => $id]);
if (!$target) {
    flash_set('warning', 'Usuario no encontrado.');
    redirect('usuarios.php');
}


$adminInfo = db_one('SELECT security_question, security_answer_hash FROM users WHERE user_id = :id LIMIT 1', [':id' => $currentId]) ?: [];

$error = '';
if (is_post()) {
    csrf_verify();

    $password = (string)($_POST['admin_password'] ?? '');
    $secAnswer = trim((string)($_POST['admin_security_answer'] ?? ''));

    $admin = db_one('SELECT user_id, user_password_hash, security_question, security_answer_hash
                     FROM users WHERE user_id = :id LIMIT 1', [':id' => $currentId]);

    if (!$admin || !password_verify($password, (string)$admin['user_password_hash'])) {
        $error = 'Autenticación inválida.';
        audit_log('USER_DELETE_DENIED', 'users', $id, ['reason' => 'bad_password']);
    } else {
       
        $hash = (string)($admin['security_answer_hash'] ?? '');
        if ($hash === '') {
            $error = 'Debes configurar tu pregunta de seguridad antes de eliminar usuarios.';
            audit_log('USER_DELETE_DENIED', 'users', $id, ['reason' => 'security_question_not_set']);
        } elseif (!password_verify($secAnswer, $hash)) {
            $error = 'Respuesta de seguridad inválida.';
            audit_log('USER_DELETE_DENIED', 'users', $id, ['reason' => 'bad_security_answer']);
        }
    }

    if ($error === '') {
        db_exec('DELETE FROM users WHERE user_id = :id', [':id' => $id]);
        audit_log('USER_DELETE', 'users', $id, ['by' => $currentId]);
        flash_set('success', 'Usuario eliminado.');
        redirect('usuarios.php');
    }
}

require_once __DIR__ . '/includes/layout.php';
?>

<div class="row justify-content-center">

  <div class="col-lg-6">
    <div class="card stat-card primary">

     
      <div class="card-header form-header">
        <h5 class="card-title mb-0">
          <i class="bi bi-exclamation-triangle me-2"></i>
          Confirmar eliminación
        </h5>
      </div>

      
      <div class="card-body">

        <p class="mb-2">Vas a eliminar al usuario:</p>

        <div class="info-box mb-3">
          <div><b>ID:</b> <?= e((string)$target['user_id']) ?></div>
          <div><b>Usuario:</b> <?= e((string)$target['user_name']) ?></div>
          <div><b>Email:</b> <?= e((string)$target['user_email']) ?></div>
        </div>

        <div class="alert alert-modern warning mb-3">
          Para cumplir con el instrumento, debes autenticarte nuevamente
          (contraseña + pregunta de seguridad) para eliminar un usuario.
        </div>

        <?php if ($error): ?>
          <div class="alert alert-modern danger mb-3"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="POST">
          <?= csrf_field() ?>

          <div class="mb-3">
            <label class="form-label">Tu contraseña (admin)</label>
            <input maxlength="16" class="form-control form-modern" type="password" name="admin_password" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Pregunta de seguridad</label>
            <div class="form-text mb-1">
              <?= e((string)($adminInfo['security_question'] ?? 'No configurada')) ?>
            </div>
            <input maxlength="20" class="form-control form-modern" name="admin_security_answer" required>
          </div>

          <div class="form-actions justify-content-center">
            <button class="btn btndeleteconfirm" style="width: auto;" type="submit">
              Eliminar 
            </button>

            <a class="btn btn-cancel" href="usuarios.php">
              Cancelar
            </a>
          </div>

        </form>

      </div>
    </div>
  </div>

</div>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
