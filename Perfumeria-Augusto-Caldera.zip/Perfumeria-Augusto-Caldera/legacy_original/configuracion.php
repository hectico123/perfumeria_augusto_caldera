<?php
require_once __DIR__ . '/config/config.php';
$page = 'Configuración';
$active = 'config';



$old = old_form_data();
old_input_clear();

if (is_post()) {
    csrf_verify();

    $rate = trim((string)($_POST['usd_to_ves'] ?? ''));
    old_input_set(['usd_to_ves' => $rate]);

    $rateNormalized = str_replace(',', '.', $rate);

    if ($rateNormalized === '' || !is_numeric($rateNormalized) || (float)$rateNormalized <= 0) {
        flash_set('danger', 'Ingresa una tasa válida mayor a 0.');
        redirect('configuracion.php');
    }

    $val = number_format((float)$rateNormalized, 4, '.', '');

    db_exec(
        "INSERT INTO settings (setting_key, setting_value)
         VALUES ('usd_to_ves', :v1)
         ON DUPLICATE KEY UPDATE setting_value = :v2",
        [':v1' => $val, ':v2' => $val]
    );

    db_exec(
        "INSERT INTO exchange_rate_history (rate, user_id, created_at)
         VALUES (:rate, :user_id, NOW())",
        [
            ':rate' => $val,
            ':user_id' => (int)(current_user()['id'] ?? 0)
        ]
    );

    old_input_clear();
    flash_set('success', 'Tasa actualizada correctamente.');
    redirect('configuracion.php');
}

$rateRow = db_one("SELECT setting_value FROM settings WHERE setting_key='usd_to_ves' LIMIT 1");
$usd_to_ves = $rateRow ? (float)$rateRow['setting_value'] : 0.0;

$history = db_all(
    "SELECT h.rate, h.created_at, u.user_name
     FROM exchange_rate_history h
     LEFT JOIN users u ON u.user_id = h.user_id
     ORDER BY h.created_at DESC
     LIMIT 20"
);

require_once __DIR__ . '/includes/layout.php';
?>

<div class="row g-3">

  <!-- FORM -->
  <div class="col-12 col-lg-6">
    <div class="card stat-card primary h-100">
      <div class="card-header form-header">
        <h5 class="card-title mb-0">Conversión USD → Bolívares</h5>
        <small class="text-muted">Se usa para calcular y mostrar precios en Bs</small>
      </div>

      <div class="card-body">
        <form method="POST">
          <?= csrf_field() ?>

          <label class="form-label">Tasa actual</label>

          <div class="input-group">
            <span class="input-group-text">1 USD =</span>

              <input
                class="form-control form-modern"
                name="usd_to_ves"
                type="number"
                step="0.0001"
                min="0.0001"
                value="<?= e(($old['usd_to_ves'] ?? '') !== '' ? $old['usd_to_ves'] : ($usd_to_ves > 0 ? (string)$usd_to_ves : '')) ?>"
                oninput="if(this.value.length>20)this.value=this.value.slice(0,20)"
                required
              >

            <span class="input-group-text">Bs</span>
          </div>

          <button class="btn btn-save mt-3" type="submit">
            Guardar
          </button>

        </form>
      </div>
    </div>
  </div>


  <!-- HISTORIAL -->
  <div class="col-12 col-lg-6">
    <div class="card stat-card primary table-card h-100">

      <div class="card-header table-header">
        <h5 class="card-title mb-0">Historial de tasas</h5>
        <small class="text-muted">Últimos 20 cambios registrados</small>
      </div>

      <div class="card-body">

        <div class="table-responsive table-modern">

          <table class="table align-middle mb-0">

            <thead>
              <tr>
                <th>Fecha</th>
                <th>Tasa</th>
                <th>Usuario</th>
              </tr>
            </thead>

            <tbody>

              <?php if (!$history): ?>

                <tr>
                  <td colspan="3" class="text-center text-muted py-4">
                    No hay historial de tasas
                  </td>
                </tr>

              <?php else: foreach ($history as $row): ?>

                <tr>

                  <td class="text-muted">
                    <?= e((string)$row['created_at']) ?>
                  </td>

                  <td class="fw-semibold">
                    <?= e(number_format((float)$row['rate'], 4, '.', '')) ?>
                  </td>

                  <td>
                    <?= e((string)($row['user_name'] ?? '—')) ?>
                  </td>

                </tr>

              <?php endforeach; endif; ?>

            </tbody>

          </table>

        </div>

      </div>

    </div>
  </div>

</div>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
