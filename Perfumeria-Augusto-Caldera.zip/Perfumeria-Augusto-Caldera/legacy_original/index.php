<?php
require_once __DIR__ . '/config/config.php';

if (is_logged_in()) {
    redirect('dashboard');
}

$error = '';
$oldUser = '';

if (is_post()) {
    csrf_verify();
    $user = trim((string)($_POST['user'] ?? ''));
    $pass = (string)($_POST['password'] ?? '');
    $oldUser = $user;

    
    $ip = $_SERVER['REMOTE_ADDR']; 
    $captcha = $_POST['g-recaptcha-response'] ?? ''; 
    $secret = '6LfYqJUsAAAAAM2GXfJ9ZPMC3AlPThEVI5E787v_';

    
    $url = "https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$captcha&remoteip=$ip";
    $respuesta = file_get_contents($url); 
    
    
    $atributos = json_decode($respuesta, true); 

    if (!$atributos['success']) {
        $error = 'Por favor, verifica la casilla de "No soy un robot".';
    } else {
        
        try {
            $res = login_attempt($user, $pass);
            if ($res['ok']) {
                if (!empty($res['redirect'])) {
                    redirect((string)$res['redirect']);
                }
                redirect('dashboard');
            }
            $error = $res['msg'];
        } catch (Throwable $e) {
            $error = APP_ENV === 'development'
                ? ('Error al iniciar sesión: ' . $e->getMessage())
                : 'Error al iniciar sesión.';
        }
    }
}

$flash = flash_get();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-Frame-Options" content="SAMEORIGIN">
  <meta http-equiv="X-Content-Type-Options" content="nosniff">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Iniciar Sesión - <?= e(APP_NAME) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= e(ASSETS_URL) ?>css/login.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body>
<div class="login-container">
  <div class="login-panel-left d-none d-lg-flex">
    <div class="logo-container">
      <div class="logo-wrapper">
        <img src="<?= e(ASSETS_URL) ?>img/logo.jpeg" alt="Logo">
      </div>
      <div class="login-tagline">
        <h2 class="mb-1"><?= e(APP_NAME) ?></h2>
        <p class="mb-0">Sistema de Inventario</p>
      </div>
    </div>
  </div>

  <div class="login-panel-right">
    <div class="w-100" style="max-width:520px;">
      <div class="text-center mb-3 d-lg-none">
        <img src="<?= e(ASSETS_URL) ?>img/logo.png" alt="Logo" style="width:84px;height:84px;object-fit:contain;" class="mb-2">
        <h3 class="h5 mb-0">Iniciar sesión</h3>
        <div class="text-muted small">Accede con tu usuario o email</div>
      </div>

      <?php if ($flash): ?>
        <div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
      <?php endif; ?>

      <?php if ($error): ?>
        <div class="alert alert-danger"><?= e($error) ?></div>
      <?php endif; ?>

      <form method="POST" autocomplete="off">
        <?= csrf_field() ?>

        <div class="mb-3">
                    <h3 class="h1 mb-3 text-center" style="color: #1a2e1a;">Iniciar sesión</h3>

          <label class="form-label">Usuario o Email</label>
          <div class="input-group">
            <span class="input-group-text"><i class="bi bi-person"></i></span>
            <input class="form-control" maxlength="20" name="user" required value="<?= e($oldUser) ?>">
          </div>
        </div>

<div class="mb-3">
  <label class="form-label">Contraseña</label>
  <div class="input-group">
    <span class="input-group-text"><i class="bi bi-lock"></i></span>
    
    <input 
      id="passwordInput"
      class="form-control" 
      maxlength="16" 
      type="password" 
      name="password" 
      required
    >

    <button 
      class="input-group-text bg-white border-start-0" 
      type="button" 
      id="togglePassword"
      style="cursor:pointer;"
    >
      <i class="bi bi-eye" id="iconPassword"></i>
    </button>
  </div>
</div>

        <button class="btn btn-primary w-100" type="submit">Entrar</button>

        <div class="mt-3 mb-2 d-flex justify-content-center">
            <div class="g-recaptcha" data-sitekey="6LfYqJUsAAAAAL7VzEtKZjyPw_S2XjDh92cvNaS0"></div>
        </div>
        <div class="mt-2 text-end">
          <a class="small" href="forgot_password.php">¿Olvidaste tu contraseña?</a>
        </div>

<script>
let timeout;

function resetTimer() {
    clearTimeout(timeout);
    timeout = setTimeout(() => {
        window.location.href = "logout.php";
    }, 300000); // 5 min
}

document.onload = resetTimer;
document.onmousemove = resetTimer;
document.onkeypress = resetTimer;
document.onclick = resetTimer;
</script>
<script>
const togglePassword = document.getElementById('togglePassword');
const passwordInput = document.getElementById('passwordInput');
const icon = document.getElementById('iconPassword');

togglePassword.addEventListener('click', () => {
    const isPassword = passwordInput.type === 'password';

    passwordInput.type = isPassword ? 'text' : 'password';

    icon.classList.toggle('bi-eye');
    icon.classList.toggle('bi-eye-slash');
});
</script>



</body>
</html>
