<?php
require_once __DIR__ . '/config/config.php';
logout();
flash_set('success', 'Sesión cerrada correctamente.');
redirect('index.php');


