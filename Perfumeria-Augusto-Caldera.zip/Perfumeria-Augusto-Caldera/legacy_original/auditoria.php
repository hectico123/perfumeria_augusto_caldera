<?php
require_once __DIR__ . '/config/config.php';
require_login();
require_admin();

$page = 'Reportes';
$active = 'auditoria';

$tab = $_GET['tab'] ?? 'audit';

// =========================
// Filtros
// =========================
$from = trim((string)($_GET['from'] ?? ''));
$to   = trim((string)($_GET['to'] ?? ''));
$q    = trim((string)($_GET['q'] ?? ''));

function parse_date(?string $d): ?string {
    if (!$d) {
        return null;
    }

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) {
        return null;
    }

    return $d;
}

function action_label(?string $action): string {
    $map = [
        'LOGIN_SUCCESS'      => 'Inicio de sesión exitoso',
        'LOGIN_FAILED'       => 'Intento de inicio de sesión fallido',
        'LOGIN_LOCKED'       => 'Acceso bloqueado por seguridad',
        'LOGOUT'             => 'Cierre de sesión',
        'PRODUCT_CREATE'     => 'Producto creado',
        'PRODUCT_UPDATE'     => 'Producto actualizado',
        'PRODUCT_DELETE'     => 'Producto eliminado',
        'CATEGORY_CREATE'    => 'Categoría creada',
        'CATEGORY_UPDATE'    => 'Categoría actualizada',
        'CATEGORY_DELETE'    => 'Categoría eliminada',
        'USER_CREATE'        => 'Usuario creado',
        'USER_UPDATE'        => 'Usuario actualizado',
        'USER_DELETE'        => 'Usuario eliminado',
        'USER_STATUS_CHANGE' => 'Estado del usuario actualizado',
        'PASSWORD_RESET'     => 'Contraseña restablecida',
        'PASSWORD_CHANGE'    => 'Contraseña actualizada',
        'EXPORT'             => 'Reporte exportado',
        'CREATE'             => 'Registro creado',
        'UPDATE'             => 'Registro actualizado',
        'DELETE'             => 'Registro eliminado',
    ];

    if (!$action) {
        return 'Sin acción';
    }

    $action = trim($action);

    if (isset($map[$action])) {
        return $map[$action];
    }

    return ucwords(strtolower(str_replace('_', ' ', $action)));
}

function field_label(string $field): string {
    $map = [
        'type'          => 'Tipo',
        'user'          => 'Usuario',
        'user_id'       => 'ID de usuario',
        'entity'        => 'Módulo',
        'entity_id'     => 'ID relacionado',
        'product'       => 'Producto',
        'product_id'    => 'ID de producto',
        'category'      => 'Categoría',
        'category_id'   => 'ID de categoría',
        'old'           => 'Valor anterior',
        'new'           => 'Valor nuevo',
        'stock'         => 'Stock',
        'stock_antes'   => 'Stock antes',
        'stock_despues' => 'Stock después',
        'cantidad'      => 'Cantidad',
        'precio_usd'    => 'Precio USD',
        'precio_bs'     => 'Precio Bs',
        'code'          => 'Código',
        'codigo'        => 'Código',
        'name'          => 'Nombre',
        'nombre'        => 'Nombre',
        'firstname'     => 'Nombres',
        'lastname'      => 'Apellidos',
        'email'         => 'Correo',
        'role'          => 'Rol',
        'status'        => 'Estado',
        'is_active'     => 'Activo',
        'ip'            => 'IP',
        'from'          => 'Desde',
        'to'            => 'Hasta',
        'q'             => 'Búsqueda',
        'details'       => 'Detalles',
        'action'        => 'Acción',
        'reference'     => 'Referencia',
        'referencia'    => 'Referencia',
        'observacion'   => 'Observación',
        'username'      => 'Usuario',
        'user_name'     => 'Usuario',
    ];

    return $map[$field] ?? ucwords(strtolower(str_replace('_', ' ', $field)));
}

function humanize_text(string $text): string {
    $map = [
        'product_create'  => 'Producto creado',
        'product_update'  => 'Producto actualizado',
        'product_delete'  => 'Producto eliminado',
        'category_create' => 'Categoría creada',
        'category_update' => 'Categoría actualizada',
        'category_delete' => 'Categoría eliminada',
        'login_success'   => 'Inicio de sesión exitoso',
        'login_failed'    => 'Intento de inicio de sesión fallido',
        'login_locked'    => 'Acceso bloqueado por seguridad',
        'logout'          => 'Cierre de sesión',
        'export'          => 'Reporte exportado',
        'users'           => 'Usuarios',
        'products'        => 'Productos',
        'categorias'      => 'Categorías',
        'movimientos'     => 'Movimientos',
        'audit'           => 'Auditoría',
        'product'         => 'Producto',
        'category'        => 'Categoría',
        'user'            => 'Usuario',
    ];

    $lower = strtolower(trim($text));

    if (isset($map[$lower])) {
        return $map[$lower];
    }

    return ucwords(strtolower(str_replace('_', ' ', $text)));
}

function detail_label($details): string {
    if ($details === null || $details === '') {
        return 'Sin detalles';
    }

    $text = trim((string)$details);

    if ($text === '') {
        return 'Sin detalles';
    }

    $json = json_decode($text, true);

    if (json_last_error() === JSON_ERROR_NONE && is_array($json)) {
        $parts = [];

        foreach ($json as $key => $value) {
            $label = field_label((string)$key);

            if (is_array($value)) {
                $flat = [];
                foreach ($value as $k => $v) {
                    if (is_array($v)) {
                        $flat[] = field_label((string)$k) . ': ' . implode(', ', array_map('strval', $v));
                    } else {
                        $flat[] = field_label((string)$k) . ': ' . format_detail_value($v);
                    }
                }
                $value = implode(', ', $flat);
            } else {
                $value = format_detail_value($value);
            }

            $parts[] = $label . ': ' . $value;
        }

        return $parts ? implode(' | ', $parts) : 'Sin detalles';
    }

    return humanize_text($text);
}

function format_detail_value($value): string {
    if (is_bool($value)) {
        return $value ? 'Sí' : 'No';
    }

    if ($value === null || $value === '') {
        return '—';
    }

    if (is_string($value)) {
        return humanize_text($value);
    }

    return (string)$value;
}

$fromD = parse_date($from);
$toD   = parse_date($to);

// =========================
// Consultas
// =========================
if ($tab === 'audit') {
    $params = [];
    $where = [];

    if ($fromD) {
        $where[] = "a.created_at >= :from_dt";
        $params[':from_dt'] = $fromD . " 00:00:00";
    }

    if ($toD) {
        $where[] = "a.created_at <= :to_dt";
        $params[':to_dt'] = $toD . " 23:59:59";
    }

    if ($q !== '') {
        $like = '%' . $q . '%';
        $where[] = "(a.action LIKE :q1 OR a.details_json LIKE :q2 OR u.user_name LIKE :q3 OR a.ip LIKE :q4)";
        $params[':q1'] = $like;
        $params[':q2'] = $like;
        $params[':q3'] = $like;
        $params[':q4'] = $like;
    }

    $sql = "SELECT 
                a.created_at, 
                u.user_name, 
                a.action, 
                a.ip AS ip_address, 
                a.details_json AS details
            FROM audit_logs a
            LEFT JOIN users u ON u.user_id = a.user_id";

    if ($where) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }

    $sql .= " ORDER BY a.created_at DESC LIMIT 500";

    $rows = db_all($sql, $params);
} else {
    $sql = "SELECT * FROM (
                SELECT
                    m.created_at,
                    u.user_name,
                    m.tipo,
                    p.codigo_producto,
                    p.nombre_producto,
                    m.cantidad,
                    m.stock_antes,
                    m.stock_despues,
                    m.referencia,
                    m.observacion
                FROM movimientos m
                LEFT JOIN products p ON p.id_producto = m.id_producto
                LEFT JOIN users u ON u.user_id = m.user_id

                UNION ALL

                SELECT
                    a.created_at,
                    u2.user_name,
                    'REGISTRO_PRODUCTO' AS tipo,
                    p2.codigo_producto,
                    p2.nombre_producto,
                    p2.stock AS cantidad,
                    0 AS stock_antes,
                    p2.stock AS stock_despues,
                    'REGISTRO_PRODUCTO' AS referencia,
                    'Alta de producto' AS observacion
                FROM audit_logs a
                LEFT JOIN users u2 ON u2.user_id = a.user_id
                LEFT JOIN products p2 ON p2.id_producto = a.entity_id
                WHERE a.action = 'PRODUCT_CREATE' AND a.entity = 'product'

                UNION ALL

                SELECT
                    a2.created_at,
                    u3.user_name,
                    'REGISTRO_CATEGORIA' AS tipo,
                    CONCAT('CAT-', c2.id_categoria) AS codigo_producto,
                    c2.nombre_categoria AS nombre_producto,
                    0 AS cantidad,
                    0 AS stock_antes,
                    0 AS stock_despues,
                    'REGISTRO_CATEGORIA' AS referencia,
                    'Alta de categoría' AS observacion
                FROM audit_logs a2
                LEFT JOIN users u3 ON u3.user_id = a2.user_id
                LEFT JOIN categorias c2 ON c2.id_categoria = a2.entity_id
                WHERE a2.action = 'CATEGORY_CREATE' AND a2.entity = 'category'
            ) t";

    $whereInv = [];
    $paramsInv = [];

    if ($fromD) {
        $whereInv[] = "t.created_at >= :from_dt";
        $paramsInv[':from_dt'] = $fromD . " 00:00:00";
    }

    if ($toD) {
        $whereInv[] = "t.created_at <= :to_dt";
        $paramsInv[':to_dt'] = $toD . " 23:59:59";
    }

    if ($q !== '') {
        $like = '%' . $q . '%';
        $whereInv[] = "(t.codigo_producto LIKE :q1 OR t.nombre_producto LIKE :q2 OR t.referencia LIKE :q3 OR t.observacion LIKE :q4 OR t.user_name LIKE :q5 OR t.tipo LIKE :q6)";
        $paramsInv[':q1'] = $like;
        $paramsInv[':q2'] = $like;
        $paramsInv[':q3'] = $like;
        $paramsInv[':q4'] = $like;
        $paramsInv[':q5'] = $like;
        $paramsInv[':q6'] = $like;
    }

    if ($whereInv) {
        $sql .= " WHERE " . implode(" AND ", $whereInv);
    }

    $sql .= " ORDER BY t.created_at DESC LIMIT 500";

    $rows = db_all($sql, $paramsInv);
}

require_once __DIR__ . '/includes/layout.php';
?>

<div class="container-fluid">

  <div class="card stat-card primary table-card">

    <!-- HEADER -->
    <div class="card-header table-header">

      <div>
        <h5 class="card-title mb-1">
          <i class="bi bi-bar-chart-line me-2"></i>
          Reportes y Auditoría
        </h5>
        <small class="text-muted">Movimientos del sistema e inventario</small>
      </div>

      <?php if ($tab === 'audit'): ?>
        <a class="btn btn-outline-success btn-sm"
           href="export.php?type=audit<?php
            echo $fromD ? '&from=' . urlencode($fromD) : '';
            echo $toD ? '&to=' . urlencode($toD) : '';
            echo $q ? '&q=' . urlencode($q) : '';
           ?>">
          <i class="bi bi-file-earmark-excel"></i> Exportar
        </a>
      <?php else: ?>
        <a class="btn btn-outline-success btn-sm"
           href="export.php?type=movimientos<?php
            echo $fromD ? '&from=' . urlencode($fromD) : '';
            echo $toD ? '&to=' . urlencode($toD) : '';
            echo $q ? '&q=' . urlencode($q) : '';
           ?>">
          <i class="bi bi-file-earmark-excel"></i> Exportar
        </a>
      <?php endif; ?>

    </div>

    <div class="card-body">

      <!-- TABS -->
      <ul class="nav nav-tabs nav-modern mb-3">
        <li class="nav-item">
          <a class="nav-link <?= $tab === 'audit' ? 'active' : '' ?>" href="auditoria.php?tab=audit">
            Movimientos del sistema
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $tab === 'mov' ? 'active' : '' ?>" href="auditoria.php?tab=mov">
            Inventario
          </a>
        </li>
      </ul>

      <!-- FILTROS -->
      <form class="row g-2 mb-3" method="GET" action="auditoria.php">

        <input type="hidden" name="tab" value="<?= e($tab) ?>">

        <div class="col-12 col-md-3">
          <label class="form-label">Desde</label>
          <input type="date" class="form-control form-modern" name="from" value="<?= e($fromD ?? '') ?>">
        </div>

        <div class="col-12 col-md-3">
          <label class="form-label">Hasta</label>
          <input type="date" class="form-control form-modern" name="to" value="<?= e($toD ?? '') ?>">
        </div>

        <div class="col-12 col-md-4">
          <label class="form-label">Buscar</label>
          <input
            type="text"
            class="form-control form-modern"
            name="q"
            maxlength="30"
            placeholder="Usuario, acción, producto..."
            value="<?= e($q) ?>"
          >
        </div>

        <div class="col-12 col-md-2 d-flex align-items-end gap-2">
          <button class="btn btn-save w-100" type="submit">
            <i class="bi bi-funnel"></i>
          </button>
          <a class="btn btn-cancel w-100" href="auditoria.php?tab=<?= e($tab) ?>">
            <i class="bi bi-arrow-clockwise"></i>
          </a>
        </div>

      </form>

      <!-- TABLA -->
      <div class="table-responsive table-modern">

        <table class="table align-middle mb-0">

          <thead>
            <?php if ($tab === 'audit'): ?>
              <tr>
                <th>Fecha</th>
                <th>Usuario</th>
                <th>Acción</th>
                <th>IP</th>
                <th>Detalle</th>
              </tr>
            <?php else: ?>
              <tr>
                <th>Fecha</th>
                <th>Usuario</th>
                <th>Tipo</th>
                <th>Código</th>
                <th>Producto</th>
                <th>Cant.</th>
                <th>Stock Antes</th>
                <th>Stock Después</th>
                <th>Referencia</th>
                <th>Observación</th>
              </tr>
            <?php endif; ?>
          </thead>

          <tbody>

          <?php if (!$rows): ?>

            <tr>
              <td colspan="<?= $tab === 'audit' ? 5 : 10 ?>" class="text-center text-muted py-4">
                Sin registros con los filtros actuales
              </td>
            </tr>

          <?php else: foreach ($rows as $r): ?>

            <?php if ($tab === 'audit'): ?>

              <tr>
                <td class="text-muted"><?= e((string)$r['created_at']) ?></td>
                <td><?= e((string)($r['user_name'] ?? '—')) ?></td>
                <td class="fw-semibold"><?= e(action_label((string)$r['action'])) ?></td>
                <td><?= e((string)($r['ip_address'] ?? '')) ?></td>
                <td style="max-width:420px;white-space:normal;"><?= e(detail_label($r['details'])) ?></td>
              </tr>

            <?php else: ?>

              <tr>
                <td class="text-muted"><?= e((string)$r['created_at']) ?></td>
                <td><?= e((string)($r['user_name'] ?? '—')) ?></td>
                <td class="fw-semibold"><?= e((string)$r['tipo']) ?></td>
                <td><?= e((string)$r['codigo_producto']) ?></td>
                <td><?= e((string)$r['nombre_producto']) ?></td>
                <td><?= e((string)$r['cantidad']) ?></td>
                <td><?= e((string)$r['stock_antes']) ?></td>
                <td><?= e((string)$r['stock_despues']) ?></td>
                <td><?= e((string)$r['referencia']) ?></td>
                <td class="descripcion"><?= e((string)$r['observacion']) ?></td>
              </tr>

            <?php endif; ?>

          <?php endforeach; endif; ?>

          </tbody>

        </table>

      </div>

    </div>

  </div>

</div>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>