<?php
require_once __DIR__ . '/config/config.php';
$page = 'Dashboard';
$active = 'dashboard';

require_once __DIR__ . '/includes/layout.php';

$rateRow = db_one("SELECT setting_value FROM settings WHERE setting_key='usd_to_ves' LIMIT 1");
$usd_to_ves = $rateRow ? (float)$rateRow['setting_value'] : 0.0;

$total_productos = (int)(db_one('SELECT COUNT(*) AS c FROM products')['c'] ?? 0);
$total_categorias = (int)(db_one('SELECT COUNT(*) AS c FROM categorias')['c'] ?? 0);

$stock_bajo = (int)(db_one('SELECT COUNT(*) AS c FROM products WHERE stock <= stock_min AND stock > 0')['c'] ?? 0);
$agotados = (int)(db_one('SELECT COUNT(*) AS c FROM products WHERE stock <= 0')['c'] ?? 0);

$buscar = trim($_GET['buscar'] ?? '');
$params = [];
$where = '';
if ($buscar !== '') {
    
    $where = 'WHERE p.nombre_producto LIKE :q1 OR c.nombre_categoria LIKE :q2 OR p.codigo_producto LIKE :q3';
    $like = '%' . $buscar . '%';
    $params = ['q1' => $like, 'q2' => $like, 'q3' => $like];
}

$productos = db_all(
    "SELECT p.id_producto, p.codigo_producto, p.nombre_producto, p.precio_usd, p.stock, p.stock_min, c.nombre_categoria
     FROM products p
     LEFT JOIN categorias c ON c.id_categoria = p.id_categoria
     $where
     ORDER BY p.date_added DESC
     LIMIT 8",
    $params
);

?>

<!-- Estadísticas -->
<div class="row g-3 mb-4">

  <!-- TOTAL PRODUCTOS -->
  <div class="col-6 col-lg-3">
    <div class="card stat-card primary h-100">
      <div class="card-body">

        <div class="stat-header">
          <small class="stat-title">Total Productos</small>

          <div class="stat-icon">
            <i class="bi bi-box-seam"></i>
          </div>
        </div>

        <div class="stat-value"><?= e((string)$total_productos) ?></div>

        <div class="stat-sub">
          Categorías: <?= e((string)$total_categorias) ?>
        </div>

      </div>
    </div>
  </div>


  <!-- STOCK BAJO -->
  <div class="col-6 col-lg-3">
    <div class="card stat-card warning h-100">
      <div class="card-body">

        <div class="stat-header">
          <small class="stat-title">Stock Bajo</small>

          <div class="stat-icon">
            <i class="bi bi-exclamation-triangle"></i>
          </div>
        </div>

        <div class="stat-value"><?= e((string)$stock_bajo) ?></div>

        <div class="stat-sub">
          Umbral por producto (stock mín.)
        </div>

      </div>
    </div>
  </div>


  <!-- AGOTADOS -->
  <div class="col-6 col-lg-3">
    <div class="card stat-card danger h-100">
      <div class="card-body">

        <div class="stat-header">
          <small class="stat-title">Agotados</small>

          <div class="stat-icon">
            <i class="bi bi-x-circle"></i>
          </div>
        </div>

        <div class="stat-value"><?= e((string)$agotados) ?></div>

        <div class="stat-sub">
          Revisa compras/reposición
        </div>

      </div>
    </div>
  </div>


  <!-- TASA -->
  <div class="col-6 col-lg-3">
    <div class="card stat-card success h-100">
      <div class="card-body">

        <div class="stat-header">
          <small class="stat-title">Tasa USD → Bs</small>

          <div class="stat-icon">
            <i class="bi bi-currency-dollar"></i>
          </div>
        </div>

        <div class="stat-value">
          <?= $usd_to_ves > 0 ? e(number_format($usd_to_ves, 2)) : '—' ?>
        </div>

        <div class="stat-sub">
          Configurable por admin
        </div>

      </div>
    </div>
  </div>

</div>

<div class="row g-3">
  <div class="col-12">

    <div class="card table-card">

      <!-- HEADER -->
      <div class="card-header table-header">

        <div>
          <h5 class="card-title mb-1">Productos recientes</h5>
          <small class="text-muted">Incluye indicador de stock bajo / agotado</small>
        </div>

        <div class="table-actions">
          <a class="btn btn-outline-success btn-sm" href="export.php?type=products">
            <i class="bi bi-file-earmark-excel"></i> Exportar
          </a>
    

          <a class="btn btn-primary btn-sm" href="productos">
            <i class="bi bi-box"></i> Ver productos
          </a>
        </div>

      </div>

      <!-- BODY -->
      <div class="card-body">

 <!-- BUSCADOR -->
<form class="table-search mb-3" method="GET">

  <div class="search-bar">

    <!-- INPUT -->
    <div class="search-input-wrap">

      <i class="bi bi-search search-icon"></i>

      <input
        class="form-control search-input"
        name="buscar"
        maxlength="40"
        placeholder="Buscar por código, producto o categoría"
        value="<?= e($buscar) ?>">

      <?php if(!empty($buscar)): ?>
        <a href="dashboard" class="clear-search" title="Limpiar">
          <i class="bi bi-x"></i>
        </a>
      <?php endif; ?>

    </div>


    <!-- BOTONES -->
    <div class="search-actions">

      <button class="btn btn-search" type="submit">
        <i class="bi bi-search"></i>
        Buscar
      </button>

      <a class="btn btn-refresh" href="dashboard">
        <i class="bi bi-arrow-clockwise"></i>
      </a>

    </div>

  </div>

</form>

        <!-- TABLA -->
        <div class="table-responsive table-modern">

          <table class="table align-middle mb-0">
            <thead>
              <tr>
                <th>Código</th>
                <th>Producto</th>
                <th>Categoría</th>
                <th>Stock</th>
                <th>Precio (USD)</th>
                <th>Precio (Bs)</th>
                <th>Estado</th>
              </tr>
            </thead>

            <tbody>

              <?php if (!$productos): ?>
                <tr>
                  <td colspan="7" class="text-center text-muted py-4">
                    No hay productos
                  </td>
                </tr>

              <?php else: foreach ($productos as $p):

                $stock = (int)$p['stock'];
                $min = (int)$p['stock_min'];
                $estado = $stock <= 0 ? 'agotado' : ($stock <= $min ? 'bajo' : 'ok');
                $badge = $estado === 'agotado' ? 'danger' : ($estado === 'bajo' ? 'warning' : 'success');

                $precioUsd = (float)$p['precio_usd'];
                $precioBs = $usd_to_ves > 0 ? $precioUsd * $usd_to_ves : null;

              ?>

                <tr>

                  <td class="text-muted fw-medium">
                    <?= e($p['codigo_producto']) ?>
                  </td>

                  <td class="fw-semibold">
                    <?= e($p['nombre_producto']) ?>
                  </td>

                  <td><?= e($p['nombre_categoria'] ?? '—') ?></td>

                  <td>
                    <strong><?= e((string)$stock) ?></strong>
                    <span class="text-muted"> / mín <?= e((string)$min) ?></span>
                  </td>

                  <td>$<?= e(number_format($precioUsd, 2)) ?></td>

                  <td>
                    <?= $precioBs === null ? '—' : 'Bs ' . e(number_format($precioBs, 2)) ?>
                  </td>

                  <td>
                    <span class="badge-modern <?= e($estado) ?>">
                      <?= e(strtoupper($estado)) ?>
                    </span>
                  </td>

                </tr>

              <?php endforeach; endif; ?>

            </tbody>
          </table>

        </div>

      </div>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
