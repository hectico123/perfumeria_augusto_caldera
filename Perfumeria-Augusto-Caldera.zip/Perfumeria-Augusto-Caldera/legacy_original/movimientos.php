<?php
require_once __DIR__ . '/config/config.php';
$page = 'Entradas / Salidas';
$active = 'movimientos';

/* =========================
   HELPERS FORM
========================= */
function movimiento_old_set(array $data): void {
    $_SESSION['_movimiento_old_input'] = $data;
}
function movimiento_old_get(): array {
    return $_SESSION['_movimiento_old_input'] ?? [];
}
function movimiento_old_clear(): void {
    unset($_SESSION['_movimiento_old_input']);
}

/* =========================
   DATOS BASE
========================= */
$productos = db_all(
'SELECT id_producto, codigo_producto, nombre_producto, stock
 FROM products
 ORDER BY nombre_producto ASC'
);

/* =========================
   POST
========================= */
if (is_post()) {

csrf_verify();

$tipo = trim($_POST['tipo'] ?? '');
$id_producto = (int)($_POST['id_producto'] ?? 0);
$cantidad = (int)($_POST['cantidad'] ?? 0);
$referencia = trim($_POST['referencia'] ?? '');
$observacion = trim($_POST['observacion'] ?? '');

movimiento_old_set(compact('tipo','id_producto','cantidad','referencia','observacion'));

$validos=['ENTRADA','SALIDA','AJUSTE_POSITIVO','AJUSTE_NEGATIVO'];

if(!in_array($tipo,$validos,true)){
flash_set('danger','Selecciona un tipo válido.');
redirect('movimientos.php');
}

if($id_producto<=0){
flash_set('danger','Selecciona un producto.');
redirect('movimientos.php');
}

if($cantidad<=0){
flash_set('danger','La cantidad debe ser mayor a 0.');
redirect('movimientos.php');
}

$p=db_one('SELECT stock,codigo_producto,nombre_producto FROM products WHERE id_producto=:id',[':id'=>$id_producto]);

if(!$p){
flash_set('danger','Producto no existe.');
redirect('movimientos.php');
}

$antes=(int)$p['stock'];
$despues=$antes;

if($tipo==='ENTRADA'||$tipo==='AJUSTE_POSITIVO') $despues+=$cantidad;

if($tipo==='SALIDA'||$tipo==='AJUSTE_NEGATIVO'){
if($cantidad>$antes){
flash_set('danger','Cantidad mayor al stock.');
redirect('movimientos.php');
}
$despues-=$cantidad;
}

db_exec('UPDATE products SET stock=:s WHERE id_producto=:id',[':s'=>$despues,':id'=>$id_producto]);

db_exec(
'INSERT INTO movimientos (tipo,id_producto,cantidad,stock_antes,stock_despues,referencia,observacion,user_id,created_at)
VALUES (:t,:id,:c,:a,:d,:r,:o,:u,NOW())',
[
':t'=>$tipo,
':id'=>$id_producto,
':c'=>$cantidad,
':a'=>$antes,
':d'=>$despues,
':r'=>$referencia?:null,
':o'=>$observacion?:null,
':u'=>(int)(current_user()['id']??0)
]);

movimiento_old_clear();
flash_set('success','Movimiento registrado.');
redirect('movimientos.php');
}

/* =========================
   BUSQUEDA
========================= */
$old=movimiento_old_get();
movimiento_old_clear();

$buscar=trim($_GET['buscar']??'');
$params=[];
$where='';

if($buscar!==''){
$where="WHERE p.codigo_producto LIKE :q1 OR p.nombre_producto LIKE :q2 OR m.tipo LIKE :q3 OR COALESCE(m.referencia,'') LIKE :q4";
$like="%$buscar%";
$params=[':q1'=>$like,':q2'=>$like,':q3'=>$like,':q4'=>$like];
}

$movimientos=db_all(
"SELECT m.*,p.codigo_producto,p.nombre_producto,u.user_name
FROM movimientos m
LEFT JOIN products p ON p.id_producto=m.id_producto
LEFT JOIN users u ON u.user_id=m.user_id
$where
ORDER BY m.created_at DESC",
$params
);

require_once __DIR__ . '/includes/layout.php';
?>

<div class="row g-3">

<!-- ================= FORM ================= -->
<div class="col-12 col-lg-4">
<div class="card stat-card primary h-100">

<div class="card-header form-header">
<h5 class="card-title mb-0">
<i class="bi bi-arrow-left-right me-2"></i>
Registrar movimiento
</h5>
<small class="text-muted">Especifica producto por código y nombre, y aparte la cantidad</small>
</div>

<div class="card-body">

<form method="POST">

<?= csrf_field() ?>

<div class="mb-3">
<label class="form-label">Tipo de movimiento</label>
<select class="form-control form-modern" name="tipo" required>
<option value="">Selecciona...</option>
<option value="ENTRADA" <?=($old['tipo']??'')==='ENTRADA'?'selected':''?>>ENTRADA (reposiciones)</option>
<option value="SALIDA" <?=($old['tipo']??'')==='SALIDA'?'selected':''?>>SALIDA (ventas)</option>
<option value="AJUSTE_POSITIVO" <?=($old['tipo']??'')==='AJUSTE_POSITIVO'?'selected':''?>>AJUSTE +</option>
<option value="AJUSTE_NEGATIVO" <?=($old['tipo']??'')==='AJUSTE_NEGATIVO'?'selected':''?>>AJUSTE -</option>
</select>
</div>

<div class="mb-3">
<label class="form-label">Producto (código - nombre)</label>
<select class="form-control form-modern" name="id_producto" required>
<option value="">Selecciona...</option>
<?php foreach($productos as $p): ?>
<option value="<?=$p['id_producto']?>" <?=($old['id_producto']??0)==$p['id_producto']?'selected':''?>>
<?=e($p['codigo_producto'].' - '.$p['nombre_producto'].' | Stock: '.$p['stock'])?>
</option>
<?php endforeach;?>
</select>
<div class="form-text">Aquí eliges el producto por su código y nombre.</div>
</div>

<div class="mb-3">
<label class="form-label">Cantidad a mover</label>
<input class="form-control form-modern" type="number" name="cantidad" min="1"
value="<?=e($old['cantidad']??'')?>" required>
<div class="form-text">Este número corresponde a la cantidad, no al código.</div>
</div>

<div class="mb-3">
<label class="form-label">Referencia (opcional)</label>
<input class="form-control form-modern" name="referencia"
placeholder="Factura, nota, venta #..."
maxlength="20"
value="<?=e($old['referencia']??'')?>">
</div>

<div class="mb-3">
<label class="form-label">Observación (opcional)</label>
<textarea class="form-control form-modern" name="observacion" maxlength="255"
placeholder="Detalle adicional"
value="<?=e($old['observacion']??'')?>"></textarea>
</div>

<div class="form-actions">
<button class="btn btn-save w-100"><i class="bi bi-check-lg"></i> Guardar movimiento</button>
</div>

</form>

</div>
</div>
</div>


<!-- ================= TABLA ================= -->
<div class="col-12 col-lg-8">

<div class="card stat-card primary table-card h-100">

<div class="card-header table-header">
<div>
<h5 class="card-title mb-1">Historial de movimientos</h5>
<small class="text-muted">Últimos registros de entradas, salidas y ajustes</small>
</div>

<a class="btn btn-outline-success btn-sm" href="export.php?type=movimientos">
<i class="bi bi-file-earmark-excel"></i> Exportar
</a>
</div>

<form class="table-search m-3" method="GET">
<div class="search-bar">

<div class="search-input-wrap">
<i class="bi bi-search search-icon"></i>

<input class="form-control search-input"
name="buscar"
placeholder="Buscar por producto, tipo o referencia"
value="<?=e($buscar)?>">

<?php if($buscar): ?>
<a href="movimientos.php" class="clear-search"><i class="bi bi-x"></i></a>
<?php endif; ?>
</div>

<div class="search-actions">
<button class="btn btn-search"><i class="bi bi-search"></i>Buscar</button>
<a class="btn btn-refresh" href="movimientos.php"><i class="bi bi-arrow-clockwise"></i></a>
</div>

</div>
</form>

<div class="card-body">

<div class="table-responsive table-modern">

<table class="table align-middle mb-0">

<thead>
<tr>
<th>Fecha</th>
<th>Tipo</th>
<th>Producto</th>
<th>Cantidad</th>
<th>Antes</th>
<th>Después</th>
<th>Referencia</th>
<th>Usuario</th>
</tr>
</thead>

<tbody>

<?php if(!$movimientos): ?>

<tr>
<td colspan="8" class="text-center text-muted py-4">No hay movimientos</td>
</tr>

<?php else: foreach($movimientos as $m):

$tipo=$m['tipo'];
$estadoClass=$tipo==='ENTRADA'?'success':($tipo==='SALIDA'?'danger':($tipo==='AJUSTE_POSITIVO'?'primary':'warning'));

?>

<tr>

<td><?=e($m['created_at'])?></td>

<td>
<span class="badge-modern <?=$estadoClass?>">
<?=e($tipo)?>
</span>
</td>

<td>
<div class="fw-semibold"><?=e($m['nombre_producto']??'—')?></div>
<div class="small text-muted"><?=e($m['codigo_producto']??'—')?></div>
</td>

<td><?=e($m['cantidad'])?></td>
<td><?=e($m['stock_antes'])?></td>
<td><?=e($m['stock_despues'])?></td>

<td class="descripcion">
<?=e($m['referencia']??'—')?>
<?php if(!empty($m['observacion'])): ?>
<div class="small text-muted"><?=e($m['observacion'])?></div>
<?php endif;?>
</td>

<td><?=e($m['user_name']??'—')?></td>

</tr>

<?php endforeach; endif; ?>

</tbody>

</table>

</div>
</div>
</div>
</div>
</div>

<?php require_once __DIR__ . '/includes/layout_footer.php'; ?>
