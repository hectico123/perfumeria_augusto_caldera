<?php

declare(strict_types=1);

if (!ob_get_level()) {
    ob_start();
}

defined('BASE_PATH') or define('BASE_PATH', dirname(__DIR__));

define('APP_NAME', 'Perfumería Augusto Caldera');
define('APP_VERSION', '3.0.0');
define('APP_ENV', 'production');

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['SERVER_PORT'] ?? '') === '443')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

$scheme = $isHttps ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$scriptDir = dirname($scriptName);
$scriptDir = $scriptDir === '.' ? '' : rtrim($scriptDir, '/');
$requestPath = (string) (parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
$fallbackDir = '/' . basename(BASE_PATH);

if ($scriptDir !== '' && $scriptDir !== '/') {
    $basePath = $scriptDir;
} elseif ($requestPath === $fallbackDir || str_starts_with($requestPath, $fallbackDir . '/')) {
    $basePath = $fallbackDir;
} else {
    $basePath = '';
}

define('BASE_URL', $scheme . '://' . $host . ($basePath !== '' ? $basePath : '') . '/');
define('ASSETS_URL', BASE_URL . 'assets/');

date_default_timezone_set('America/Caracas');

ini_set('session.cookie_httponly', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.cookie_secure', $isHttps ? '1' : '0');

if (session_status() === PHP_SESSION_NONE) {
    session_name('pac_inventory_session');
    session_start();
}

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
header("Content-Security-Policy: default-src 'self' https: data: 'unsafe-inline' 'unsafe-eval'; frame-ancestors 'self';");

if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}

define('DB_HOST', 'localhost');
define('DB_NAME', 'perfumeria_augusto_caldera');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

define('ITEMS_PER_PAGE', 10);
define('PASSWORD_MIN_LEN', 16);

define('MAIL_MODE', 'log');
define('RECAPTCHA_SITE_KEY', getenv('RECAPTCHA_SITE_KEY') ?: '6LfYqJUsAAAAAL7VzEtKZjyPw_S2XjDh92cvNaS0');
define('RECAPTCHA_SECRET_KEY', getenv('RECAPTCHA_SECRET_KEY') ?: '6LfYqJUsAAAAAM2GXfJ9ZPMC3AlPThEVI5E787v_');

define('RECAPTCHA_ENABLED', RECAPTCHA_SITE_KEY !== '' && RECAPTCHA_SECRET_KEY !== '');

function verify_recaptcha(string $token, ?string $remoteIp = null): array {
    if (!RECAPTCHA_ENABLED) {
        return ['ok' => true, 'message' => 'Captcha deshabilitado.'];
    }

    if ($token === '') {
        return ['ok' => false, 'message' => 'Debes completar el captcha.'];
    }

    $postData = http_build_query([
        'secret'   => RECAPTCHA_SECRET_KEY,
        'response' => $token,
        'remoteip' => $remoteIp ?? '',
    ]);

    $responseBody = false;

    if (function_exists('curl_init')) {
        $ch = curl_init('https://www.google.com/recaptcha/api/siteverify');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
        ]);
        $responseBody = curl_exec($ch);
        curl_close($ch);
    } else {
        $context = stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                'content' => $postData,
                'timeout' => 15,
            ],
        ]);
        $responseBody = @file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $context);
    }

    if ($responseBody === false || $responseBody === '') {
        return ['ok' => false, 'message' => 'No se pudo validar el captcha.'];
    }

    $result = json_decode($responseBody, true);

    if (!is_array($result) || !isset($result['success'])) {
        return ['ok' => false, 'message' => 'Respuesta inválida del captcha.'];
    }

    if ((bool) $result['success'] !== true) {
        return ['ok' => false, 'message' => 'Captcha inválido. Intenta nuevamente.'];
    }

    return ['ok' => true, 'message' => 'Captcha válido.'];
}

require_once BASE_PATH . '/includes/helpers.php';
require_once BASE_PATH . '/includes/db.php';
require_once BASE_PATH . '/includes/csrf.php';
require_once BASE_PATH . '/includes/auth.php';
require_once BASE_PATH . '/includes/audit.php';
require_once BASE_PATH . '/includes/password_reset.php';
