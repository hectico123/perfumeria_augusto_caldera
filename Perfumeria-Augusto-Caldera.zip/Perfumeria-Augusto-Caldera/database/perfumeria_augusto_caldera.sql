-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-03-2026 a las 00:08:20
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `perfumeria_augusto_caldera`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(64) NOT NULL,
  `entity` varchar(64) NOT NULL DEFAULT '',
  `entity_id` int(11) DEFAULT NULL,
  `ip` varchar(64) NOT NULL DEFAULT '',
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  `details_json` text DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `entity`, `entity_id`, `ip`, `user_agent`, `details_json`, `created_at`) VALUES
(1, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-23 18:31:53'),
(2, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-23 18:31:59'),
(3, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-23 18:50:05'),
(4, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-23 18:50:29'),
(5, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-24 12:55:58'),
(6, 1, 'EXPORT', 'movimientos', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"type\":\"movimientos\"}', '2026-02-24 13:00:18'),
(7, 1, 'EXPORT', 'audit', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"type\":\"audit\"}', '2026-02-24 13:00:31'),
(8, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-24 13:02:08'),
(9, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-24 13:05:45'),
(10, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-24 19:00:59'),
(11, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-24 19:01:11'),
(12, 1, 'PRODUCT_CREATE', 'product', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"regh\",\"nombre_producto\":\"rweg\",\"precio_usd\":14,\"stock\":14,\"stock_min\":5,\"id_categoria\":1}', '2026-02-24 19:02:11'),
(13, 1, 'CATEGORY_CREATE', 'category', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"nombre_categoria\":\"23\",\"descripcion_categoria\":\"b12b\"}', '2026-02-24 19:02:21'),
(14, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-24 19:04:29'),
(15, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-24 19:04:46'),
(16, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-24 19:06:01'),
(17, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-26 18:31:37'),
(18, 1, 'USER_CREATE', 'users', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"user_name\":\"Denyer\",\"role\":\"user\"}', '2026-02-26 18:32:58'),
(19, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-26 18:33:33'),
(20, 2, 'LOGIN_OK', 'auth', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-26 18:33:45'),
(21, 2, 'LOGOUT', 'auth', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-26 18:35:43'),
(22, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-26 18:36:28'),
(23, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-26 18:36:35'),
(24, 2, 'LOGIN_OK', 'auth', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-02-26 18:36:43'),
(25, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 13:32:43'),
(26, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 13:34:25'),
(27, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 13:47:29'),
(28, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 13:56:58'),
(29, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 13:57:07'),
(30, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 14:08:41'),
(31, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 14:11:38'),
(32, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 14:21:28'),
(33, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 14:21:34'),
(34, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 14:21:45'),
(35, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 14:21:49'),
(36, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 14:21:56'),
(37, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 14:22:05'),
(38, 1, 'PRODUCT_CREATE', 'product', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"erg\",\"nombre_producto\":\"erg\",\"precio_usd\":2334,\"stock\":23,\"stock_min\":5,\"id_categoria\":3}', '2026-03-10 14:34:03'),
(39, 1, 'CATEGORY_CREATE', 'category', 4, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"nombre_categoria\":\"2r\",\"descripcion_categoria\":\"23r\"}', '2026-03-10 14:34:12'),
(40, 1, 'PRODUCT_DELETE', 'product', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"erg\",\"nombre_producto\":\"erg\"}', '2026-03-10 14:34:32'),
(41, 1, 'CATEGORY_DELETE', 'category', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"nombre_categoria\":\"23\",\"descripcion_categoria\":\"b12b\"}', '2026-03-10 14:34:37'),
(42, 1, 'CATEGORY_DELETE', 'category', 4, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"nombre_categoria\":\"2r\",\"descripcion_categoria\":\"23r\"}', '2026-03-10 14:34:40'),
(43, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 15:04:49'),
(44, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 15:05:21'),
(45, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 15:21:03'),
(46, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 15:21:47'),
(47, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 15:36:50'),
(48, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 15:36:53'),
(49, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 15:51:38'),
(50, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 15:51:40'),
(51, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 17:17:20'),
(52, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 17:18:31'),
(53, 1, 'PRODUCT_CREATE', 'product', 4, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"dg\",\"nombre_producto\":\"erg\",\"precio_usd\":10,\"stock\":10,\"stock_min\":5,\"id_categoria\":2}', '2026-03-10 17:36:43'),
(54, 1, 'CATEGORY_CREATE', 'category', 5, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"nombre_categoria\":\"bf\",\"descripcion_categoria\":\"rg\"}', '2026-03-10 17:36:56'),
(55, 1, 'MOVEMENT_CREATE', 'movimientos', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"tipo\":\"SALIDA\",\"id_producto\":4,\"codigo_producto\":\"dg\",\"nombre_producto\":\"erg\",\"cantidad\":5,\"stock_antes\":10,\"stock_despues\":5,\"referencia\":\"reg\",\"observacion\":\"rge\"}', '2026-03-10 17:37:16'),
(56, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 17:49:42'),
(57, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:00:49'),
(58, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:00:51'),
(59, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:00:52'),
(60, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:14:12'),
(61, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:14:16'),
(62, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:14:22'),
(63, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:15:15'),
(64, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:31:31'),
(65, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:33:55'),
(66, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:41:22'),
(67, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:41:26'),
(68, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:46:17'),
(69, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:48:01'),
(70, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:48:06'),
(71, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:49:00'),
(72, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:50:46'),
(73, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:50:52'),
(74, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 18:58:42'),
(75, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 19:00:04'),
(76, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 19:00:13'),
(77, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 19:00:21'),
(78, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36', '[]', '2026-03-10 19:01:24'),
(79, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 19:02:58'),
(80, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 19:03:15'),
(81, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 19:03:20'),
(82, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 19:04:27'),
(83, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 19:07:52'),
(84, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 19:08:13'),
(85, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 19:08:15'),
(86, 1, 'EXPORT', 'products', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"type\":\"products\"}', '2026-03-10 19:15:33'),
(87, 1, 'CATEGORY_CREATE', 'category', 6, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"nombre_categoria\":\"fdg\",\"descripcion_categoria\":\"rsdg\"}', '2026-03-10 19:31:43'),
(88, 1, 'CATEGORY_DELETE', 'category', 6, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"nombre_categoria\":\"fdg\",\"descripcion_categoria\":\"rsdg\"}', '2026-03-10 19:32:31'),
(89, 1, 'CATEGORY_DELETE', 'category', 5, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"nombre_categoria\":\"bf\",\"descripcion_categoria\":\"rg\"}', '2026-03-10 19:32:35'),
(90, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 19:55:58'),
(91, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 19:56:00'),
(92, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 20:21:43'),
(93, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 20:22:08'),
(94, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-10 20:22:09'),
(95, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-11 20:36:03'),
(96, 1, 'CATEGORY_CREATE', 'category', 7, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"nombre_categoria\":\"9p\",\"descripcion_categoria\":\"98p\"}', '2026-03-11 20:36:39'),
(97, 1, 'CATEGORY_DELETE', 'category', 7, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"nombre_categoria\":\"9p\",\"descripcion_categoria\":\"98p\"}', '2026-03-11 20:36:45'),
(98, 1, 'CATEGORY_CREATE', 'category', 8, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"nombre_categoria\":\"p\",\"descripcion_categoria\":\"8p\"}', '2026-03-11 20:36:54'),
(99, 1, 'MOVEMENT_CREATE', 'movimientos', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"tipo\":\"ENTRADA\",\"id_producto\":4,\"codigo_producto\":\"dg\",\"nombre_producto\":\"erg\",\"cantidad\":3,\"stock_antes\":5,\"stock_despues\":8,\"referencia\":\"reg\",\"observacion\":\"erh\"}', '2026-03-11 21:51:17'),
(100, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-11 22:36:07'),
(101, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-11 22:36:10'),
(102, 1, 'PRODUCT_CREATE', 'product', 5, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"ewg\",\"nombre_producto\":\"wg\",\"precio_usd\":0,\"stock\":0,\"stock_min\":5,\"id_categoria\":2}', '2026-03-11 22:49:51'),
(103, 1, 'PRODUCT_CREATE', 'product', 6, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"wg\",\"nombre_producto\":\"e3gw\",\"precio_usd\":0,\"stock\":0,\"stock_min\":5,\"id_categoria\":1}', '2026-03-11 22:50:03'),
(104, 1, 'PRODUCT_CREATE', 'product', 7, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"wgw\",\"nombre_producto\":\"wg\",\"precio_usd\":0,\"stock\":0,\"stock_min\":5,\"id_categoria\":2}', '2026-03-11 22:50:17'),
(105, 1, 'PRODUCT_DELETE', 'product', 7, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"wgw\",\"nombre_producto\":\"wg\"}', '2026-03-11 22:50:37'),
(106, 1, 'PRODUCT_DELETE', 'product', 6, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"wg\",\"nombre_producto\":\"e3gw\"}', '2026-03-11 22:50:39'),
(107, 1, 'PRODUCT_DELETE', 'product', 5, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"ewg\",\"nombre_producto\":\"wg\"}', '2026-03-11 22:50:41'),
(108, 1, 'PRODUCT_DELETE', 'product', 4, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"dg\",\"nombre_producto\":\"erg\"}', '2026-03-11 22:50:43'),
(109, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-11 22:52:40'),
(110, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-11 22:53:25'),
(111, 1, 'PRODUCT_UPDATE', 'product', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"regh\",\"nombre_producto\":\"gnfn\",\"precio_usd\":14,\"stock\":9,\"stock_min\":5,\"id_categoria\":1}', '2026-03-11 23:48:40'),
(112, 1, 'CATEGORY_UPDATE', 'category', 8, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"nombre_categoria\":\"pgh\",\"descripcion_categoria\":\"8p\"}', '2026-03-11 23:48:49'),
(113, 1, 'CATEGORY_DELETE', 'category', 8, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"nombre_categoria\":\"pgh\",\"descripcion_categoria\":\"8p\"}', '2026-03-11 23:48:55'),
(114, 1, 'USER_UPDATE', 'users', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-11 23:59:52'),
(115, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-12 00:00:03'),
(116, NULL, 'AUTH', 'password_reset_security_question', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-12 00:01:43'),
(117, 2, 'LOGIN_OK', 'auth', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-12 00:02:19'),
(118, 2, 'LOGOUT', 'auth', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-12 00:02:30'),
(119, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-12 00:02:33'),
(120, 1, 'USER_CREATE', 'users', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"user_name\":\"qf\",\"role\":\"user\"}', '2026-03-12 00:03:30'),
(121, 1, 'USER_DELETE_DENIED', 'users', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"reason\":\"bad_security_answer\"}', '2026-03-12 00:03:47'),
(122, 1, 'USER_DELETE_DENIED', 'users', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"reason\":\"bad_security_answer\"}', '2026-03-12 00:04:01'),
(123, 1, 'USER_DELETE_DENIED', 'users', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"reason\":\"bad_security_answer\"}', '2026-03-12 00:04:34'),
(124, 1, 'USER_DELETE_DENIED', 'users', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"reason\":\"bad_security_answer\"}', '2026-03-12 00:04:41'),
(125, 1, 'USER_UPDATE', 'users', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-12 00:04:59'),
(126, 1, 'USER_DELETE', 'users', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"by\":1}', '2026-03-12 00:05:12'),
(127, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-12 00:11:26'),
(128, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-12 00:12:34'),
(129, 1, 'PRODUCT_CREATE', 'product', 8, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"efweg\",\"nombre_producto\":\"weg\",\"precio_usd\":324235,\"stock\":10,\"stock_min\":5,\"id_categoria\":2}', '2026-03-12 00:15:35'),
(130, 1, 'PRODUCT_DELETE', 'product', 8, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"efweg\",\"nombre_producto\":\"weg\"}', '2026-03-12 00:15:52'),
(131, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-12 00:17:52'),
(132, NULL, 'AUTH', 'password_reset_security_question', 2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-12 00:18:49'),
(133, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-12 00:19:00'),
(134, 1, 'LOGOUT', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-12 00:30:26'),
(135, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-12 00:30:34'),
(136, 1, 'PRODUCT_CREATE', 'product', 102, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"ssssssssssssssssssss\",\"nombre_producto\":\"sssssssssssssssssssssssssssssssssssssssssssss\",\"precio_usd\":1120,\"stock\":120,\"stock_min\":5,\"id_categoria\":2}', '2026-03-12 00:35:39'),
(137, 1, 'USER_CREATE', 'users', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"user_name\":\"dwerf\",\"role\":\"user\"}', '2026-03-12 00:39:32'),
(138, 1, 'USER_DELETE', 'users', 4, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"by\":1}', '2026-03-12 00:39:49'),
(139, 1, 'PRODUCT_DELETE', 'product', 102, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"ssssssssssssssssssss\",\"nombre_producto\":\"ssssssssssssssssssss\"}', '2026-03-12 01:07:49'),
(140, 1, 'PRODUCT_CREATE', 'product', 103, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"fge31ger\",\"nombre_producto\":\"werg41wg\",\"precio_usd\":110,\"stock\":10,\"stock_min\":5,\"id_categoria\":2}', '2026-03-12 01:13:54'),
(141, 1, 'PRODUCT_DELETE', 'product', 103, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"codigo_producto\":\"fge31ger\",\"nombre_producto\":\"werg41wg\"}', '2026-03-12 01:14:02'),
(142, 1, 'EXPORT', 'products', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"type\":\"products\"}', '2026-03-12 01:25:34'),
(143, 1, 'EXPORT', 'products', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"type\":\"products\"}', '2026-03-12 01:39:37'),
(144, 1, 'LOGIN_OK', 'auth', 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '[]', '2026-03-12 18:23:22'),
(145, 1, 'EXPORT', 'products', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"type\":\"products\"}', '2026-03-12 19:03:33'),
(146, 1, 'EXPORT', 'categorias', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"type\":\"categorias\"}', '2026-03-12 19:04:29'),
(147, 1, 'EXPORT', 'products', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"type\":\"products\"}', '2026-03-12 19:06:12'),
(148, 1, 'EXPORT', 'categorias', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"type\":\"categorias\"}', '2026-03-12 19:06:30'),
(149, 1, 'EXPORT', 'products', NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '{\"type\":\"products\"}', '2026-03-12 19:06:54');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id_categoria` int(11) NOT NULL,
  `nombre_categoria` varchar(20) NOT NULL,
  `descripcion_categoria` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_categoria`, `nombre_categoria`, `descripcion_categoria`, `date_added`) VALUES
(1, 'Perfumes', 'Fragancias', '2026-02-22 00:00:00'),
(2, 'Esotéricos', 'Velones, amuletos, e', '2026-02-22 00:00:00');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `categories`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `categories` (
`id` int(11)
,`name` varchar(20)
,`description` varchar(255)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `exchange_rate_history`
--

CREATE TABLE `exchange_rate_history` (
  `id` int(11) NOT NULL,
  `rate` decimal(12,4) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `exchange_rate_history`
--

INSERT INTO `exchange_rate_history` (`id`, `rate`, `user_id`, `created_at`) VALUES
(1, 400.0000, 1, '2026-03-10 16:21:22'),
(2, 534.0000, 1, '2026-03-10 16:21:33'),
(3, 346.0000, 1, '2026-03-11 23:49:10'),
(4, 500.0000, 1, '2026-03-12 00:25:17');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimientos`
--

CREATE TABLE `movimientos` (
  `id_movimiento` int(11) NOT NULL,
  `tipo` enum('ENTRADA','SALIDA','AJUSTE_POSITIVO','AJUSTE_NEGATIVO') NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `stock_antes` int(11) NOT NULL,
  `stock_despues` int(11) NOT NULL,
  `referencia` varchar(20) NOT NULL,
  `observacion` varchar(255) NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `movimientos`
--

INSERT INTO `movimientos` (`id_movimiento`, `tipo`, `id_producto`, `cantidad`, `stock_antes`, `stock_despues`, `referencia`, `observacion`, `user_id`, `created_at`) VALUES
(1, 'ENTRADA', 1, 5, 13, 18, '1234', 'sg', 1, '2026-02-24 12:57:51'),
(2, 'ENTRADA', 1, 5, 18, 23, '1234', 'sg', 1, '2026-02-24 12:58:06'),
(3, 'ENTRADA', 1, 5, 23, 28, '1234', 'sg', 1, '2026-02-24 12:58:37'),
(4, 'SALIDA', 1, 10, 28, 18, '1234', 'ererh', 1, '2026-02-24 12:59:34'),
(5, 'SALIDA', 1, 15, 18, 3, '436', 'dfh', 1, '2026-02-24 13:01:26'),
(6, 'SALIDA', 1, 3, 3, 0, '45', 'dfbh', 1, '2026-02-24 13:01:44'),
(7, 'ENTRADA', 100, 14, 0, 14, 'REGISTRO_PRODUCTO', 'Alta de producto', 1, '2026-02-24 19:02:11'),
(8, 'SALIDA', 100, 5, 14, 9, 'reg', 'ertg', 1, '2026-02-24 19:02:45'),
(17, 'SALIDA', 100, 3, 9, 6, 'degs', 'sg', 1, '2026-03-12 00:20:33'),
(18, 'ENTRADA', 1, 5, 0, 5, 'eg', 'wegf', 1, '2026-03-12 00:20:53');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE `products` (
  `id_producto` int(11) NOT NULL,
  `codigo_producto` varchar(20) NOT NULL,
  `nombre_producto` varchar(20) NOT NULL,
  `date_added` datetime NOT NULL,
  `precio_usd` double NOT NULL DEFAULT 0,
  `stock` int(11) NOT NULL DEFAULT 0,
  `stock_min` int(11) NOT NULL DEFAULT 5,
  `id_categoria` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `products`
--

INSERT INTO `products` (`id_producto`, `codigo_producto`, `nombre_producto`, `date_added`, `precio_usd`, `stock`, `stock_min`, `id_categoria`) VALUES
(1, '1234', 'cf', '2026-02-23 18:32:24', 13, 5, 5, 1),
(100, 'regh', 'gnfn', '2026-02-24 19:02:11', 14, 6, 5, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `settings`
--

CREATE TABLE `settings` (
  `setting_key` varchar(50) NOT NULL,
  `setting_value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `settings`
--

INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('usd_to_ves', '500.0000');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `user_name` varchar(64) NOT NULL,
  `user_password_hash` varchar(255) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `failed_attempts` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `security_question` varchar(50) DEFAULT NULL,
  `security_answer_hash` varchar(255) DEFAULT NULL,
  `date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `user_name`, `user_password_hash`, `user_email`, `role`, `is_active`, `failed_attempts`, `locked_until`, `security_question`, `security_answer_hash`, `date_added`) VALUES
(1, 'Administrador', 'Sistema', 'admin', '$2y$10$YPIz4ySxifdL1n7c5dCaQuyTgxEttijbOn4GyAoC10msC7IqQYjxO', 'admin@perfumeria.com', 'admin', 1, 0, NULL, 'q_color', '$2y$10$RAqrJP.73h60FzSkN5TsvO4WDC5p6voL9wMIdv1/rhDCjiRyqTS7.', '2026-02-22 00:00:00'),
(2, 'Denyer', 'Bastidas', 'Denyer', '$2y$10$6rGC7fx.f4faHDr7UoGHwuGxdqYo05km6q1ieI5BESgl5ADrL.WNq', 'dbastidas00@gmail.com', 'user', 1, 0, NULL, 'q_color', '$2y$10$wE2PeIPIYxaMaSX2m6WQce3nwagzKNlgFRdn6VdOHc9GHDcdpYrd2', '2026-02-26 18:32:58');

-- --------------------------------------------------------

--
-- Estructura para la vista `categories`
--
DROP TABLE IF EXISTS `categories`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `categories`  AS SELECT `categorias`.`id_categoria` AS `id`, `categorias`.`nombre_categoria` AS `name`, `categorias`.`descripcion_categoria` AS `description` FROM `categorias` ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `action` (`action`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indices de la tabla `exchange_rate_history`
--
ALTER TABLE `exchange_rate_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_exchange_rate_created_at` (`created_at`),
  ADD KEY `idx_exchange_rate_user` (`user_id`);

--
-- Indices de la tabla `movimientos`
--
ALTER TABLE `movimientos`
  ADD PRIMARY KEY (`id_movimiento`),
  ADD KEY `idx_mov_producto` (`id_producto`),
  ADD KEY `idx_mov_user` (`user_id`),
  ADD KEY `idx_mov_fecha` (`created_at`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token_hash` (`token_hash`),
  ADD KEY `user_id` (`user_id`);

--
-- Indices de la tabla `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id_producto`),
  ADD UNIQUE KEY `codigo_producto` (`codigo_producto`),
  ADD KEY `id_categoria` (`id_categoria`);

--
-- Indices de la tabla `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_name` (`user_name`),
  ADD UNIQUE KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `exchange_rate_history`
--
ALTER TABLE `exchange_rate_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `movimientos`
--
ALTER TABLE `movimientos`
  MODIFY `id_movimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `products`
--
ALTER TABLE `products`
  MODIFY `id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `exchange_rate_history`
--
ALTER TABLE `exchange_rate_history`
  ADD CONSTRAINT `fk_exchange_rate_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `movimientos`
--
ALTER TABLE `movimientos`
  ADD CONSTRAINT `fk_mov_producto` FOREIGN KEY (`id_producto`) REFERENCES `products` (`id_producto`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mov_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `fk_pr_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
