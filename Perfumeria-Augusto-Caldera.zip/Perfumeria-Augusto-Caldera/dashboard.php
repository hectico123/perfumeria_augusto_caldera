<?php

declare(strict_types=1);
$_GET['route'] = 'categorias';
$_GET['route'] = 'configuracion';
$_GET['route'] = 'forgot-password';
$_GET['route'] = 'export';
$_GET['route'] = 'auditoria';
$_GET['route'] = 'dashboard';
$_GET['route'] = 'logout';
$_GET['route'] = 'movimientos';
$_GET['route'] = 'reset-password';
$_GET['route'] = 'productos';
$_GET['route'] = 'usuarios/eliminar';
$_GET['route'] = 'usuarios';
require __DIR__ . '/index.php';
