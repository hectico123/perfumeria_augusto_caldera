<?php

declare(strict_types=1);

use App\Core\View;

function run_controller_script(string $controllerFile): array
{
    return (static function (string $__file): array {
        require $__file;
        $vars = get_defined_vars();
        unset($vars['__file']);
        return $vars;
    })($controllerFile);
}

function dispatch_page(string $controllerName, string $viewName, bool $withLayout = true): void
{
    if ($withLayout) {
        require_login();
    }

    $data = run_controller_script(BASE_PATH . '/app/Controllers/' . $controllerName . '.php');
    View::render(BASE_PATH . '/app/Views/pages/' . $viewName . '.php', $data, $withLayout);
}

function dispatch_controller_only(string $controllerName): void
{
    run_controller_script(BASE_PATH . '/app/Controllers/' . $controllerName . '.php');
}
