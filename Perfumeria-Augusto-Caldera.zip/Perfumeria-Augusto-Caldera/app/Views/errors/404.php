<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>404 - <?= e(APP_NAME) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center" style="min-height:100vh;">
  <div class="container py-5">
    <div class="card shadow-sm border-0 mx-auto" style="max-width:720px;">
      <div class="card-body p-4 p-md-5">
        <div class="display-6 fw-bold mb-2">404</div>
        <h1 class="h3 mb-3">Ruta no encontrada</h1>
        <p class="text-muted mb-4">La ruta solicitada <?= isset($requestedPath) && $requestedPath !== '' ? '<code>' . e($requestedPath) . '</code>' : 'no existe' ?> no está registrada en el sistema.</p>
        <div class="d-flex gap-2 flex-wrap">
          <a class="btn btn-primary" href="<?= e(url(is_logged_in() ? 'dashboard' : 'login')) ?>">Ir al sistema</a>
          <?php if (is_logged_in()): ?>
            <a class="btn btn-outline-secondary" href="<?= e(url('dashboard')) ?>">Volver al dashboard</a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
