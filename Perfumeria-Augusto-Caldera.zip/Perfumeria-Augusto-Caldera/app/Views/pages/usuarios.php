<div class="row g-3">

  <!-- ===================== FORMULARIO ===================== -->
  <div class="col-12 col-lg-4">
    <div class="card stat-card primary h-100">

      <div class="card-header form-header">
        <h5 class="card-title mb-0">
          <i class="bi bi-people me-2"></i>
          <?= $edit ? 'Editar usuario' : 'Nuevo usuario' ?>
        </h5>
      </div>

      <div class="card-body">
        <form method="POST">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="<?= $edit ? 'update' : 'create' ?>">
          <input type="hidden" name="user_id" value="<?= e((string)($edit['user_id'] ?? 0)) ?>">

          <div class="row g-2">
            <div class="col-6">
              <label class="form-label">Nombres</label>
              <input
                class="form-control form-modern"
                name="firstname"
                maxlength="20"
                required
                value="<?= e(user_form_value($old,$edit,'firstname')) ?>"
                oninput="this.value=this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñÜü ]/g,'');">
            </div>

            <div class="col-6">
              <label class="form-label">Apellidos</label>
              <input
                class="form-control form-modern"
                name="lastname"
                maxlength="20"
                required
                value="<?= e(user_form_value($old,$edit,'lastname')) ?>"
                oninput="this.value=this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñÜü ]/g,'');">
            </div>
          </div>

          <div class="row g-2">
             <div class="col-6">
           
                <label class="form-label">Usuario</label>
                <input class="form-control form-modern" name="user_name" required
                maxlength="20"
                value="<?= e(user_form_value($old,$edit,'user_name')) ?>">
      
            </div>

            <div class="col-6">
           
                <label class="form-label">Email</label>
                <input class="form-control form-modern" name="user_email" required
                maxlength="35"
                value="<?= e(user_form_value($old,$edit,'user_email')) ?>">
             
            </div>

          </div>


          <div class="row g-2">
            <div class="col-6">
              <label class="form-label">Rol</label>
              <select class="form-select form-modern" name="role">
                <option value="user" <?= user_form_value($old,$edit,'role','user')==='user'?'selected':'' ?>>Usuario</option>
                <option value="admin" <?= user_form_value($old,$edit,'role','user')==='admin'?'selected':'' ?>>Admin</option>
              </select>
            </div>

            <div class="col-6 d-flex align-items-end">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="is_active" id="is_active" <?= $currentIsActive?'checked':'' ?>>
                <label class="form-check-label" for="is_active">Activo</label>
              </div>
            </div>
          </div>

          <div class="mb-3 mt-2">
            <label class="form-label">Pregunta de seguridad (solo Admin)</label>
            <select class="form-select form-modern" name="security_question">
              <option value="">Selecciona una pregunta</option>
              <?php foreach ($securityQuestions as $code => $label): ?>
                <option value="<?= e($code) ?>" <?= (($edit['security_question'] ?? '') === $code) ? 'selected' : '' ?>>
                  <?= e($label) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label">Respuesta (solo Admin)</label>
            <input maxlength="20" class="form-control form-modern" type="password" name="security_answer">
          </div>

<div class="mb-3">
  <label class="form-label">
    Contraseña <?= $edit ? '(opcional)' : '' ?>
  </label>

  <div class="input-group">
    <input 
      id="passwordInputEdit"
      class="form-control form-modern" 
      name="password" 
      type="password"
      minlength="16"
      <?= $edit ? '' : 'required' ?>
    >

    <button 
      class="input-group-text bg-white" 
      type="button" 
      id="togglePasswordEdit"
      style="cursor:pointer;"
    >
      <i class="bi bi-eye" id="iconPasswordEdit"></i>
    </button>
  </div>

  <div class="form-text">Mínimo 16 caracteres.</div>
</div>

          <div class="form-actions">
            <button class="btn btn-save" type="submit">
              <i class="bi bi-check-lg"></i>
              <?= $edit ? 'Guardar cambios' : 'Crear usuario' ?>
            </button>

            <?php if ($edit): ?>
              <a class="btn btn-cancel" href="usuarios.php">Cancelar</a>
            <?php endif; ?>
          </div>

        </form>
      </div>
    </div>
  </div>

  <!-- ===================== TABLA ===================== -->
  <div class="col-12 col-lg-8">
    <div class="card stat-card primary table-card h-100">

      <div class="card-header table-header">
        <div>
          <h5 class="card-title mb-1">Listado de usuarios</h5>
          <small class="text-muted">Admin tiene todos los privilegios</small>
        </div>

        <a class="btn btn-outline-success btn-sm" href="export.php?type=users">
          <i class="bi bi-file-earmark-excel"></i> Exportar
        </a>
      </div>

      <div class="card-body">
        <div class="table-responsive table-modern">
          <table class="table align-middle mb-0">

            <thead>
              <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Usuario</th>
                <th>Email</th>
                <th>Rol</th>
                <th>Estado</th>
                <th>Seguridad</th>
                <th style="width:160px;">Acciones</th>
              </tr>
            </thead>

            <tbody>
              <?php if (!$users): ?>
                <tr>
                  <td colspan="8" class="text-center text-muted py-4">No hay usuarios</td>
                </tr>
              <?php else: foreach ($users as $u): ?>
                <tr>

                  <td class="text-muted"><?= e((string)$u['user_id']) ?></td>

                  <td class="fw-semibold"><?= e($u['firstname'].' '.$u['lastname']) ?></td>

                  <td><?= e($u['user_name']) ?></td>

                  <td><?= e($u['user_email']) ?></td>

                  <td>
                    <span class="badge-modern <?= $u['role']==='admin'?'ok':'bajo' ?>">
                      <?= e(strtoupper($u['role'])) ?>
                    </span>
                  </td>

                  <td>
                    <span class="badge-modern <?= (int)$u['is_active']===1?'ok':'agotado' ?>">
                      <?= (int)$u['is_active']===1?'ACTIVO':'INACTIVO' ?>
                    </span>
                  </td>

                  <td>
                    <?php $locked = !empty($u['locked_until']) && strtotime((string)$u['locked_until']) > time(); ?>
                    <span class="badge-modern <?= $locked?'bajo':'ok' ?>">
                      <?= $locked?'BLOQUEADO':'OK' ?>
                    </span>
                    <div class="small text-muted">Intentos: <?= e((string)($u['failed_attempts'] ?? 0)) ?></div>
                  </td>

                  <td>
                    <div class="table-actions">
                      <a class="btn btn-edit" href="usuarios.php?edit=<?= e((string)$u['user_id']) ?>">
                        <i class="bi bi-pencil"></i>
                      </a>

                      <?php if ($locked): ?>
                        <form method="POST">
                          <?= csrf_field() ?>
                          <input type="hidden" name="action" value="unlock">
                          <input type="hidden" name="user_id" value="<?= e((string)$u['user_id']) ?>">
                          <button class="btn btn-refresh" type="submit">
                            <i class="bi bi-unlock"></i>
                          </button>
                        </form>
                      <?php endif; ?>

                      <a class="btn btn-delete" href="usuarios_delete.php?id=<?= e((string)$u['user_id']) ?>">
                        <i class="bi bi-trash"></i>
                      </a>
                    </div>
                  </td>

                </tr>
              <?php endforeach; endif; ?>
            </tbody>

          </table>
        </div>
      </div>
    </div>
  </div>

</div>

<script>
const togglePasswordEdit = document.getElementById('togglePasswordEdit');
const passwordInputEdit = document.getElementById('passwordInputEdit');
const iconEdit = document.getElementById('iconPasswordEdit');

if (togglePasswordEdit) {
    togglePasswordEdit.addEventListener('click', () => {
        const isPassword = passwordInputEdit.type === 'password';

        passwordInputEdit.type = isPassword ? 'text' : 'password';

        iconEdit.classList.toggle('bi-eye');
        iconEdit.classList.toggle('bi-eye-slash');
    });
}
</script>
