<div class="row g-3">

<!-- FORM -->
<div class="col-12 col-lg-4">
<div class="card stat-card primary h-100">

<div class="card-header form-header">
<h5 class="card-title mb-0">
<i class="bi bi-tags me-2"></i>
<?= $edit ? 'Editar categoría' : 'Nueva categoría' ?>
</h5>
</div>

<div class="card-body">

<form method="POST">
<?= csrf_field() ?>

<input type="hidden" name="action" value="<?= $edit ? 'update' : 'create' ?>">
<input type="hidden" name="id_categoria" value="<?= e((string)($edit['id_categoria'] ?? 0)) ?>">

<div class="mb-3">
<label class="form-label">Nombre<span style="color:#dc2626">*</span></label>
<input 
  class="form-control form-modern"
  name="nombre_categoria"
  maxlength="20"
  oninput="this.value=this.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñÜü ]/g,'');"
  required
  value="<?= e($edit['nombre_categoria'] ?? '') ?>">
<div class="form-text">Máx. 20 caracteres</div>
</div>

<div class="mb-2">
<label class="form-label">Descripción</label>
<textarea class="form-control form-modern"
name="descripcion_categoria"
maxlength="255"
placeholder="Opcional"
value="<?= e($edit['descripcion_categoria'] ?? '') ?>"></textarea> 
</div>

<div class="form-actions">

<button class="btn btn-save" type="submit">
<i class="bi bi-check-lg"></i>
<?= $edit ? 'Guardar cambios' : 'Crear categoría' ?>
</button>

<?php if ($edit): ?>
<a class="btn btn-cancel" href="categorias">Cancelar</a>
<?php endif; ?>

</div>
</form>

</div>
</div>
</div>

<!-- TABLA -->
<div class="col-12 col-lg-8">
<div class="card stat-card primary table-card h-100">

<div class="card-header table-header">

<div>
<h5 class="card-title mb-1">Listado de categorías</h5>
<small class="text-muted">No se permite borrar categorías con productos</small>
</div>

<a class="btn btn-outline-success btn-sm" href="export.php?type=categorias">
<i class="bi bi-file-earmark-excel"></i> Exportar
</a>

</div>

<!-- BUSCADOR -->
<form class="table-search m-3" method="GET">

<div class="search-bar">

<div class="search-input-wrap">

<i class="bi bi-search search-icon"></i>

<input
class="form-control search-input"
name="buscar"
maxlength="40"
placeholder="Buscar por ID, nombre o descripción"
value="<?= e($buscar) ?>">

<?php if(!empty($buscar)): ?>
<a href="categorias" class="clear-search">
<i class="bi bi-x"></i>
</a>
<?php endif; ?>

</div>

<div class="search-actions">

<button class="btn btn-search" type="submit">
<i class="bi bi-search"></i>
Buscar
</button>

<a class="btn btn-refresh" href="categorias">
<i class="bi bi-arrow-clockwise"></i>
</a>

</div>

</div>
</form>

<div class="card-body">

<div class="table-responsive table-modern">

<table class="table align-middle mb-0">

<thead>
<tr>
<th>ID</th>
<th>Nombre</th>
<th>Descripción</th>
<th>Productos</th>
<th style="width:160px;">Acciones</th>
</tr>
</thead>

<tbody>

<?php if (!$categorias): ?>
<tr>
<td colspan="5" class="text-center text-muted py-4">
No hay categorías
</td>
</tr>

<?php else: foreach ($categorias as $c): ?>

<tr>

<td class="text-muted fw-medium"><?= e((string)$c['id_categoria']) ?></td>

<td class="fw-semibold"><?= e($c['nombre_categoria']) ?></td>

<td class="descripcion"><?= e($c['descripcion_categoria']) ?></td>

<td>
<span class="badge-soft"><?= e((string)$c['productos']) ?></span>
</td>

<td>

<div class="table-actions">

<a class="btn btn-edit"
href="categorias?edit=<?= e((string)$c['id_categoria']) ?>">
<i class="bi bi-pencil"></i>
</a>

<button
type="button"
class="btn btn-delete btn-delete-category"
data-id="<?= e((string)$c['id_categoria']) ?>"
data-name="<?= e($c['nombre_categoria']) ?>"
data-bs-toggle="modal"
data-bs-target="#deleteCategoryModal">
<i class="bi bi-trash"></i>
</button>

</div>

</td>

</tr>

<?php endforeach; endif; ?>

</tbody>

</table>

</div>
</div>
</div>
</div>

</div>

<!-- MODAL ELIMINAR -->
<div class="modal fade" id="deleteCategoryModal" tabindex="-1">
<div class="modal-dialog modal-dialog-centered modal-sm">

<div class="modal-content modal-delete">

<div class="modal-header border-0 pb-0">
<h5 class="modal-title">
<i class="bi bi-exclamation-triangle text-danger me-2"></i>
Eliminar categoría
</h5>

<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body text-center pt-2">

<div class="delete-icon">
<i class="bi bi-trash"></i>
</div>

<p class="mb-1">Vas a eliminar:</p>

<div class="delete-name" id="deleteCategoryName">—</div>

<p class="text-muted small mt-3 mb-0">
Solo se eliminará si no tiene productos asociados.
</p>

</div>

<div class="modal-footer border-0 pt-0 justify-content-center">

<button type="button" class="btn btn-cancel" data-bs-dismiss="modal">
Cancelar
</button>

<form method="POST">
<?= csrf_field() ?>
<input type="hidden" name="action" value="delete">
<input type="hidden" name="id_categoria" id="deleteCategoryId">

<button class="btn btndeleteconfirm" type="submit">
Sí, eliminar
</button>
</form>

</div>

</div>
</div>
</div>

<script>
document.querySelectorAll('.btn-delete-category').forEach(function (btn) {
btn.addEventListener('click', function () {
document.getElementById('deleteCategoryId').value = this.dataset.id;
document.getElementById('deleteCategoryName').textContent = this.dataset.name;
});
});
</script>
