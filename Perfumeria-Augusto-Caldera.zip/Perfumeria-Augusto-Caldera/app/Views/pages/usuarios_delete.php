<div class="row justify-content-center">

  <div class="col-lg-6">
    <div class="card stat-card primary">

     
      <div class="card-header form-header">
        <h5 class="card-title mb-0">
          <i class="bi bi-exclamation-triangle me-2"></i>
          Confirmar eliminación
        </h5>
      </div>

      
      <div class="card-body">

        <p class="mb-2">Vas a eliminar al usuario:</p>

        <div class="info-box mb-3">
          <div><b>ID:</b> <?= e((string)$target['user_id']) ?></div>
          <div><b>Usuario:</b> <?= e((string)$target['user_name']) ?></div>
          <div><b>Email:</b> <?= e((string)$target['user_email']) ?></div>
        </div>

        <div class="alert alert-modern warning mb-3">
          Para cumplir con el instrumento, debes autenticarte nuevamente
          (contraseña + pregunta de seguridad) para eliminar un usuario.
        </div>

        <?php if ($error): ?>
          <div class="alert alert-modern danger mb-3"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="POST">
          <?= csrf_field() ?>

          <div class="mb-3">
            <label class="form-label">Tu contraseña (admin)</label>
              <div class="input-group">
               
                
                <input 
                  id="passwordInput"
                  class="form-control" 
                  maxlength="16" 
                  type="password" 
                  name="admin_password" 
                  required
                >

                <button 
                  class="input-group-text bg-white border-start-0" 
                  type="button" 
                  id="togglePassword"
                  style="cursor:pointer;"
                >
                  <i class="bi bi-eye" id="iconPassword"></i>
                </button>
              </div>
          <!--<input maxlength="16" class="form-control form-modern" type="password" name="admin_password" required>-->
          </div>

          <div class="mb-3">
            <label class="form-label">Pregunta de seguridad</label>
            <div class="form-text mb-1">
              <?= e((string)($adminInfo['security_question'] ?? 'No configurada')) ?>
            </div>
            <input maxlength="20" class="form-control form-modern" name="admin_security_answer" required>
          </div>

          <div class="form-actions justify-content-center">
            <button class="btn btndeleteconfirm" style="width: auto;" type="submit">
              Eliminar 
            </button>

            <a class="btn btn-cancel" href="usuarios.php">
              Cancelar
            </a>
          </div>

        </form>

      </div>
    </div>
  </div>

</div>
<script>
const togglePassword = document.getElementById('togglePassword');
const passwordInput = document.getElementById('passwordInput');
const icon = document.getElementById('iconPassword');

togglePassword.addEventListener('click', () => {
    const isPassword = passwordInput.type === 'password';

    passwordInput.type = isPassword ? 'text' : 'password';

    icon.classList.toggle('bi-eye');
    icon.classList.toggle('bi-eye-slash');
});
</script>