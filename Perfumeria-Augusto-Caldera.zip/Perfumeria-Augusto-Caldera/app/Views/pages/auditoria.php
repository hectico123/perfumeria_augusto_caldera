<div class="container-fluid">

  <div class="card stat-card primary table-card">

    <!-- HEADER -->
    <div class="card-header table-header">

      <div>
        <h5 class="card-title mb-1">
          <i class="bi bi-bar-chart-line me-2"></i>
          Reportes y Auditoría
        </h5>
        <small class="text-muted">Movimientos del sistema e inventario</small>
      </div>

      <?php if ($tab === 'audit'): ?>
        <a class="btn btn-outline-success btn-sm"
           href="export.php?type=audit<?php
            echo $fromD ? '&from=' . urlencode($fromD) : '';
            echo $toD ? '&to=' . urlencode($toD) : '';
            echo $q ? '&q=' . urlencode($q) : '';
           ?>">
          <i class="bi bi-file-earmark-excel"></i> Exportar
        </a>
      <?php else: ?>
        <a class="btn btn-outline-success btn-sm"
           href="export.php?type=movimientos<?php
            echo $fromD ? '&from=' . urlencode($fromD) : '';
            echo $toD ? '&to=' . urlencode($toD) : '';
            echo $q ? '&q=' . urlencode($q) : '';
           ?>">
          <i class="bi bi-file-earmark-excel"></i> Exportar
        </a>
      <?php endif; ?>

    </div>

    <div class="card-body">

      <!-- TABS -->
      <ul class="nav nav-tabs nav-modern mb-3">
        <li class="nav-item">
          <a class="nav-link <?= $tab === 'audit' ? 'active' : '' ?>" href="auditoria.php?tab=audit">
            Movimientos del sistema
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $tab === 'mov' ? 'active' : '' ?>" href="auditoria.php?tab=mov">
            Inventario
          </a>
        </li>
      </ul>

      <!-- FILTROS -->
      <form class="row g-2 mb-3" method="GET" action="auditoria.php">

        <input type="hidden" name="tab" value="<?= e($tab) ?>">

        <div class="col-12 col-md-3">
          <label class="form-label">Desde</label>
          <input type="date" class="form-control form-modern" name="from" value="<?= e($fromD ?? '') ?>">
        </div>

        <div class="col-12 col-md-3">
          <label class="form-label">Hasta</label>
          <input type="date" class="form-control form-modern" name="to" value="<?= e($toD ?? '') ?>">
        </div>

        <div class="col-12 col-md-4">
          <label class="form-label">Buscar</label>
          <input
            type="text"
            class="form-control form-modern"
            name="q"
            maxlength="30"
            placeholder="Usuario, acción, producto..."
            value="<?= e($q) ?>"
          >
        </div>

        <div class="col-12 col-md-2 d-flex align-items-end gap-2">
          <button class="btn btn-save w-100" type="submit">
            <i class="bi bi-funnel"></i>
          </button>
          <a class="btn btn-cancel w-100" href="auditoria.php?tab=<?= e($tab) ?>">
            <i class="bi bi-arrow-clockwise"></i>
          </a>
        </div>

      </form>

      <!-- TABLA -->
      <div class="table-responsive table-modern">

        <table class="table align-middle mb-0">

          <thead>
            <?php if ($tab === 'audit'): ?>
              <tr>
                <th>Fecha</th>
                <th>Usuario</th>
                <th>Acción</th>
                <th>IP</th>
                <th>Detalle</th>
              </tr>
            <?php else: ?>
              <tr>
                <th>Fecha</th>
                <th>Usuario</th>
                <th>Tipo</th>
                <th>Código</th>
                <th>Producto</th>
                <th>Cant.</th>
                <th>Stock Antes</th>
                <th>Stock Después</th>
                <th>Referencia</th>
                <th>Observación</th>
              </tr>
            <?php endif; ?>
          </thead>

          <tbody>

          <?php if (!$rows): ?>

            <tr>
              <td colspan="<?= $tab === 'audit' ? 5 : 10 ?>" class="text-center text-muted py-4">
                Sin registros con los filtros actuales
              </td>
            </tr>

          <?php else: foreach ($rows as $r): ?>

            <?php if ($tab === 'audit'): ?>

              <tr>
                <td class="text-muted"><?= e((string)$r['created_at']) ?></td>
                <td><?= e((string)($r['user_name'] ?? '—')) ?></td>
                <td class="fw-semibold"><?= e(action_label((string)$r['action'])) ?></td>
                <td><?= e((string)($r['ip_address'] ?? '')) ?></td>
                <td style="max-width:420px;white-space:normal;"><?= e(detail_label($r['details'])) ?></td>
              </tr>

            <?php else: ?>

              <tr>
                <td class="text-muted"><?= e((string)$r['created_at']) ?></td>
                <td><?= e((string)($r['user_name'] ?? '—')) ?></td>
                <td class="fw-semibold"><?= e((string)$r['tipo']) ?></td>
                <td><?= e((string)$r['codigo_producto']) ?></td>
                <td><?= e((string)$r['nombre_producto']) ?></td>
                <td><?= e((string)$r['cantidad']) ?></td>
                <td><?= e((string)$r['stock_antes']) ?></td>
                <td><?= e((string)$r['stock_despues']) ?></td>
                <td><?= e((string)$r['referencia']) ?></td>
                <td class="descripcion"><?= e((string)$r['observacion']) ?></td>
              </tr>

            <?php endif; ?>

          <?php endforeach; endif; ?>

          </tbody>

        </table>

      </div>

    </div>

  </div>

</div>
