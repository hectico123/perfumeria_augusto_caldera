<div class="row g-3">

  <!-- FORM -->
  <div class="col-12 col-lg-6">
    <div class="card stat-card primary h-100">
      <div class="card-header form-header">
        <h5 class="card-title mb-0">Conversión USD → Bolívares</h5>
        <small class="text-muted">Se usa para calcular y mostrar precios en Bs</small>
      </div>

      <div class="card-body">
        <form method="POST">
          <?= csrf_field() ?>

          <label class="form-label">Tasa actual</label>

          <div class="input-group">
            <span class="input-group-text">1 USD =</span>

              <input
                class="form-control form-modern"
                name="usd_to_ves"
                type="number"
                step="0.0001"
                min="0.0001"
                value="<?= e(($old['usd_to_ves'] ?? '') !== '' ? $old['usd_to_ves'] : ($usd_to_ves > 0 ? (string)$usd_to_ves : '')) ?>"
                oninput="if(this.value.length>20)this.value=this.value.slice(0,20)"
                required
              >

            <span class="input-group-text">Bs</span>
          </div>

          <button class="btn btn-save mt-3" type="submit">
            Guardar
          </button>

        </form>
      </div>
    </div>
  </div>


  <!-- HISTORIAL -->
  <div class="col-12 col-lg-6">
    <div class="card stat-card primary table-card h-100">

      <div class="card-header table-header">
        <h5 class="card-title mb-0">Historial de tasas</h5>
        <small class="text-muted">Últimos 20 cambios registrados</small>
      </div>

      <div class="card-body">

        <div class="table-responsive table-modern">

          <table class="table align-middle mb-0">

            <thead>
              <tr>
                <th>Fecha</th>
                <th>Tasa</th>
                <th>Usuario</th>
              </tr>
            </thead>

            <tbody>

              <?php if (!$history): ?>

                <tr>
                  <td colspan="3" class="text-center text-muted py-4">
                    No hay historial de tasas
                  </td>
                </tr>

              <?php else: foreach ($history as $row): ?>

                <tr>

                  <td class="text-muted">
                    <?= e((string)$row['created_at']) ?>
                  </td>

                  <td class="fw-semibold">
                    <?= e(number_format((float)$row['rate'], 4, '.', '')) ?>
                  </td>

                  <td>
                    <?= e((string)($row['user_name'] ?? '—')) ?>
                  </td>

                </tr>

              <?php endforeach; endif; ?>

            </tbody>

          </table>

        </div>

      </div>

    </div>
  </div>

</div>
