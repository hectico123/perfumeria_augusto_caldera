<?php

declare(strict_types=1);

namespace App\Core;

final class View
{
    public static function render(string $view, array $data = [], bool $withLayout = true): void
    {
        extract($data, EXTR_SKIP);

        ob_start();
        if ($withLayout) {
            require BASE_PATH . '/includes/layout.php';
        }

        require $view;

        if ($withLayout) {
            require BASE_PATH . '/includes/layout_footer.php';
        }

        $html = ob_get_clean() ?: '';
        echo self::sanitizeInternalUrls($html);
    }

    public static function sanitizeInternalUrls(string $html): string
    {
        $replacements = [
            'href="index.php"' => 'href="' . e(url('')) . '"',
            'action="index.php"' => 'action="' . e(url('')) . '"',
            'href="dashboard.php' => 'href="' . e(url('dashboard')),
            'action="dashboard.php' => 'action="' . e(url('dashboard')),
            'href="productos.php' => 'href="' . e(url('productos')),
            'action="productos.php' => 'action="' . e(url('productos')),
            'href="categorias.php' => 'href="' . e(url('categorias')),
            'action="categorias.php' => 'action="' . e(url('categorias')),
            'href="movimientos.php' => 'href="' . e(url('movimientos')),
            'action="movimientos.php' => 'action="' . e(url('movimientos')),
            'href="usuarios.php' => 'href="' . e(url('usuarios')),
            'action="usuarios.php' => 'action="' . e(url('usuarios')),
            'href="usuarios_delete.php' => 'href="' . e(url('usuarios/eliminar')),
            'action="usuarios_delete.php' => 'action="' . e(url('usuarios/eliminar')),
            'href="configuracion.php' => 'href="' . e(url('configuracion')),
            'action="configuracion.php' => 'action="' . e(url('configuracion')),
            'href="auditoria.php' => 'href="' . e(url('auditoria')),
            'action="auditoria.php' => 'action="' . e(url('auditoria')),
            'href="export.php' => 'href="' . e(url('export')),
            'action="export.php' => 'action="' . e(url('export')),
            'href="forgot_password.php' => 'href="' . e(url('forgot-password')),
            'action="forgot_password.php' => 'action="' . e(url('forgot-password')),
            'href="reset_password.php' => 'href="' . e(url('reset-password')),
            'action="reset_password.php' => 'action="' . e(url('reset-password')),
            'href="logout.php"' => 'href="' . e(url('logout')) . '"',
            'action="logout.php"' => 'action="' . e(url('logout')) . '"',
            'window.location.href = "logout.php"' => 'window.location.href = "' . e(url('logout')) . '"',
            'location.href="logout.php"' => 'location.href="' . e(url('logout')) . '"',
            'window.location.href = "index.php"' => 'window.location.href = "' . e(url('')) . '"',
        ];

        return strtr($html, $replacements);
    }
}
