<?php

declare(strict_types=1);

namespace App\Core;

final class Router
{
    /** @var array<int, array{methods: array<int, string>, uri: string, action: callable}> */
    private array $routes = [];

    public function get(string $uri, callable $action): self
    {
        return $this->match(['GET'], $uri, $action);
    }

    public function post(string $uri, callable $action): self
    {
        return $this->match(['POST'], $uri, $action);
    }

    public function match(array $methods, string $uri, callable $action): self
    {
        $this->routes[] = [
            'methods' => array_values(array_unique(array_map('strtoupper', $methods))),
            'uri' => trim($uri, '/'),
            'action' => $action,
        ];

        return $this;
    }

    public function dispatch(string $uri, string $method): void
    {
        $uri = trim($uri, '/');
        $method = strtoupper($method);
        $allowed = [];

        foreach ($this->routes as $route) {
            if ($route['uri'] !== $uri) {
                continue;
            }

            if (in_array($method, $route['methods'], true)) {
                ($route['action'])();
                return;
            }

            $allowed = array_merge($allowed, $route['methods']);
        }

        if ($allowed !== []) {
            http_response_code(405);
            header('Allow: ' . implode(', ', array_unique($allowed)));
            echo '405 Método no permitido';
            return;
        }

        http_response_code(404);
        View::render(BASE_PATH . '/app/Views/errors/404.php', [
            'requestedPath' => $uri,
            'page' => 'Página no encontrada',
            'active' => '',
        ], false);
    }
}
