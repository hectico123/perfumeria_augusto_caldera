<?php

require_login();

require BASE_PATH . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;

$type = $_GET['type'] ?? 'products';

/**
 * EXCEL PROFESIONAL
 */
function output_excel(string $filename, array $headers, array $rows): void {

    $excel = new Spreadsheet();
    $sheet = $excel->getActiveSheet();

    // =========================
    // TITULO
    // =========================
    $sheet->setCellValue('A1', strtoupper(str_replace('.xlsx','',$filename)));
    $sheet->mergeCells('A1:' . chr(64 + count($headers)) . '1');

    $sheet->getStyle('A1')->getFont()->setBold(true)->setSize(14);
    $sheet->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

    // =========================
    // ENCABEZADOS
    // =========================
    $col = 'A';
    foreach ($headers as $h) {
        $sheet->setCellValue($col . '3', $h);
        $col++;
    }

    $headerRange = 'A3:' . chr(64 + count($headers)) . '3';

    $sheet->getStyle($headerRange)->getFont()->setBold(true);
    $sheet->getStyle($headerRange)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    $sheet->getStyle($headerRange)->getFill()->setFillType(Fill::FILL_SOLID)
        ->getStartColor()->setARGB('FFEFEFEF');

    // =========================
    // DATOS
    // =========================
    $fila = 4;

    foreach ($rows as $row) {

        $col = 'A';

        foreach ($row as $cell) {
            $sheet->setCellValue($col . $fila, $cell);
            $col++;
        }

        $fila++;
    }

    // =========================
    // AUTO AJUSTE COLUMNAS
    // =========================
    foreach (range('A', chr(64 + count($headers))) as $col) {
        $sheet->getColumnDimension($col)->setAutoSize(true);
    }

    // =========================
    // BORDES
    // =========================
    $sheet->getStyle('A3:' . chr(64 + count($headers)) . ($fila - 1))
        ->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);

    // =========================
    // FILTROS
    // =========================
    $sheet->setAutoFilter('A3:' . chr(64 + count($headers)) . '3');

    // =========================
    // DESCARGA
    // =========================
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header("Content-Disposition: attachment; filename=\"$filename\"");
    header('Cache-Control: max-age=0');

    $writer = new Xlsx($excel);
    $writer->save('php://output');
    exit;
}

$rateRow = db_one("SELECT setting_value FROM settings WHERE setting_key='usd_to_ves' LIMIT 1");
$usd_to_ves = $rateRow ? (float)$rateRow['setting_value'] : 0.0;

/**
 * =========================
 * PRODUCTOS
 * =========================
 */
if ($type === 'products') {

    $data = db_all('SELECT p.codigo_producto, p.nombre_producto, c.nombre_categoria, p.stock, p.stock_min, p.precio_usd, p.date_added FROM products p LEFT JOIN categorias c ON c.id_categoria=p.id_categoria ORDER BY p.id_producto DESC');

    $rows = [];

    foreach ($data as $d) {

        $precioUsd = (float)$d['precio_usd'];
        $precioBs = $usd_to_ves > 0 ? $precioUsd * $usd_to_ves : '';

        $estado = ((int)$d['stock']<=0)
            ? 'AGOTADO'
            : (((int)$d['stock'] <= (int)$d['stock_min']) ? 'BAJO' : 'OK');

        $rows[] = [
            $d['codigo_producto'],
            $d['nombre_producto'],
            $d['nombre_categoria'] ?? '',
            (int)$d['stock'],
            (int)$d['stock_min'],
            number_format($precioUsd, 2),
            $precioBs===''? '' : number_format((float)$precioBs, 2),
            $estado,
            $d['date_added'],
        ];
    }

    audit_log('EXPORT', 'products', null, ['type' => 'products']);

    output_excel(
        'reporte_productos.xlsx',
        ['Código','Producto','Categoría','Stock','Stock mín.','Precio USD','Precio Bs','Estado','Fecha'],
        $rows
    );
}

/**
 * =========================
 * CATEGORIAS
 * =========================
 */
if ($type === 'categorias') {

    $data = db_all('SELECT c.id_categoria, c.nombre_categoria, c.descripcion_categoria, c.date_added, (SELECT COUNT(*) FROM products p WHERE p.id_categoria=c.id_categoria) AS productos FROM categorias c ORDER BY c.id_categoria DESC');

    $rows = [];

    foreach ($data as $d) {
        $rows[] = [$d['id_categoria'], $d['nombre_categoria'], $d['descripcion_categoria'], $d['productos'], $d['date_added']];
    }

    audit_log('EXPORT', 'categorias', null, ['type' => 'categorias']);

    output_excel(
        'reporte_categorias.xlsx',
        ['ID','Nombre','Descripción','Productos','Fecha'],
        $rows
    );
}

/**
 * =========================
 * USERS
 * =========================
 */
if ($type === 'users') {

    require_admin();

    $data = db_all('SELECT user_id, firstname, lastname, user_name, user_email, role, is_active, date_added FROM users ORDER BY user_id DESC');

    $rows = [];

    foreach ($data as $d) {
        $rows[] = [$d['user_id'], $d['firstname'], $d['lastname'], $d['user_name'], $d['user_email'], $d['role'], (int)$d['is_active']===1?'ACTIVO':'INACTIVO', $d['date_added']];
    }

    audit_log('EXPORT', 'users', null, ['type' => 'users']);

    output_excel(
        'reporte_usuarios.xlsx',
        ['ID','Nombres','Apellidos','Usuario','Email','Rol','Estado','Fecha'],
        $rows
    );
}

/**
 * =========================
 * MOVIMIENTOS
 * =========================
 */
if ($type === 'movimientos') {

    require_admin();

    $data = db_all("SELECT m.created_at, u.user_name, m.tipo, p.codigo_producto, p.nombre_producto, m.cantidad, m.stock_antes, m.stock_despues, m.referencia, m.observacion
                    FROM movimientos m
                    LEFT JOIN products p ON p.id_producto = m.id_producto
                    LEFT JOIN users u ON u.user_id = m.user_id
                    ORDER BY m.created_at DESC");

    $rows = [];

    foreach ($data as $d) {
        $rows[] = [$d['created_at'], $d['user_name'], $d['tipo'], $d['codigo_producto'], $d['nombre_producto'], $d['cantidad'], $d['stock_antes'], $d['stock_despues'], $d['referencia'], $d['observacion']];
    }

    audit_log('EXPORT', 'movimientos', null, ['type' => 'movimientos']);

    output_excel(
        'reporte_movimientos.xlsx',
        ['Fecha','Usuario','Tipo','Código','Producto','Cantidad','Stock Antes','Stock Después','Referencia','Observación'],
        $rows
    );
}
/**
 * =========================
 * AUDITORIA (LOGS DEL SISTEMA)
 * =========================
 */
if ($type === 'audit') {

    require_admin();

    $from = trim((string)($_GET['from'] ?? ''));
    $to   = trim((string)($_GET['to'] ?? ''));
    $q    = trim((string)($_GET['q'] ?? ''));

    $where = [];
    $params = [];

    if ($from) {
        $where[] = "a.created_at >= :from_dt";
        $params[':from_dt'] = $from . " 00:00:00";
    }

    if ($to) {
        $where[] = "a.created_at <= :to_dt";
        $params[':to_dt'] = $to . " 23:59:59";
    }

    if ($q !== '') {
        $like = '%' . $q . '%';
        $where[] = "(a.action LIKE :q1 OR a.details_json LIKE :q2 OR u.user_name LIKE :q3 OR a.ip LIKE :q4)";
        $params[':q1'] = $like;
        $params[':q2'] = $like;
        $params[':q3'] = $like;
        $params[':q4'] = $like;
    }

    $sql = "SELECT 
                a.created_at, 
                u.user_name, 
                a.action, 
                a.ip AS ip_address, 
                a.details_json
            FROM audit_logs a
            LEFT JOIN users u ON u.user_id = a.user_id";

    if ($where) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }

    $sql .= " ORDER BY a.created_at DESC";

    $data = db_all($sql, $params);

    $rows = [];

    foreach ($data as $d) {
        $rows[] = [
            $d['created_at'],
            $d['user_name'],
            $d['action'],
            $d['ip_address'],
            $d['details_json']
        ];
    }

    audit_log('EXPORT', 'audit', null, ['type' => 'audit']);

    output_excel(
        'reporte_auditoria.xlsx',
        ['Fecha','Usuario','Acción','IP','Detalles'],
        $rows
    );
}
http_response_code(400);
echo 'Tipo de exportación no válido.';
