<?php

if (is_logged_in()) {
    redirect('dashboard.php');
}

$step = (int)($_POST['step'] ?? 1);
$identifier = trim($_POST['identifier'] ?? '');
$answer = trim($_POST['answer'] ?? '');
$new1 = (string)($_POST['new_password'] ?? '');
$new2 = (string)($_POST['new_password2'] ?? '');

$question = '';
$user_id = 0;

$ok = '';
$error = '';

if (is_post()) {
    csrf_verify();

    if ($step === 1) {
        if ($identifier === '') {
            $error = 'Ingresa tu usuario o correo.';
        } else {
            $u = db_one("SELECT user_id, user_name, user_email, security_question, security_answer_hash
                        FROM users
                        WHERE is_active=1 AND (user_name=:u1 OR user_email=:u2)
                        LIMIT 1", [':u1'=>$identifier, ':u2'=>$identifier]);

            if (!$u || empty($u['security_question']) || empty($u['security_answer_hash'])) {

                $ok = 'Si la cuenta existe y tiene recuperación configurada, podrás restablecer la contraseña.';
            } else {
                $step = 2;
                $user_id = (int)$u['user_id'];
                $_SESSION['pw_reset_user'] = $user_id;
                $securityquestions = [
    'q_color' => '¿cuál es tu color favorito?',
    'q_pet'   => '¿cuál es el nombre de tu primera mascota?',
    'q_city'  => '¿cuál es tu ciudad de nacimiento?',
    'q_food'  => '¿cuál es tu comida favorita?',
    'q_word'  => '¿cuál es tu palabra clave?'
];

$questioncode = (string)$u['security_question'];
$question = $securityquestions[$questioncode] ?? 'pregunta no disponible';
            }
        }
    } elseif ($step === 2) {
        $user_id = (int)($_SESSION['pw_reset_user'] ?? 0);
        if ($user_id <= 0) {
            $error = 'Sesión de recuperación expirada. Intenta nuevamente.';
            $step = 1;
        } else {
            $u = db_one("SELECT user_id, security_question, security_answer_hash FROM users WHERE user_id=:id AND is_active=1 LIMIT 1",
                        [':id'=>$user_id]);
            if (!$u) {
                $error = 'No se pudo validar la cuenta.';
                $step = 1;
            } else {
                $securityquestions = [
    'q_color' => '¿cuál es tu color favorito?',
    'q_pet'   => '¿cuál es el nombre de tu primera mascota?',
    'q_city'  => '¿cuál es tu ciudad de nacimiento?',
    'q_food'  => '¿cuál es tu comida favorita?',
    'q_word'  => '¿cuál es tu palabra clave?'
];

$questioncode = (string)$u['security_question'];
$question = $securityquestions[$questioncode] ?? 'pregunta no disponible';

                if ($answer === '') {
                    $error = 'Responde la pregunta de seguridad.';
                } elseif (!password_verify($answer, (string)$u['security_answer_hash'])) {
                    $error = 'Respuesta incorrecta.';
                } elseif (strlen($new1) < 16) {
                    $error = 'La contraseña debe tener mínimo 16 caracteres.';
                } elseif ($new1 !== $new2) {
                    $error = 'Las contraseñas no coinciden.';
                } else {
                    $hash = password_hash($new1, PASSWORD_DEFAULT);
                    db_exec("UPDATE users SET user_password_hash=:h WHERE user_id=:id", [':h'=>$hash, ':id'=>$user_id]);
                    audit_log('AUTH', 'password_reset_security_question', $user_id, []);
                    unset($_SESSION['pw_reset_user']);
                    $ok = 'Contraseña actualizada. Ya puedes iniciar sesión.';
                    $step = 1;
                }
            }
        }
    }
}

$flash = flash_get();
