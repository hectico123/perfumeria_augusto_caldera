<?php

$page = 'Entradas / Salidas';
$active = 'movimientos';

/* =========================
   HELPERS FORM
========================= */
function movimiento_old_set(array $data): void {
    $_SESSION['_movimiento_old_input'] = $data;
}
function movimiento_old_get(): array {
    return $_SESSION['_movimiento_old_input'] ?? [];
}
function movimiento_old_clear(): void {
    unset($_SESSION['_movimiento_old_input']);
}

/* =========================
   DATOS BASE
========================= */
$productos = db_all(
'SELECT id_producto, codigo_producto, nombre_producto, stock
 FROM products
 ORDER BY nombre_producto ASC'
);

/* =========================
   POST
========================= */
if (is_post()) {

csrf_verify();

$tipo = trim($_POST['tipo'] ?? '');
$id_producto = (int)($_POST['id_producto'] ?? 0);
$cantidad = (int)($_POST['cantidad'] ?? 0);
$referencia = trim($_POST['referencia'] ?? '');
$observacion = trim($_POST['observacion'] ?? '');

movimiento_old_set(compact('tipo','id_producto','cantidad','referencia','observacion'));

$validos=['ENTRADA','SALIDA','AJUSTE_POSITIVO','AJUSTE_NEGATIVO'];

if(!in_array($tipo,$validos,true)){
flash_set('danger','Selecciona un tipo válido.');
redirect('movimientos.php');
}

if($id_producto<=0){
flash_set('danger','Selecciona un producto.');
redirect('movimientos.php');
}

if($cantidad<=0){
flash_set('danger','La cantidad debe ser mayor a 0.');
redirect('movimientos.php');
}

$p=db_one('SELECT stock,codigo_producto,nombre_producto FROM products WHERE id_producto=:id',[':id'=>$id_producto]);

if(!$p){
flash_set('danger','Producto no existe.');
redirect('movimientos.php');
}

$antes=(int)$p['stock'];
$despues=$antes;

if($tipo==='ENTRADA'||$tipo==='AJUSTE_POSITIVO') $despues+=$cantidad;

if($tipo==='SALIDA'||$tipo==='AJUSTE_NEGATIVO'){
if($cantidad>$antes){
flash_set('danger','Cantidad mayor al stock.');
redirect('movimientos.php');
}
$despues-=$cantidad;
}

db_exec('UPDATE products SET stock=:s WHERE id_producto=:id',[':s'=>$despues,':id'=>$id_producto]);

db_exec(
'INSERT INTO movimientos (tipo,id_producto,cantidad,stock_antes,stock_despues,referencia,observacion,user_id,created_at)
VALUES (:t,:id,:c,:a,:d,:r,:o,:u,NOW())',
[
':t'=>$tipo,
':id'=>$id_producto,
':c'=>$cantidad,
':a'=>$antes,
':d'=>$despues,
':r'=>$referencia?:null,
':o'=>$observacion?:null,
':u'=>(int)(current_user()['id']??0)
]);

movimiento_old_clear();
flash_set('success','Movimiento registrado.');
redirect('movimientos.php');
}

/* =========================
   BUSQUEDA
========================= */
$old=movimiento_old_get();
movimiento_old_clear();

$buscar=trim($_GET['buscar']??'');
$params=[];
$where='';

if($buscar!==''){
$where="WHERE p.codigo_producto LIKE :q1 OR p.nombre_producto LIKE :q2 OR m.tipo LIKE :q3 OR COALESCE(m.referencia,'') LIKE :q4";
$like="%$buscar%";
$params=[':q1'=>$like,':q2'=>$like,':q3'=>$like,':q4'=>$like];
}

$movimientos=db_all(
"SELECT m.*,p.codigo_producto,p.nombre_producto,u.user_name
FROM movimientos m
LEFT JOIN products p ON p.id_producto=m.id_producto
LEFT JOIN users u ON u.user_id=m.user_id
$where
ORDER BY m.created_at DESC",
$params
);
