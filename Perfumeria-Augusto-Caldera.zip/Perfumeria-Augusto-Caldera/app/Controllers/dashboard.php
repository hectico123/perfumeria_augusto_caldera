<?php

$page = 'Dashboard';
$active = 'dashboard';

$rateRow = db_one("SELECT setting_value FROM settings WHERE setting_key='usd_to_ves' LIMIT 1");
$usd_to_ves = $rateRow ? (float)$rateRow['setting_value'] : 0.0;

$total_productos = (int)(db_one('SELECT COUNT(*) AS c FROM products')['c'] ?? 0);
$total_categorias = (int)(db_one('SELECT COUNT(*) AS c FROM categorias')['c'] ?? 0);

$stock_bajo = (int)(db_one('SELECT COUNT(*) AS c FROM products WHERE stock <= stock_min AND stock > 0')['c'] ?? 0);
$agotados = (int)(db_one('SELECT COUNT(*) AS c FROM products WHERE stock <= 0')['c'] ?? 0);

$buscar = trim($_GET['buscar'] ?? '');
$params = [];
$where = '';
if ($buscar !== '') {
    
    $where = 'WHERE p.nombre_producto LIKE :q1 OR c.nombre_categoria LIKE :q2 OR p.codigo_producto LIKE :q3';
    $like = '%' . $buscar . '%';
    $params = ['q1' => $like, 'q2' => $like, 'q3' => $like];
}

$productos = db_all(
    "SELECT p.id_producto, p.codigo_producto, p.nombre_producto, p.precio_usd, p.stock, p.stock_min, c.nombre_categoria
     FROM products p
     LEFT JOIN categorias c ON c.id_categoria = p.id_categoria
     $where
     ORDER BY p.date_added DESC
     LIMIT 8",
    $params
);
