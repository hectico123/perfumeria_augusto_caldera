<?php

logout();
flash_set('success', 'Sesión cerrada correctamente.');
redirect('index.php');
