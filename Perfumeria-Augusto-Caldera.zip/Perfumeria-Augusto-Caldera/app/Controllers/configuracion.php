<?php

$page = 'Configuración';
$active = 'config';



$old = old_form_data();
old_input_clear();

if (is_post()) {
    csrf_verify();

    $rate = trim((string)($_POST['usd_to_ves'] ?? ''));
    old_input_set(['usd_to_ves' => $rate]);

    $rateNormalized = str_replace(',', '.', $rate);

    if ($rateNormalized === '' || !is_numeric($rateNormalized) || (float)$rateNormalized <= 0) {
        flash_set('danger', 'Ingresa una tasa válida mayor a 0.');
        redirect('configuracion.php');
    }

    $val = number_format((float)$rateNormalized, 4, '.', '');

    db_exec(
        "INSERT INTO settings (setting_key, setting_value)
         VALUES ('usd_to_ves', :v1)
         ON DUPLICATE KEY UPDATE setting_value = :v2",
        [':v1' => $val, ':v2' => $val]
    );

    db_exec(
        "INSERT INTO exchange_rate_history (rate, user_id, created_at)
         VALUES (:rate, :user_id, NOW())",
        [
            ':rate' => $val,
            ':user_id' => (int)(current_user()['id'] ?? 0)
        ]
    );

    old_input_clear();
    flash_set('success', 'Tasa actualizada correctamente.');
    redirect('configuracion.php');
}

$rateRow = db_one("SELECT setting_value FROM settings WHERE setting_key='usd_to_ves' LIMIT 1");
$usd_to_ves = $rateRow ? (float)$rateRow['setting_value'] : 0.0;

$history = db_all(
    "SELECT h.rate, h.created_at, u.user_name
     FROM exchange_rate_history h
     LEFT JOIN users u ON u.user_id = h.user_id
     ORDER BY h.created_at DESC
     LIMIT 20"
);
