<?php

$page = 'Eliminar Usuario';
$active = 'usuarios';

require_admin();

$id = (int)($_GET['id'] ?? 0);
$currentId = (int)(current_user()['id'] ?? 0);

if ($id <= 0) {
    redirect('usuarios.php');
}
if ($id === $currentId) {
    flash_set('warning', 'No puedes eliminar tu propio usuario.');
    redirect('usuarios.php');
}

$target = db_one('SELECT user_id, user_name, user_email FROM users WHERE user_id = :id LIMIT 1', [':id' => $id]);
if (!$target) {
    flash_set('warning', 'Usuario no encontrado.');
    redirect('usuarios.php');
}


$adminInfo = db_one('SELECT security_question, security_answer_hash FROM users WHERE user_id = :id LIMIT 1', [':id' => $currentId]) ?: [];

$error = '';
if (is_post()) {
    csrf_verify();

    $password = (string)($_POST['admin_password'] ?? '');
    $secAnswer = trim((string)($_POST['admin_security_answer'] ?? ''));

    $admin = db_one('SELECT user_id, user_password_hash, security_question, security_answer_hash
                     FROM users WHERE user_id = :id LIMIT 1', [':id' => $currentId]);

    if (!$admin || !password_verify($password, (string)$admin['user_password_hash'])) {
        $error = 'Autenticación inválida.';
        audit_log('USER_DELETE_DENIED', 'users', $id, ['reason' => 'bad_password']);
    } else {
       
        $hash = (string)($admin['security_answer_hash'] ?? '');
        if ($hash === '') {
            $error = 'Debes configurar tu pregunta de seguridad antes de eliminar usuarios.';
            audit_log('USER_DELETE_DENIED', 'users', $id, ['reason' => 'security_question_not_set']);
        } elseif (!password_verify($secAnswer, $hash)) {
            $error = 'Respuesta de seguridad inválida.';
            audit_log('USER_DELETE_DENIED', 'users', $id, ['reason' => 'bad_security_answer']);
        }
    }

    if ($error === '') {
        db_exec('DELETE FROM users WHERE user_id = :id', [':id' => $id]);
        audit_log('USER_DELETE', 'users', $id, ['by' => $currentId]);
        flash_set('success', 'Usuario eliminado.');
        redirect('usuarios.php');
    }
}
