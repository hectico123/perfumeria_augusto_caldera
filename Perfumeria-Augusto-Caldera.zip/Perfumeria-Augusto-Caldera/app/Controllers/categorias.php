<?php

$page = 'Categorías';
$active = 'categorias';

/* =========================
   BUSCADOR 
========================= */
$buscar = trim($_GET['buscar'] ?? '');
$params = [];
$where = '';

if ($buscar !== '') {

    $where = 'WHERE c.nombre_categoria LIKE :q1 
              OR c.descripcion_categoria LIKE :q2 
              OR c.id_categoria LIKE :q3';

    $like = "%$buscar%";

    $params = [
        'q1' => $like,
        'q2' => $like,
        'q3' => $like
    ];
}

/* =========================
   CRUD
========================= */
if (is_post()) {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $id = (int)($_POST['id_categoria'] ?? 0);
        $redirectUrl = $action === 'update' ? 'categorias?edit=' . $id : 'categorias';
        $nombre = trim($_POST['nombre_categoria'] ?? '');
        if (mb_strlen($nombre) > 20) {
            flash_set('danger', 'El nombre de la categoría no puede superar 20 caracteres.');
            redirect($redirectUrl);
        }
        $desc = trim($_POST['descripcion_categoria'] ?? '');

        if ($nombre === '') {
            flash_set('danger', 'El nombre es obligatorio.');
            redirect($redirectUrl);
        }

        if ($action === 'create') {

            db_exec(
                'INSERT INTO categorias (nombre_categoria, descripcion_categoria, date_added) 
                 VALUES (:n,:d,NOW())',
                [':n'=>$nombre, ':d'=>$desc]
            );

            $newId = db_last_id();

            audit_log('CATEGORY_CREATE', 'category', $newId, [
                'nombre_categoria' => $nombre,
                'descripcion_categoria' => $desc,
            ]);

            flash_set('success', 'Categoría creada.');

        } else {

            db_exec(
                'UPDATE categorias 
                 SET nombre_categoria=:n, descripcion_categoria=:d 
                 WHERE id_categoria=:id',
                [':n'=>$nombre, ':d'=>$desc, ':id'=>$id]
            );

            audit_log('CATEGORY_UPDATE', 'category', $id, [
                'nombre_categoria' => $nombre,
                'descripcion_categoria' => $desc,
            ]);

            flash_set('success', 'Categoría actualizada.');
        }

        redirect('categorias');
    }

    if ($action === 'delete') {

        $id = (int)($_POST['id_categoria'] ?? 0);

        $count = (int)(db_one(
            'SELECT COUNT(*) AS c FROM products WHERE id_categoria=:id',
            [':id'=>$id]
        )['c'] ?? 0);

        if ($count > 0) {
            flash_set('warning', 'No puedes eliminar una categoría con productos asociados.');
            redirect('categorias');
        }

        $c = db_one(
            'SELECT nombre_categoria, descripcion_categoria 
             FROM categorias 
             WHERE id_categoria=:id',
            [':id'=>$id]
        );

        db_exec('DELETE FROM categorias WHERE id_categoria=:id', [':id'=>$id]);

        audit_log('CATEGORY_DELETE', 'category', $id, [
            'nombre_categoria' => $c['nombre_categoria'] ?? null,
            'descripcion_categoria' => $c['descripcion_categoria'] ?? null,
        ]);

        flash_set('success', 'Categoría eliminada.');
        redirect('categorias');
    }
}

/* =========================
   CONSULTA
========================= */
$sql = "SELECT c.*, 
        (SELECT COUNT(*) FROM products p WHERE p.id_categoria=c.id_categoria) AS productos 
        FROM categorias c 
        $where
        ORDER BY c.id_categoria DESC";

$categorias = db_all($sql, $params);

$edit_id = (int)($_GET['edit'] ?? 0);
$edit = null;

if ($edit_id > 0) {
    $edit = db_one('SELECT * FROM categorias WHERE id_categoria=:id', [':id'=>$edit_id]);
}
