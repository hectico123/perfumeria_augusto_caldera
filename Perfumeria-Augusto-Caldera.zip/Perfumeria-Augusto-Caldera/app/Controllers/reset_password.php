<?php

redirect('forgot-password');
