<?php

$page = 'Usuarios';
$active = 'usuarios';

require_admin();

$securityQuestions = [
    'q_color' => '¿Cuál es tu color favorito?',
    'q_pet'   => '¿Cuál es el nombre de tu primera mascota?',
    'q_city'  => '¿Cuál es tu ciudad de nacimiento?',
    'q_food'  => '¿Cuál es tu comida favorita?',
    'q_word'  => '¿Cuál es tu palabra clave?'
];

$old = old_form_data();
old_input_clear();

if (is_post()) {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {

        $id = (int)($_POST['user_id'] ?? 0);
        $firstname = trim((string)($_POST['firstname'] ?? ''));
        $lastname = trim((string)($_POST['lastname'] ?? ''));
        $username = trim((string)($_POST['user_name'] ?? ''));
        $email = trim((string)($_POST['user_email'] ?? ''));
        $role = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $password = (string)($_POST['password'] ?? '');
        $sec_q = trim((string)($_POST['security_question'] ?? ''));
        $sec_a = trim((string)($_POST['security_answer'] ?? ''));

        $redirectUrl = $action === 'update' ? 'usuarios.php?edit=' . $id : 'usuarios.php';

        // ✅ VALIDACIÓN CORRECTA
        if ($sec_q !== '' && !array_key_exists($sec_q, $securityQuestions)) {
            flash_set('danger', 'Selecciona una pregunta de seguridad válida.');
            redirect($redirectUrl);
        }

        old_input_set([
            'user_id' => $id,
            'firstname' => $firstname,
            'lastname' => $lastname,
            'user_name' => $username,
            'user_email' => $email,
            'role' => $role,
            'is_active' => $is_active,
            'security_question' => $sec_q
        ]);

        if ($firstname === '' || $lastname === '' || $username === '' || $email === '') {
            flash_set('danger', 'Completa todos los campos obligatorios.');
            redirect($redirectUrl);
        }

        if (!valid_person_name($firstname) || !valid_person_name($lastname)) {
            flash_set('danger', 'Nombres y apellidos solo pueden tener letras y máximo 30 caracteres.');
            redirect($redirectUrl);
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash_set('danger', 'Email inválido.');
            redirect($redirectUrl);
        }

        if ($password !== '' && strlen($password) < PASSWORD_MIN_LEN) {
            flash_set('danger', 'La contraseña debe tener mínimo ' . PASSWORD_MIN_LEN . ' caracteres.');
            redirect($redirectUrl);
        }

        $dupU = db_one(
            'SELECT user_id FROM users WHERE user_name=:u AND user_id<>:id LIMIT 1',
            [':u' => $username, ':id' => $id]
        );

        if ($dupU) {
            flash_set('danger', 'El nombre de usuario ya existe.');
            redirect($redirectUrl);
        }

        $dupE = db_one(
            'SELECT user_id FROM users WHERE user_email=:e AND user_id<>:id LIMIT 1',
            [':e' => $email, ':id' => $id]
        );

        if ($dupE) {
            flash_set('danger', 'El email ya está registrado.');
            redirect($redirectUrl);
        }

        $secHash = null;

        // ================= CREATE =================
        if ($action === 'create') {

            if ($role === 'admin' && ($sec_q === '' || $sec_a === '')) {
                flash_set('danger', 'Para usuarios admin debes configurar pregunta y respuesta de seguridad.');
                redirect($redirectUrl);
            }

            if ($sec_q !== '' && $sec_a !== '') {
                $secHash = password_hash($sec_a, PASSWORD_DEFAULT);
            }

            if ($password === '') {
                flash_set('danger', 'La contraseña es obligatoria para crear usuario.');
                redirect($redirectUrl);
            }

            $hash = password_hash($password, PASSWORD_DEFAULT);

            db_exec(
                'INSERT INTO users 
                (firstname, lastname, user_name, user_email, user_password_hash, role, is_active, security_question, security_answer_hash, date_added)
                VALUES
                (:f,:l,:u,:e,:p,:r,:a,:sq,:sh,NOW())',
                [
                    ':f' => $firstname,
                    ':l' => $lastname,
                    ':u' => $username,
                    ':e' => $email,
                    ':p' => $hash,
                    ':r' => $role,
                    ':a' => $is_active,
                    ':sq' => $sec_q !== '' ? $sec_q : null,
                    ':sh' => $secHash
                ]
            );

            old_input_clear();
            audit_log('USER_CREATE', 'users', null, ['user_name' => $username, 'role' => $role]);
            flash_set('success', 'Usuario creado.');
            redirect('usuarios.php');
        }

        // ================= UPDATE =================
        $currentId = (int)(current_user()['id'] ?? 0);

        if ($id === $currentId && $is_active === 0) {
            flash_set('warning', 'No puedes desactivar tu propio usuario.');
            redirect($redirectUrl);
        }

        if (($sec_q !== '' && $sec_a === '') || ($sec_q === '' && $sec_a !== '')) {
            flash_set('danger', 'Para actualizar la pregunta debes indicar pregunta y respuesta.');
            redirect($redirectUrl);
        }

        if ($sec_q !== '' && $sec_a !== '') {
            $secHash = password_hash($sec_a, PASSWORD_DEFAULT);
        }

        $sql = 'UPDATE users SET firstname=:f, lastname=:l, user_name=:u, user_email=:e, role=:r, is_active=:a';
        $params = [
            ':f' => $firstname,
            ':l' => $lastname,
            ':u' => $username,
            ':e' => $email,
            ':r' => $role,
            ':a' => $is_active,
            ':id' => $id
        ];

        if ($password !== '') {
            $sql .= ', user_password_hash=:p';
            $params[':p'] = password_hash($password, PASSWORD_DEFAULT);
        }

        if ($secHash !== null) {
            $sql .= ', security_question=:sq, security_answer_hash=:sh';
            $params[':sq'] = $sec_q;
            $params[':sh'] = $secHash;
        }

        $sql .= ' WHERE user_id=:id';
        db_exec($sql, $params);

        old_input_clear();
        audit_log('USER_UPDATE', 'users', $id);
        flash_set('success', 'Usuario actualizado.');
        redirect('usuarios.php');
    }

    // ================= UNLOCK =================
    if ($action === 'unlock') {
        $id = (int)($_POST['user_id'] ?? 0);
        db_exec(
            'UPDATE users SET failed_attempts=0, locked_until=NULL WHERE user_id=:id',
            [':id' => $id]
        );
        audit_log('USER_UNLOCK', 'users', $id);
        flash_set('success', 'Usuario desbloqueado.');
        redirect('usuarios.php');
    }
}

$users = db_all(
    'SELECT user_id, firstname, lastname, user_name, user_email, role, is_active, date_added, failed_attempts, locked_until 
     FROM users ORDER BY user_id DESC'
);

$edit_id = (int)($_GET['edit'] ?? 0);
$edit = null;

if ($edit_id > 0) {
    $edit = db_one(
        'SELECT user_id, firstname, lastname, user_name, user_email, role, is_active, security_question 
         FROM users WHERE user_id=:id',
        [':id' => $edit_id]
    );
}

function user_form_value(array $old, ?array $edit, string $key, string $default = ''): string {
    return (string)($old[$key] ?? $edit[$key] ?? $default);
}

$currentQuestion = user_form_value($old, $edit, 'security_question');

if ($currentQuestion !== '' && !array_key_exists($currentQuestion, $securityQuestions)) {
    $securityQuestions[$currentQuestion] = $currentQuestion;
}

$currentIsActive = array_key_exists('is_active', $old)
    ? (int)$old['is_active'] === 1
    : (int)($edit['is_active'] ?? 1) === 1;
