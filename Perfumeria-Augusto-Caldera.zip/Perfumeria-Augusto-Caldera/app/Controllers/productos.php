<?php

$page = 'Productos';
$active = 'productos';

/* =========================
   TASA
========================= */
$rateRow = db_one("SELECT setting_value FROM settings WHERE setting_key='usd_to_ves' LIMIT 1");
$usd_to_ves = $rateRow ? (float)$rateRow['setting_value'] : 0.0;

/* =========================
   HELPERS FORM
========================= */
function product_old_set(array $data): void {
    $_SESSION['_product_old_input'] = $data;
}

function product_old_get(): array {
    return $_SESSION['_product_old_input'] ?? [];
}

function product_old_clear(): void {
    unset($_SESSION['_product_old_input']);
}

function product_form_value(array $old, ?array $edit, string $key, string $default = ''): string {
    return (string)($old[$key] ?? $edit[$key] ?? $default);
}

/* =========================
   ACCIONES POST
========================= */
if (is_post()) {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $id = (int)($_POST['id_producto'] ?? 0);
        $codigo = trim((string)($_POST['codigo_producto'] ?? ''));
        $nombre = trim((string)($_POST['nombre_producto'] ?? ''));
        $precio = (float)($_POST['precio_usd'] ?? 0);
        $stock = (int)($_POST['stock'] ?? 0);
        $min = (int)($_POST['stock_min'] ?? 5);
        $cat = (int)($_POST['id_categoria'] ?? 0);

        $redirectUrl = $action === 'update' ? 'productos.php?edit=' . $id : 'productos.php';

        product_old_set([
            'id_producto'      => (string)$id,
            'codigo_producto'  => $codigo,
            'nombre_producto'  => $nombre,
            'precio_usd'       => (string)$precio,
            'stock'            => (string)$stock,
            'stock_min'        => (string)$min,
            'id_categoria'     => (string)$cat,
        ]);

        if ($codigo === '' || $nombre === '' || $cat <= 0) {
            flash_set('danger', 'Completa código, nombre y categoría.');
            redirect($redirectUrl);
        }

        if (mb_strlen($codigo) > 20) {
            flash_set('danger', 'El código no puede superar 20 caracteres.');
            redirect($redirectUrl);
        }

        if (!preg_match('/^[A-Za-z0-9_-]+$/', $codigo)) {
            flash_set('danger', 'El código solo puede contener letras, números, guion y guion bajo.');
            redirect($redirectUrl);
        }

        if ($precio < 0) {
            flash_set('danger', 'El precio no puede ser negativo.');
            redirect($redirectUrl);
        }

        if ($stock < 0) {
            flash_set('danger', 'El stock no puede ser negativo.');
            redirect($redirectUrl);
        }

        if ($min < 0) {
            flash_set('danger', 'El stock mínimo no puede ser negativo.');
            redirect($redirectUrl);
        }

        $dupCode = db_one(
            'SELECT id_producto 
             FROM products 
             WHERE codigo_producto = :c AND id_producto <> :id 
             LIMIT 1',
            [
                ':c'  => $codigo,
                ':id' => $id
            ]
        );

        if ($dupCode) {
            flash_set('danger', 'Ya existe un producto con ese código.');
            redirect($redirectUrl);
        }

        if ($action === 'create') {
            db_exec(
                'INSERT INTO products (
                    codigo_producto,
                    nombre_producto,
                    precio_usd,
                    stock,
                    stock_min,
                    id_categoria,
                    date_added
                 ) VALUES (
                    :c, :n, :p, :s, :m, :cat, NOW()
                 )',
                [
                    ':c'   => $codigo,
                    ':n'   => $nombre,
                    ':p'   => $precio,
                    ':s'   => $stock,
                    ':m'   => $min,
                    ':cat' => $cat
                ]
            );

            $newId = db_last_id();

            db_exec(
                'INSERT INTO movimientos (
                    tipo,
                    id_producto,
                    cantidad,
                    stock_antes,
                    stock_despues,
                    referencia,
                    observacion,
                    user_id,
                    created_at
                 ) VALUES (
                    :t, :pid, :c, :sa, :sd, :r, :o, :uid, NOW()
                 )',
                [
                    ':t'   => 'ENTRADA',
                    ':pid' => $newId,
                    ':c'   => $stock,
                    ':sa'  => 0,
                    ':sd'  => $stock,
                    ':r'   => 'REGISTRO_PRODUCTO',
                    ':o'   => 'Alta de producto',
                    ':uid' => (int)(current_user()['id'] ?? 0),
                ]
            );

            audit_log('PRODUCT_CREATE', 'product', $newId, [
                'codigo_producto' => $codigo,
                'nombre_producto' => $nombre,
                'precio_usd'      => $precio,
                'stock'           => $stock,
                'stock_min'       => $min,
                'id_categoria'    => $cat,
            ]);

            product_old_clear();
            flash_set('success', 'Producto creado.');
            redirect('productos.php');
        }

        db_exec(
            'UPDATE products
             SET codigo_producto = :c,
                 nombre_producto = :n,
                 precio_usd = :p,
                 stock = :s,
                 stock_min = :m,
                 id_categoria = :cat
             WHERE id_producto = :id',
            [
                ':c'   => $codigo,
                ':n'   => $nombre,
                ':p'   => $precio,
                ':s'   => $stock,
                ':m'   => $min,
                ':cat' => $cat,
                ':id'  => $id
            ]
        );

        audit_log('PRODUCT_UPDATE', 'product', $id, [
            'codigo_producto' => $codigo,
            'nombre_producto' => $nombre,
            'precio_usd'      => $precio,
            'stock'           => $stock,
            'stock_min'       => $min,
            'id_categoria'    => $cat,
        ]);

        product_old_clear();
        flash_set('success', 'Producto actualizado.');
        redirect('productos.php');
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id_producto'] ?? 0);

        $p = db_one(
            'SELECT codigo_producto, nombre_producto 
             FROM products 
             WHERE id_producto = :id',
            [':id' => $id]
        );

        if ($p) {
            db_exec('DELETE FROM movimientos WHERE id_producto = :id', [':id' => $id]);
            db_exec('DELETE FROM products WHERE id_producto = :id', [':id' => $id]);

            audit_log('PRODUCT_DELETE', 'product', $id, [
                'codigo_producto' => $p['codigo_producto'] ?? null,
                'nombre_producto' => $p['nombre_producto'] ?? null,
            ]);

            flash_set('success', 'Producto y su historial eliminados correctamente.');
        } else {
            flash_set('danger', 'El producto no existe.');
        }

        redirect('productos.php');
    }
}

/* =========================
   DATOS PARA LA VISTA
========================= */
$categorias = db_all(
    'SELECT id_categoria, nombre_categoria
     FROM categorias
     ORDER BY nombre_categoria ASC'
);

$buscar = trim((string)($_GET['buscar'] ?? ''));
$params = [];
$where = '';

if ($buscar !== '') {
    $where = 'WHERE p.nombre_producto LIKE :q1 
              OR p.codigo_producto LIKE :q2 
              OR c.nombre_categoria LIKE :q3';

    $like = '%' . $buscar . '%';

    $params = [
        ':q1' => $like,
        ':q2' => $like,
        ':q3' => $like
    ];
}

$productos = db_all(
    "SELECT p.*, c.nombre_categoria
     FROM products p
     LEFT JOIN categorias c ON c.id_categoria = p.id_categoria
     $where
     ORDER BY p.id_producto DESC",
    $params
);

$edit_id = (int)($_GET['edit'] ?? 0);
$edit = null;

if ($edit_id > 0) {
    $edit = db_one(
        'SELECT * FROM products WHERE id_producto = :id',
        [':id' => $edit_id]
    );
}

$old = product_old_get();
product_old_clear();

$currentCategoria = (int)($old['id_categoria'] ?? ($edit['id_categoria'] ?? 0));
