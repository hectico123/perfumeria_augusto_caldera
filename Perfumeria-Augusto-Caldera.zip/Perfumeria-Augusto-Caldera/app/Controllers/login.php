<?php

$page = 'Iniciar sesión';
$active = '';

if (is_logged_in()) {
    redirect('dashboard');
}

$error = '';
$oldUser = '';

if (is_post()) {
    csrf_verify();
    $user = trim((string)($_POST['user'] ?? ''));
    $pass = (string)($_POST['password'] ?? '');
    $oldUser = $user;

    $captcha = (string)($_POST['g-recaptcha-response'] ?? '');
    $captchaCheck = verify_recaptcha($captcha, $_SERVER['REMOTE_ADDR'] ?? null);

    if (!$captchaCheck['ok']) {
        $error = $captchaCheck['message'];
    } else {
        try {
            $res = login_attempt($user, $pass);
            if ($res['ok']) {
                if (!empty($res['redirect'])) {
                    redirect((string)$res['redirect']);
                }
                redirect('dashboard');
            }
            $error = $res['msg'];
        } catch (Throwable $e) {
            $error = APP_ENV === 'development'
                ? ('Error al iniciar sesión: ' . $e->getMessage())
                : 'Error al iniciar sesión.';
        }
    }
}

$flash = flash_get();
